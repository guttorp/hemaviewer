/*    */ package hematopoiesissimulator;
/*    */ 
/*    */ import java.awt.Color;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class XY
/*    */ {
/*    */   private int xPos;
/*    */   private int yPos;
/*    */   private double xPOS;
/*    */   private double yPOS;
/*    */   private Color color;
/*    */   
/*    */   public XY(int x, int y)
/*    */   {
/* 20 */     this.xPos = x;
/* 21 */     this.yPos = y;
/*    */   }
/*    */   
/*    */   public XY(int x, int y, Color c) {
/* 25 */     this.xPos = x;
/* 26 */     this.yPos = y;
/* 27 */     this.color = c;
/*    */   }
/*    */   
/* 30 */   public XY(double x, double y, Color c) { this.color = c;
/* 31 */     this.xPOS = x;
/* 32 */     this.yPOS = y;
/*    */   }
/*    */   
/*    */   public Color getColor()
/*    */   {
/* 37 */     return this.color;
/*    */   }
/*    */   
/*    */   public int getX() {
/* 41 */     return this.xPos;
/*    */   }
/*    */   
/*    */   public int getY() {
/* 45 */     return this.yPos;
/*    */   }
/*    */   
/*    */   public double GETX() {
/* 49 */     return this.xPOS;
/*    */   }
/*    */   
/*    */   public double GETY() {
/* 53 */     return this.yPOS;
/*    */   }
/*    */ }


/* Location:              /Users/jasonxu/Desktop/HematopoiesisSimulator.jar!/hematopoiesissimulator/XY.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */