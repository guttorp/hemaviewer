/*    */ package hematopoiesissimulator;
/*    */ 
/*    */ import edu.rit.util.Random;
/*    */ import java.awt.Color;
/*    */ import java.awt.Dimension;
/*    */ import java.awt.Graphics;
/*    */ import java.beans.PropertyChangeListener;
/*    */ import java.beans.PropertyChangeSupport;
/*    */ import java.io.Serializable;
/*    */ import java.util.ArrayList;
/*    */ import javax.swing.JPanel;
/*    */ import simulatorcore.MiceRandom;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class paintCanvasBean
/*    */   extends JPanel
/*    */   implements Serializable
/*    */ {
/*    */   public static final String PROP_SAMPLE_PROPERTY = "sampleProperty";
/*    */   private String sampleProperty;
/*    */   private PropertyChangeSupport propertySupport;
/*    */   private ArrayList<XY> xAndY;
/*    */   private double x;
/*    */   private double y;
/* 26 */   public int numOfA = 0;
/* 27 */   public int numOfB = 0;
/*    */   private MiceRandom mr;
/*    */   
/*    */   public paintCanvasBean()
/*    */   {
/* 32 */     this.xAndY = new ArrayList();
/* 33 */     this.mr = new MiceRandom(1);
/*    */     
/* 35 */     this.propertySupport = new PropertyChangeSupport(this);
/*    */   }
/*    */   
/*    */   public String getSampleProperty() {
/* 39 */     return this.sampleProperty;
/*    */   }
/*    */   
/*    */   public void setSampleProperty(String value) {
/* 43 */     String oldValue = this.sampleProperty;
/* 44 */     this.sampleProperty = value;
/* 45 */     this.propertySupport.firePropertyChange("sampleProperty", oldValue, this.sampleProperty);
/*    */   }
/*    */   
/*    */   public void addPropertyChangeListener(PropertyChangeListener listener)
/*    */   {
/* 50 */     this.propertySupport.addPropertyChangeListener(listener);
/*    */   }
/*    */   
/*    */   public void removePropertyChangeListener(PropertyChangeListener listener) {
/* 54 */     this.propertySupport.removePropertyChangeListener(listener);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void updateCanvas(double x, double y, Color c)
/*    */   {
/* 64 */     this.xAndY.add(new XY(x, y, c));
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void paint(Graphics g)
/*    */   {
/* 71 */     super.paint(g);
/* 72 */     Dimension d = getSize();
/* 73 */     this.x = d.getWidth();
/* 74 */     this.y = d.getHeight();
/*    */     
/* 76 */     long[] c = new long[this.numOfA + this.numOfB];
/* 77 */     for (int i = 0; i < this.numOfA; i++) c[i] = 1L;
/* 78 */     for (int i = 0; i < this.numOfB; i++) c[(this.numOfA + i)] = 0L;
/* 79 */     this.mr.rperm(c, this.numOfA + this.numOfB);
/*    */     
/* 81 */     for (int i = 0; i < this.numOfA + this.numOfB; i++) {
/* 82 */       if (c[i] == 1L) g.setColor(Color.BLUE); else g.setColor(Color.GREEN);
/* 84 */       g.fillOval((int)Math.round(this.mr.random.nextDouble() * this.x), (int)Math.round(this.mr.random.nextDouble() * this.y), 10, 10);
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void clearStat()
/*    */   {
/* 93 */     this.numOfA = 0;
/* 94 */     this.numOfB = 0;
/*    */   }
/*    */ }


/* Location:              /Users/jasonxu/Desktop/HematopoiesisSimulator.jar!/hematopoiesissimulator/paintCanvasBean.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */