/*    */ package hematopoiesissimulator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Util
/*    */ {
/*    */   public static String Precision(double a, int prec)
/*    */   {
/* 22 */     return Double.toString(Math.floor(a * Math.pow(10.0D, prec)) / Math.pow(10.0D, prec));
/*    */   }
/*    */ }


/* Location:              /Users/jasonxu/Desktop/HematopoiesisSimulator.jar!/hematopoiesissimulator/Util.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */