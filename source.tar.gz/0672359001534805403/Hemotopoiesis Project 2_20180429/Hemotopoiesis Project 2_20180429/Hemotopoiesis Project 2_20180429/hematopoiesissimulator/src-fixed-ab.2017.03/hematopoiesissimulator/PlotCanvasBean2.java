/*     */ package hematopoiesissimulator;
/*     */ 
/*     */ import java.awt.BasicStroke;
/*     */ import java.awt.Color;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Font;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.beans.PropertyChangeListener;
/*     */ import java.beans.PropertyChangeSupport;
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import javax.swing.JPanel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PlotCanvasBean2
/*     */   extends JPanel
/*     */   implements Serializable
/*     */ {
/*     */   public static final String PROP_SAMPLE_PROPERTY = "sampleProperty";
/*     */   private String sampleProperty;
/*  25 */   public boolean sampling = true;
/*     */   private PropertyChangeSupport propertySupport;
/*     */   private ArrayList<XY> xAndYSample;
/*     */   
/*     */   public String getSampleProperty() {
/*  30 */     return this.sampleProperty;
/*     */   }
/*     */   
/*     */   public void setSampleProperty(String value) {
/*  34 */     String oldValue = this.sampleProperty;
/*  35 */     this.sampleProperty = value;
/*  36 */     this.propertySupport.firePropertyChange("sampleProperty", oldValue, this.sampleProperty);
/*     */   }
/*     */   
/*     */   public void addPropertyChangeListener(PropertyChangeListener listener)
/*     */   {
/*  41 */     this.propertySupport.addPropertyChangeListener(listener);
/*     */   }
/*     */   
/*     */   public void removePropertyChangeListener(PropertyChangeListener listener) {
/*  45 */     this.propertySupport.removePropertyChangeListener(listener);
/*     */   }
/*     */   
/*     */   private ArrayList<XY> xAndYRes;
/*     */   private int width;
/*     */   private int height;
/*  51 */   private Color color = Color.black;
/*     */   private int inset;
/*     */   private double ymax;
/*     */   private double ymin;
/*     */   private double xmax;
/*     */   private double xmin;
/*     */   private double timeLine;
/*  58 */   private PlotCoord pc; private Graphics gg; boolean hasTimeLine; boolean outOfMemory; private String t = new String("System Out Of Memory");
/*  59 */   private int totalWeeks = 400;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PlotCanvasBean2()
/*     */   {
/*  73 */     this.propertySupport = new PropertyChangeSupport(this);
/*     */     
/*  75 */     this.outOfMemory = false;
/*  76 */     this.hasTimeLine = false;
/*  77 */     this.xAndYSample = new ArrayList();
/*  78 */     this.xAndYRes = new ArrayList();
/*  79 */     this.ymin = 0.0D;
/*  80 */     this.ymax = 1.0D;
/*  81 */     this.xmin = 0.0D;
/*  82 */     this.xmax = this.totalWeeks;
/*  83 */     Dimension d = getSize();
/*  84 */     this.width = ((int)d.getWidth());
/*  85 */     this.height = ((int)d.getHeight());
/*  86 */     this.inset = 20;
/*     */     
/*  88 */     this.pc = new PlotCoord(this.xmax, this.ymax, this.xmin, this.ymin, this.width, this.height, this.inset);
/*     */   }
/*     */   
/*     */   public void setTotalWeeks(int _totalWeeks)
/*     */   {
/*  93 */     this.totalWeeks = _totalWeeks;
/*  94 */     this.xmax = this.totalWeeks;
/*  95 */     this.pc = new PlotCoord(this.xmax, this.ymax, this.xmin, this.ymin, this.width, this.height, this.inset);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void changeColor(Color inColor)
/*     */   {
/* 102 */     this.color = inColor;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setXmin(float newXmin)
/*     */   {
/* 110 */     this.xmin = newXmin;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public double getXmin()
/*     */   {
/* 117 */     return this.xmin;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setXmax(float newXmax)
/*     */   {
/* 124 */     this.xmax = newXmax;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setOutOfMemory(boolean memory)
/*     */   {
/* 131 */     this.outOfMemory = memory;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void initComponents() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void paint(Graphics g)
/*     */   {
/* 156 */     super.paint(g);
/* 157 */     this.gg = g;
/* 158 */     Dimension d = getSize();
/* 159 */     this.height = ((int)d.getHeight());
/* 160 */     this.width = ((int)d.getWidth());
/* 161 */     g.drawRect(0, 0, d.width - 1, d.height - 1);
/* 162 */     this.pc = new PlotCoord(this.xmax, this.ymax, this.xmin, this.ymin, this.width, this.height, this.inset);
/* 163 */     g.setColor(this.color);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 172 */     int xcoord = 0;int ycoord = 0;
/*     */     
/*     */ 
/*     */ 
/* 176 */     double xaxisStart = this.xmax;double xaxisEnd = this.xmin;
/* 177 */     double yaxisStart = this.ymax;double yaxisEnd = this.ymin;
/*     */     
/*     */ 
/*     */     double yaxisPosx;
/*     */     
/*     */  
/*     */     
/* 184 */     if ((this.xmin < 0.0D) && (this.xmax > 0.0D)) {
/* 185 */       yaxisPosx = 0.0D;
/*     */     } else
/* 187 */       yaxisPosx = this.xmin;
/*     */    
/* 189 */     double xaxisPosy; if ((this.ymin < 0.0D) && (this.ymax > 0.0D)) {
/* 190 */       xaxisPosy = 0.0D;
/*     */     } else {
/* 192 */       xaxisPosy = this.ymin;
/*     */     }
/* 194 */     Font f = new Font("Dialog", 0, 10);
/* 195 */     g.setFont(f);
/*     */     
/*     */ 
/* 198 */     g.drawLine(this.pc.xcoord(xaxisStart), this.pc.ycoord(xaxisPosy) + 5, this.pc.xcoord(xaxisEnd), this.pc.ycoord(xaxisPosy) + 5);
/*     */     
/* 200 */     g.drawLine(this.pc.xcoord(yaxisPosx), this.pc.ycoord(yaxisStart), this.pc.xcoord(yaxisPosx), this.pc.ycoord(yaxisEnd) + 5);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 205 */     if ((this.xmin < 0.0D) && (this.xmax > 0.0D)) {
/* 206 */       xcoord = this.pc.xcoord(0.0D);
/* 207 */       ycoord = this.pc.ycoord(xaxisPosy);
/* 208 */       g.drawLine(xcoord, ycoord + 3, xcoord, ycoord - 3);
/* 209 */       g.drawString("0", xcoord - 5, ycoord + 15);
/*     */     }
/*     */     
/* 212 */     if ((this.ymin < 0.0D) && (this.ymax > 0.0D)) {
/* 213 */       ycoord = this.pc.ycoord(0.0D);
/* 214 */       xcoord = this.pc.xcoord(yaxisPosx);
/* 215 */       g.drawLine(xcoord + 3, ycoord, xcoord - 3, ycoord);
/* 216 */       g.drawString("0", xcoord + 7, ycoord + 10);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 222 */     ycoord = this.pc.ycoord(this.ymax);
/* 223 */     xcoord = this.pc.xcoord(yaxisPosx);
/* 224 */     g.drawLine(xcoord + 3, ycoord, xcoord - 3, ycoord);
/* 225 */     g.drawString("100%", xcoord - 19, ycoord + 5);
/*     */     
/*     */ 
/* 228 */     ycoord = this.pc.ycoord(this.ymin + (this.ymax - this.ymin) / 2.0D);
/* 229 */     xcoord = this.pc.xcoord(yaxisPosx);
/* 230 */     g.drawLine(xcoord + 3, ycoord, xcoord - 3, ycoord);
/* 231 */     g.drawString("50%", xcoord - 17, ycoord + 5);
/* 232 */     if (this.outOfMemory) {
/* 233 */       g.drawString(this.t, xcoord + 60, ycoord + 5);
/*     */     }
/*     */     
/*     */ 
/* 237 */     ycoord = this.pc.ycoord(this.ymin);
/* 238 */     xcoord = this.pc.xcoord(yaxisPosx);
/* 239 */     g.drawLine(xcoord + 3, ycoord, xcoord - 3, ycoord);
/* 240 */     g.drawString("0%", xcoord - 17, ycoord + 5);
/* 241 */     if (this.outOfMemory) {
/* 242 */       g.drawString(this.t, xcoord + 60, ycoord + 5);
/*     */     }
/*     */     
/*     */ 
/* 246 */     xcoord = this.pc.xcoord(this.xmin);
/* 247 */     ycoord = this.pc.ycoord(xaxisPosy);
/* 248 */     g.drawLine(xcoord, ycoord + 3, xcoord, ycoord - 3);
/* 249 */     g.drawString("0", xcoord - 5, ycoord + 15);
/*     */     
/*     */ 
/* 252 */     xcoord = this.pc.xcoord(this.xmin + (this.xmax - this.xmin) / 2.0D);
/* 253 */     ycoord = this.pc.ycoord(xaxisPosy);
/* 254 */     g.drawLine(xcoord, ycoord + 4, xcoord, ycoord - 3);
/* 255 */     g.drawString(Integer.toString(this.totalWeeks / 2), xcoord - 5, ycoord + 15);
/*     */     
/*     */ 
/* 258 */     xcoord = this.pc.xcoord(this.xmax);
/* 259 */     ycoord = this.pc.ycoord(xaxisPosy);
/* 260 */     g.drawLine(xcoord, ycoord + 4, xcoord, ycoord - 3);
/* 261 */     g.drawString(this.totalWeeks + " weeks", xcoord - 40, ycoord + 15);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 269 */     if (this.sampling) {
/* 270 */       Iterator it = this.xAndYSample.iterator();
/* 271 */       if (it.hasNext()) {
/* 272 */         g.setColor(Color.MAGENTA);
/* 273 */         XY prevXY = (XY)it.next();
/*     */         
/* 275 */         while (it.hasNext()) {
/* 276 */           XY xY = (XY)it.next();
/* 277 */           if ((prevXY.getY() != Integer.MAX_VALUE) && (xY.getY() != Integer.MAX_VALUE))
/* 278 */             g.drawLine(prevXY.getX(), prevXY.getY(), xY.getX(), xY.getY());
/* 279 */           prevXY = xY;
/*     */         }
/* 281 */         g.setColor(Color.black);
/*     */       }
/*     */     }
/* 284 */     Iterator it = this.xAndYRes.iterator();
/* 285 */     if (it.hasNext()) {
/* 286 */       g.setColor(Color.black);
/* 287 */       XY prevXY = (XY)it.next();
/*     */       
/* 289 */       while (it.hasNext()) {
/* 290 */         XY xY = (XY)it.next();
/* 291 */         Graphics2D g2 = (Graphics2D)g;
/* 292 */         g2.setStroke(new BasicStroke(1.2F));
/* 293 */         if ((prevXY.getY() != Integer.MAX_VALUE) && (xY.getY() != Integer.MAX_VALUE))
/* 294 */           g2.drawLine(prevXY.getX(), prevXY.getY(), xY.getX(), xY.getY());
/* 295 */         prevXY = xY;
/*     */       }
/*     */     }
/*     */     
/* 299 */     if (this.hasTimeLine) {
/* 300 */       g.setColor(Color.GRAY);
/* 301 */       g.drawLine(this.pc.xcoord(this.timeLine), this.pc.ycoord(0.0D), this.pc.xcoord(this.timeLine), this.pc.ycoord(1.0D));
/* 302 */       g.setColor(Color.BLACK);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void clearModel()
/*     */   {
/* 311 */     this.xAndYSample.clear();
/* 312 */     this.xAndYRes.clear();
/*     */   }
/*     */   
/*     */   public void forcePaint() {
/* 316 */     Graphics g = getGraphics();
/*     */     
/*     */ 
/*     */ 
/* 320 */     if (this.sampling) {
/* 321 */       Iterator it = this.xAndYSample.iterator();
/* 322 */       if (it.hasNext()) {
/* 323 */         g.setColor(Color.MAGENTA);
/* 324 */         XY prevXY = (XY)it.next();
/*     */         
/* 326 */         while (it.hasNext()) {
/* 327 */           XY xY = (XY)it.next();
/* 328 */           g.drawLine(prevXY.getX(), prevXY.getY(), xY.getX(), xY.getY());
/* 329 */           prevXY = xY;
/*     */         }
/* 331 */         g.setColor(Color.black);
/*     */       }
/*     */     }
/* 334 */     Iterator it = this.xAndYRes.iterator();
/* 335 */     if (it.hasNext()) {
/* 336 */       g.setColor(Color.black);
/* 337 */       XY prevXY = (XY)it.next();
/*     */       
/* 339 */       while (it.hasNext()) {
/* 340 */         XY xY = (XY)it.next();
/* 341 */         Graphics2D g2 = (Graphics2D)g;
/* 342 */         g2.setStroke(new BasicStroke(1.2F));
/* 343 */         g2.drawLine(prevXY.getX(), prevXY.getY(), xY.getX(), xY.getY());
/* 344 */         prevXY = xY;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void updateSample(double x, double y)
/*     */   {
/* 355 */     int thisX = this.pc.xcoord(x);
/* 356 */     int thisY = this.pc.ycoord(y);
/*     */     
/* 358 */     this.xAndYSample.add(new XY(thisX, thisY));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void updateContin(double x, double y)
/*     */   {
/* 368 */     int thisX = this.pc.xcoord(x);
/* 369 */     int thisY = this.pc.ycoord(y);
/*     */     
/* 371 */     this.xAndYRes.add(new XY(thisX, thisY));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTimeLine(double time)
/*     */   {
/* 381 */     this.timeLine = time;
/* 382 */     this.hasTimeLine = true;
/*     */   }
/*     */ }


/* Location:              /Users/jasonxu/Desktop/HematopoiesisSimulator.jar!/hematopoiesissimulator/PlotCanvasBean2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */