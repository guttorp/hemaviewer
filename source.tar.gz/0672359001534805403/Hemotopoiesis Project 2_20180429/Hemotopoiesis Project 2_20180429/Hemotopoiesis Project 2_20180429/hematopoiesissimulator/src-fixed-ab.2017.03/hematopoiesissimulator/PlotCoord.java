/*    */ package hematopoiesissimulator;
		
/*    */ class PlotCoord//class initialization
/*    */ {
/* 15 */   double xstretch = 1.0D;
/* 16 */   double ystretch = 1.0D;
/* 17 */   double xshift = 0.0D;
/* 18 */   double yshift = 0.0D;
/*    */   double ywholeScreen;
/*    */   int inset;
/*    */   int width;
/*    */   int height;
/*    */   double xM;
/*    */   double yM;
/*    */   double ym;
/*    */   double xm;
/*    */   
/*    */   PlotCoord(double xmax, double ymax, double xmin, double ymin, int w, int h, int insetin)
/*    */   {
/* 30 */     this.width = w;
/* 31 */     this.height = h;
/* 32 */     this.xM = xmax;
/* 33 */     this.xm = xmin;
/* 34 */     this.yM = ymax;
/* 35 */     this.ym = ymin;
/* 36 */     this.inset = insetin;
/*    */     
/* 38 */     this.xstretch = ((this.width - 2 * this.inset) / (xmax - xmin)); //change to double?
/* 39 */     this.ystretch = ((this.height - 2 * this.inset) / (ymax - ymin));
/*    */     
/* 41 */     this.xshift = (-xmin);
/* 42 */     this.yshift = (-ymin);
/*    */     
/* 44 */     this.ywholeScreen = (ymax - ymin);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   int xcoord(double x)
/*    */   {
/* 56 */     double xcoordDouble = (x + this.xshift) * this.xstretch + this.inset;
/* 57 */     return (int)Math.round(xcoordDouble);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   int ycoord(double y)
/*    */   {
/* 68 */     double ycoordDouble = (this.ywholeScreen - (y + this.yshift)) * this.ystretch + this.inset;
/* 69 */     if (Double.isNaN(ycoordDouble)) return Integer.MAX_VALUE;
/* 70 */     return (int)Math.round(ycoordDouble);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void setWidth(int w)
/*    */   {
/* 77 */     this.width = w;
/* 78 */     this.xstretch = ((this.width - 2 * this.inset) / (this.xM - this.xm));
/*    */   }
/*    */   
/*    */   public void setHeight(int h) {
/* 82 */     this.height = h;
/* 83 */     this.ystretch = ((this.height - 2 * this.inset) / (this.yM - this.ym));
/*    */   }
/*    */   
/*    */   public void update(int w, int h)
/*    */   {
/* 88 */     setWidth(w);
/* 89 */     setHeight(h);
/*    */   }
/*    */ }


/* Location:              /Users/jasonxu/Desktop/HematopoiesisSimulator.jar!/hematopoiesissimulator/PlotCoord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */