/*    */ package hematopoiesissimulator;
/*    */ 
/*    */ import java.io.FileNotFoundException;
/*    */ import javax.swing.JFrame;
/*    */ import javax.swing.JTextField;
/*    */ 
/*    */ public class TestZZ
/*    */ {
/*    */   public static void main(String[] arg)
/*    */     throws FileNotFoundException
/*    */   {
/* 12 */     JFrame window = new JFrame();
/* 13 */     window.setDefaultCloseOperation(3);
/* 14 */     JTextField temp = new JTextField(10);
/*    */     
/* 16 */     window.add(temp);
/* 17 */     window.setSize(600, 200);
/* 18 */     window.setVisible(true);
/* 19 */     temp.setText("0123456789");
/*    */   }
/*    */ }


/* Location:              /Users/jasonxu/Desktop/HematopoiesisSimulator.jar!/hematopoiesissimulator/TestZZ.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */