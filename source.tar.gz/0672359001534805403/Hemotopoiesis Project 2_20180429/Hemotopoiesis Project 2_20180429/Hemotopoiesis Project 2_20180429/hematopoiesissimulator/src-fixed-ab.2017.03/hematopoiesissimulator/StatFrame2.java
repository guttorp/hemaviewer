/*      */ package hematopoiesissimulator;
/*      */ 
/*      */ import java.awt.AWTException;
/*      */ import java.awt.BorderLayout;
/*      */ import java.awt.Color;
/*      */ import java.awt.Component;
/*      */ import java.awt.Container;
/*      */ import java.awt.FlowLayout;
/*      */ import java.awt.Font;
/*      */ import java.awt.GridLayout;
/*      */ import java.awt.Robot;
/*      */ import java.awt.event.ActionEvent;
/*      */ import java.awt.event.ActionListener;
/*      */ import java.awt.event.AdjustmentEvent;
/*      */ import java.awt.event.ItemEvent;
/*      */ import java.awt.event.ItemListener;
/*      */ import java.io.File;
/*      */ import java.io.FileOutputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.PrintStream;
import java.util.ArrayList;
/*      */ import java.util.Date;
import java.util.List;
/*      */ import java.util.Scanner;
/*      */ import javax.accessibility.AccessibleContext;
/*      */ import javax.swing.BorderFactory;
/*      */ import javax.swing.ButtonGroup;
/*      */ import javax.swing.GroupLayout;
/*      */ import javax.swing.GroupLayout.Alignment;
/*      */ import javax.swing.GroupLayout.ParallelGroup;
/*      */ import javax.swing.GroupLayout.SequentialGroup;
/*      */ import javax.swing.JButton;
/*      */ import javax.swing.JCheckBox;
/*      */ import javax.swing.JCheckBoxMenuItem;
/*      */ import javax.swing.JComboBox;
/*      */ import javax.swing.JLabel;
/*      */ import javax.swing.JMenu;
/*      */ import javax.swing.JMenuBar;
/*      */ import javax.swing.JMenuItem;
/*      */ import javax.swing.JOptionPane;
/*      */ import javax.swing.JPanel;
/*      */ import javax.swing.JRadioButtonMenuItem;
/*      */ import javax.swing.JScrollBar;
/*      */ import javax.swing.JSlider;
/*      */ import javax.swing.JTabbedPane;
/*      */ import javax.swing.JTextArea;
/*      */ import javax.swing.JTextField;
/*      */ import javax.swing.JToggleButton;
import javax.swing.LayoutStyle;
/*      */ import javax.swing.LayoutStyle.ComponentPlacement;
/*      */ import javax.swing.event.ChangeEvent;
/*      */ import javax.swing.event.ChangeListener;
/*      */ import org.netbeans.lib.awtextra.AbsoluteConstraints;
/*      */ import simulatorcore.Mice2new;
import javax.swing.SwingConstants;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.Insets;
/*      */ 
/*      */ public class StatFrame2 extends javax.swing.JFrame implements Runnable
/*      */ {
/*      */   private static final int TEXTFIELD_COLUMNS = 6;
/*      */   private org.w3c.dom.Document config;
/*   57 */   private String configFile = "config.xml";
/*      */   private paintCanvasBean ContributingGraphicsPanel;
/*      */   private PlotCanvasBean conPercentGraphicsPanel;
/*      */   private PlotCanvasBean2 resPercentGraphicsPanel;
/*      */   private JLabel ReserveCompartmentLabel;
/*      */   private JLabel ReserveCompartmentLabel1;
/*      */   private paintCanvasBean ReserveGraphicsPanel;
/*      */   private JLabel alphaLabel;
/*      */   private JLabel alphaLabelA;
/*      */   private JLabel alphaLabelB;
/*      */   private JSlider alphaSlider;
/*      */   private JSlider alphaSliderA;
/*      */   private JSlider alphaSliderB;
/*      */   private JTextField alphaTextField;
/*      */   private JTextField alphaTextFieldA;
/*      */   private JTextField alphaTextFieldB;
/*      */   private JLabel c0Label;
/*      */   private JCheckBox cellChance;
/*      */   private JButton clearButton;
/*      */   private JLabel conDtypeLabel;
/*      */   private JLabel conGtypeLabel;
/*      */   private JLabel conPercentlLabel;
/*      */   private JLabel conSamplelLabel;
/*      */   private JLabel conTotalLabel;
/*      */   private JLabel contributingCompLabel;
/*      */   private JComboBox creaturesComboBox;
/*      */   private JLabel currentTimeLabel;
/*      */   private JTextField currentTimeValueTextField;
/*      */   private JLabel dtypeLabel;
/*      */   private JButton exportButton;
/*      */   private JLabel gtypeLabel;
/*      */   private JPanel initParamPanel;
/*      */   private JSlider intConSlider;
/*      */   private JTextField intConTextField;
/*      */   private JSlider intResSlider;
/*      */   private JTextField intResTextField;
/*      */   private JLabel jLabel30;
/*      */   private JLabel jLabel4;
/*      */   private JPanel jPanel1;
/*      */   private JPanel jPanel2;
/*      */   private JPanel jPanel3;
/*      */   private JPanel jPanel4;
/*      */   private JTabbedPane jTabbedPane1;
/*      */   
/*      */   public static void main(String[] args)
/*      */   {
/*   67 */     Date expiration = new Date(109, 10, 2);
/*   68 */     Date rightNow = new Date();
/*      */     
/*   70 */     int comp = -1;

/*   76 */     if (comp <= 0) {
/*   77 */       java.awt.EventQueue.invokeLater(new Runnable()
/*      */       {
/*      */         public void run()
/*      */         {
/*   79 */           new StatFrame2().setVisible(true);
/*      */         }
/*      */       });
/*      */     } else {
/*   83 */       JOptionPane.showMessageDialog(null, "This beta version is only valid until 11-01-2009.", 
/*   84 */         "", 0);
/*      */     }
/*      */   }
/*      */   
/*      */   private JLabel kLabel;
/*      */   private JCheckBox abDiffBox;
/*      */   private JLabel lambdaLabel;
/*      */   private JLabel lambdaLabelA;
/*      */   private JLabel lambdaLabelB;
/*      */   private JLabel lambdaNuRatioLabel;
/*      */   private JLabel lambdaNuRatioTextField;
/*      */   private JSlider lambdaSlider;
/*      */   private JSlider lambdaSliderA;
/*      */   private JSlider lambdaSliderB;
/*      */   private JTextField lambdaTextField;
/*      */   private JTextField lambdaTextFieldA;
/*      */   private JTextField lambdaTextFieldB;
/*      */   private JSlider maxCellSlider;
/*      */   private JTextField maxCellTextField;
/*      */   private JLabel muLabel;
/*      */   private JLabel muLabelA;
/*      */   private JLabel muLabelB;
/*      */   private JSlider muSlider;
/*      */   private JSlider muSliderA;
/*      */   private JSlider muSliderB;
/*      */   private JTextField muTextField;
/*      */   private JTextField muTextFieldA;
/*      */   private JTextField muTextFieldB;
/*      */   private JLabel nuLabel;
/*      */   private JLabel nuMuRatioLabel;
/*      */   private JLabel nuMuRatioTextField;
/*      */   private JSlider nuSlider;
/*      */   private JTextField nuTextField;
/*      */   
/*      */   public StatFrame2()
/*      */   {
			  
/*   96 */     this.lambdaLB = 0;
/*   97 */     this.lambdaUB = 60;
/*   98 */     this.nuLB = 0;
/*   99 */     this.nuUB = 60;
/*  100 */     this.muLB = 0;
/*  101 */     this.muUB = 60;
/*  102 */     this.alphaLB = 0;
/*  103 */     this.alphaUB = 1000;
/*  104 */     this.scale = 100;
/*  105 */     this.N = 10000;
/*  106 */     this.N2 = 10000;
/*  107 */     this.sampleSize = 70;
/*  108 */     this.sampleInterval = 10.0D;
/*  109 */     this.percentR0a = 50.0D;
/*  110 */     this.percentC0a = 50.0D;
/*  111 */     this.cellChanceRate = 0.5D;
/*  112 */     this.mutationProb = 0.001D;
/*  113 */     this.proportion = 0.001D;
/*  114 */     this.noUpperLimitRes = false;
/*  115 */     this.runRandomeMutationMode = false;
/*      */     
/*      */ 
/*  118 */     this.firstSeed = (System.currentTimeMillis() % 1000000000L);
/*      */     
/*      */ 
/*  121 */     setParamInits("cat");
/*  122 */     this.alreadyRun = false; 
/*  128 */     setLocation(60, 60);
			   initComponents();
/*  126 */     setSliderInitValues();
			   this.randomSeedTextField.setText(Long.toString(this.firstSeed));
/*  129 */     this.conPercentGraphicsPanel.setTotalWeeks(this.totalWeeks);
/*  130 */     this.resPercentGraphicsPanel.setTotalWeeks(this.totalWeeks);
/*  131 */     this.sampleSizeLabel.setVisible(false);
/*  132 */     this.sampleSizeTextField.setVisible(false);
/*  133 */     this.conPercentGraphicsPanel.sampling = false;
/*  134 */     this.resPercentGraphicsPanel.sampling = false;
/*  135 */     this.displayParameters = false;
/*  136 */     this.useParaSameAsLastTimeBoolean = false;
/*  137 */     this.plottingDelayMilseconds = 0L;
/*  138 */     this.maxCellConBoolean = false;
/*      */   }
/*      */   
/*      */   private JLabel obsLengthWeeksLabel;
/*      */   private JLabel perLabel1;
/*      */   private JLabel perLabel2;
/*      */   private JLabel perLabel3;
/*      */   private JLabel perLabel4;
/*      */   private JLabel percentC0Label;
/*      */   private JTextField percentC0TextField;
/*      */   private JLabel percentG6PDLabel;
/*      */   private JLabel percentLabel;
/*      */   private JLabel percentR0Label;
/*      */   private JTextField percentR0TextField;
/*      */   private JLabel r0Label;
/*      */   private JLabel randomSeedLabel;
/*      */   private JTextField randomSeedTextField;
/*      */   private JPanel ratesPanel;
/*      */   private JLabel resDtypeLabel;
/*      */   private JLabel resGtypeLabel;
/*      */   private JLabel resPercentlLabel;
/*      */   private JLabel resSamplelLabel;
/*      */   private JLabel resTotalLabel;
/*      */   private JToggleButton runPauseButton;
/*      */   private JLabel sampleIntervalLabel;
/*      */   private JTextField sampleIntervalTextField;
/*      */   
/*      */   public void run()
/*      */   {
/*  145 */     if (this.useParaSameAsLastTimeBoolean) {
/*      */       try {
/*  147 */         Scanner input = new Scanner(new File(this.useParaSameAsLastTimeFileName));
/*  148 */         processInput(input);
/*      */       } catch (Exception e) {
/*  150 */         JOptionPane.showMessageDialog(null, "Fail to use same parameters as last run.", 
/*  151 */           "ERROR", 0);
/*      */       }
/*      */     }

/*  166 */     if (!this.alreadyRun) {
/*  167 */       String s = this.plotComboBox.getSelectedItem().toString();
/*  168 */       if (s.startsWith("C")) {
/*  169 */         this.plotComboBox.setSelectedIndex(1);
/*      */         try {
/*  171 */           Thread.currentThread();Thread.sleep(10L);
/*      */         } catch (InterruptedException e) {
/*  173 */           e.printStackTrace();
/*      */         }
/*  176 */         this.plotComboBox.setSelectedIndex(0);
/*      */       } else {
/*  178 */         this.plotComboBox.setSelectedIndex(0);
/*      */         try {
/*  180 */           Thread.currentThread();Thread.sleep(10L);
/*      */         } catch (InterruptedException e) {
/*  182 */           e.printStackTrace();
/*      */         }
/*      */         
/*  185 */         this.plotComboBox.setSelectedIndex(1);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  190 */     performSimulation();
/*  198 */     int j = 0;
/*  199 */     double time = 0.0D;
/*      */     
/*      */ 
/*      */ 
/*  203 */     double sam = (double)this.mice2new.Cd0 / (double)this.mice2new.C0;
/*  204 */     double sam2 = (double)this.mice2new.Rd0 / (double)this.mice2new.R0;
/*  205 */     double percent = sam;
/*  206 */     double percent2 = sam2;
/*  207 */     this.conPercentGraphicsPanel.updateContin(0.0D * this.sampleInterval, percent);
/*  208 */     this.resPercentGraphicsPanel.updateContin(0.0D * this.sampleInterval, percent2);
/*  209 */     this.conPercentGraphicsPanel.updateSample(0.0D, sam);
/*  210 */     this.resPercentGraphicsPanel.updateSample(0.0D, sam2);
/*      */     
			   //plot points
/*  212 */     while (j <= (int)((double)this.totalWeeks / this.sampleInterval)) {
/*  213 */       if (!this.paused) {
/*  214 */         percent = (double)this.mice2new.recCd[j] / (double)this.mice2new.recC[j];
/*  215 */         this.conPercentGraphicsPanel.updateContin(j * this.sampleInterval, percent);
/*  216 */         percent2 = (double)this.mice2new.recRd[j] / (double)this.mice2new.recR[j];
/*  217 */         this.resPercentGraphicsPanel.updateContin(j * this.sampleInterval, percent2);
/*      */         
/*  219 */         if (Double.isNaN(percent)) {
/*  220 */           this.conPercentGraphicsPanel.updateSample(j * this.sampleInterval, 0);
/*      */         } else {
/*  222 */           sam = (double)this.mice2new.recY[j] / (double)this.sampleSize;
/*  223 */           this.conPercentGraphicsPanel.updateSample(j * this.sampleInterval, sam);
/*      */         }
/*      */         
/*  226 */         if (Double.isNaN(percent2)) {
/*  227 */           this.resPercentGraphicsPanel.updateSample(j * this.sampleInterval, 0);
/*      */         } else {
/*  229 */           sam2 = (double)this.mice2new.recY[j] / (double)this.sampleSize;
/*  230 */           this.resPercentGraphicsPanel.updateSample(j * this.sampleInterval, sam2);
/*      */         }
/*      */         
/*  233 */         this.resTotalLabel.setText(String.valueOf(this.mice2new.recR[j]));
/*  234 */         this.conTotalLabel.setText(String.valueOf(this.mice2new.recC[j]));
/*  235 */         this.resDtypeLabel.setText(String.valueOf(this.mice2new.recRd[j]));
/*  236 */         this.resGtypeLabel.setText(String.valueOf(this.mice2new.recR[j] - this.mice2new.recRd[j]));
/*  237 */         this.conDtypeLabel.setText(String.valueOf(this.mice2new.recCd[j]));
/*  238 */         this.conGtypeLabel.setText(String.valueOf(this.mice2new.recC[j] - this.mice2new.recCd[j]));

/*  239 */         this.resPercentlLabel.setText(
/*  240 */           Util.Precision(100.0D * this.mice2new.recRd[j] / this.mice2new.recR[j], 1));
/*  241 */         this.conPercentlLabel.setText(
/*  242 */           Util.Precision(100.0D * this.mice2new.recCd[j] / this.mice2new.recC[j], 1));
/*  243 */         this.conSamplelLabel.setText(Util.Precision(100.0D * this.mice2new.recY[j] / this.sampleSize, 1));
/*      */         
/*  245 */         this.currentTimeValueTextField.setText(
/*  246 */           String.valueOf(Math.round(j * this.sampleInterval * 10000.0D) / 10000.0D));
/*      */         
/*  248 */         this.ContributingGraphicsPanel.numOfA = this.mice2new.recCd[j];
/*  249 */         this.ContributingGraphicsPanel.numOfB = (this.mice2new.recC[j] - this.mice2new.recCd[j]);
/*  250 */         this.ReserveGraphicsPanel.numOfA = this.mice2new.recRd[j];
/*  251 */         this.ReserveGraphicsPanel.numOfB = (this.mice2new.recR[j] - this.mice2new.recRd[j]);

/*  253 */         this.ReserveGraphicsPanel.repaint();
				   this.ContributingGraphicsPanel.repaint();
				   
				   this.resPercentGraphicsPanel.repaint();
				   this.conPercentGraphicsPanel.repaint();
				   
/*  256 */         j++;
/*      */       } else {
/*  258 */         int n = j;
/*  259 */         break;
/*      */       }
/*      */       
/*      */       try
/*      */       {
/*  264 */         Thread.currentThread();Thread.sleep(this.plottingDelayMilseconds);
/*      */       } catch (InterruptedException e) {
/*  266 */         e.printStackTrace();
/*      */       }
/*      */     }

/*  276 */     if (!this.useParaSameAsLastTimeBoolean) {
/*  277 */       int r1 = (int)(this.mice2new.random.nextDouble() * 1.0E9D);
/*  278 */       this.randomSeedTextField.setText(String.valueOf(Math.abs(r1)));
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  283 */     this.runPauseButton.setText("Run");
/*      */   }
/*      */   
/*      */   private JLabel sampleLabel;
/*      */   private JLabel sampleSizeLabel;
/*      */   private JTextField sampleSizeTextField;
/*      */   private JCheckBox samplingCheckbox;
/*      */   private JButton screenshotButton;
/*      */   private JLabel simLengthWeeksLabel;
/*      */   private JPanel statsPanel;
/*      */   private JScrollBar timeScrollBar;
/*      */   private JLabel totalWeeksLabel;

		     //add a simulation function for running in backstage
			 private void performSimulation_noExtSeed()
/*      */   {
/*  291 */     this.lambda = Double.parseDouble(this.lambdaTextField.getText());
/*  292 */     double lambdaA = Double.parseDouble(this.lambdaTextFieldA.getText());
/*  293 */     double lambdaB = Double.parseDouble(this.lambdaTextFieldB.getText());
/*  294 */     this.nu = Double.parseDouble(this.nuTextField.getText());
/*  295 */     double nuA = Double.parseDouble(this.nuTextFieldA.getText());
/*  296 */     double nuB = Double.parseDouble(this.nuTextFieldB.getText());
/*  297 */     this.mu = Double.parseDouble(this.muTextField.getText());
/*  298 */     double muA = Double.parseDouble(this.muTextFieldA.getText());
/*  299 */     double muB = Double.parseDouble(this.muTextFieldB.getText());
/*  300 */     this.alpha = Double.parseDouble(this.alphaTextField.getText());
/*  301 */     double alphaA = Double.parseDouble(this.alphaTextFieldA.getText());
/*  302 */     double alphaB = Double.parseDouble(this.alphaTextFieldB.getText());
/*      */     
/*  304 */     this.R0 = Integer.parseInt(this.intResTextField.getText());
/*  305 */     this.C0 = Integer.parseInt(this.intConTextField.getText());
/*  306 */     this.N = Integer.parseInt(this.maxCellTextField.getText());
/*  307 */     this.N2 = Integer.parseInt(this.maxCellTextField2.getText());
/*  308 */     this.sampleSize = Integer.parseInt(this.sampleSizeTextField.getText());
/*  309 */     this.sampleInterval = Double.parseDouble(this.sampleIntervalTextField.getText());
/*  310 */     this.percentR0a = Double.parseDouble(this.percentR0TextField.getText());
/*  311 */     this.percentC0a = Double.parseDouble(this.percentC0TextField.getText());

			   int newSeed = (int)(this.mice2new.random.nextDouble() * 1.0E9D);
/*  312 */     this.seed = Math.abs(newSeed);
/*      */     
/*  314 */     this.paused = false;
/*  315 */     this.L = (this.totalWeeks / (int)this.sampleInterval);
/*  316 */     int set = 1;
/*      */ 
/*  323 */     double mll = 1.0D;double mva = 1.0D;double dvv = 1.0D;double dvu = 1.0D;double ratio_as = 1.0D;
/*      */     double asd;
/*      */     double l;
/*  326 */     double v; double u; double a; double ld; double ad; double vd; double ud; double as; if (this.abDifference) {
/*  327 */        l = 1.0D / lambdaA;
/*  328 */        ld = 1.0D / lambdaB;
/*  329 */        v = 1.0D / nuA;
/*  330 */        vd = 1.0D / nuB;
/*  331 */        u = 1.0D / muA;
/*  332 */        a = 1.0D / alphaA;
/*  333 */        as = 0.0D;
/*  334 */        ad = 1.0D / alphaA;
/*  335 */        ud = 1.0D / muB;
/*  336 */       asd = as * ratio_as;
/*      */     } else {
/*  338 */       l = 1.0D / this.lambda;double lb = 0.0D;v = 1.0D / this.nu;u = 1.0D / this.mu;a = 1.0D / this.alpha;as = 0.0D;
/*  339 */       ld = l * mll;double ldb = 1.0D * mll;ad = a * mva;vd = v * dvv;ud = u * dvu;
/*  340 */       asd = as * ratio_as;
/*      */     }

/*  348 */     String[] events = { "B", "E", "D", "Ap" };
/*  349 */     double[] rates = { l, v, u, a, ld, vd, ud, ad };
/*      */     
/*  360 */     if (this.runRandomeMutationMode)
/*      */     {
/*  362 */       this.mice2new = new simulatorcore.Mice2mut(this.L, set, this.N, this.percentR0a / 100.0D, this.R0, this.percentC0a / 100.0D, this.C0, rates, 
/*  363 */         events, this.sampleSize, (int)this.seed, (int)this.sampleInterval, this.setCellChance, this.cellChanceRate, 
/*  364 */         this.maxCellConBoolean, this.N2, this.proportion, this.mutationProb, this.noUpperLimitRes);
/*      */     }
/*      */     else {
/*  367 */       this.mice2new = new Mice2new(this.L, set, this.N, this.percentR0a / 100.0D, this.R0, this.percentC0a / 100.0D, this.C0, rates, 
/*  368 */         events, this.sampleSize, (int)this.seed, (int)this.sampleInterval, this.setCellChance, this.cellChanceRate, 
/*  369 */         this.maxCellConBoolean, this.N2);
/*      */     }
/*  371 */     this.mice2new.writeResults2File = false;
/*  372 */     this.alreadyRun = true;
/*  373 */     this.mice2new.simulate("");
/*      */     
/*      */ 
/*  376 */     this.lastestRunParameters = new double[] { lambdaA, lambdaB, muA, muB, alphaA, alphaB, 
/*  377 */       nuA, nuB, this.cellChanceRate };
/*  378 */     if (this.displayParameters) {
/*  379 */       recordCurrentRunParameters(System.out);
/*      */     }
/*      */   }
/*      */   
/*      */   private void performSimulation()
/*      */   {
/*  291 */     this.lambda = Double.parseDouble(this.lambdaTextField.getText());
/*  292 */     double lambdaA = Double.parseDouble(this.lambdaTextFieldA.getText());
/*  293 */     double lambdaB = Double.parseDouble(this.lambdaTextFieldB.getText());
/*  294 */     this.nu = Double.parseDouble(this.nuTextField.getText());
/*  295 */     double nuA = Double.parseDouble(this.nuTextFieldA.getText());
/*  296 */     double nuB = Double.parseDouble(this.nuTextFieldB.getText());
/*  297 */     this.mu = Double.parseDouble(this.muTextField.getText());
/*  298 */     double muA = Double.parseDouble(this.muTextFieldA.getText());
/*  299 */     double muB = Double.parseDouble(this.muTextFieldB.getText());
/*  300 */     this.alpha = Double.parseDouble(this.alphaTextField.getText());
/*  301 */     double alphaA = Double.parseDouble(this.alphaTextFieldA.getText());
/*  302 */     double alphaB = Double.parseDouble(this.alphaTextFieldB.getText());
/*      */     
/*  304 */     this.R0 = Integer.parseInt(this.intResTextField.getText());
/*  305 */     this.C0 = Integer.parseInt(this.intConTextField.getText());
/*  306 */     this.N = Integer.parseInt(this.maxCellTextField.getText());
/*  307 */     this.N2 = Integer.parseInt(this.maxCellTextField2.getText());
/*  308 */     this.sampleSize = Integer.parseInt(this.sampleSizeTextField.getText());
/*  309 */     this.sampleInterval = Double.parseDouble(this.sampleIntervalTextField.getText());
/*  310 */     this.percentR0a = Double.parseDouble(this.percentR0TextField.getText());
/*  311 */     this.percentC0a = Double.parseDouble(this.percentC0TextField.getText());
/*  312 */     this.seed = Long.parseLong(this.randomSeedTextField.getText());
/*      */     
/*  314 */     this.paused = false;
/*  315 */     this.L = (this.totalWeeks / (int)this.sampleInterval);
/*  316 */     int set = 1;
/*      */ 
/*  323 */     double mll = 1.0D;double mva = 1.0D;double dvv = 1.0D;double dvu = 1.0D;double ratio_as = 1.0D;
/*      */     double asd;
/*      */     double l;
/*  326 */     double v; double u; double a; double ld; double ad; double vd; double ud; double as; if (this.abDifference) {
/*  327 */        l = 1.0D / lambdaA;
/*  328 */        ld = 1.0D / lambdaB;
/*  329 */        v = 1.0D / nuA;
/*  330 */        vd = 1.0D / nuB;
/*  331 */        u = 1.0D / muA;
/*  332 */        a = 1.0D / alphaA;
/*  333 */        as = 0.0D;
/*  334 */        ad = 1.0D / alphaA;
/*  335 */        ud = 1.0D / muB;
/*  336 */       asd = as * ratio_as;
/*      */     } else {
/*  338 */       l = 1.0D / this.lambda;double lb = 0.0D;v = 1.0D / this.nu;u = 1.0D / this.mu;a = 1.0D / this.alpha;as = 0.0D;
/*  339 */       ld = l * mll;double ldb = 1.0D * mll;ad = a * mva;vd = v * dvv;ud = u * dvu;
/*  340 */       asd = as * ratio_as;
/*      */     }

/*  348 */     String[] events = { "B", "E", "D", "Ap" };
/*  349 */     double[] rates = { l, v, u, a, ld, vd, ud, ad };
/*      */     
/*  360 */     if (this.runRandomeMutationMode)
/*      */     {
/*  362 */       this.mice2new = new simulatorcore.Mice2mut(this.L, set, this.N, this.percentR0a / 100.0D, this.R0, this.percentC0a / 100.0D, this.C0, rates, 
/*  363 */         events, this.sampleSize, (int)this.seed, (int)this.sampleInterval, this.setCellChance, this.cellChanceRate, 
/*  364 */         this.maxCellConBoolean, this.N2, this.proportion, this.mutationProb, this.noUpperLimitRes);
/*      */     }
/*      */     else {
/*  367 */       this.mice2new = new Mice2new(this.L, set, this.N, this.percentR0a / 100.0D, this.R0, this.percentC0a / 100.0D, this.C0, rates, 
/*  368 */         events, this.sampleSize, (int)this.seed, (int)this.sampleInterval, this.setCellChance, this.cellChanceRate, 
/*  369 */         this.maxCellConBoolean, this.N2);
/*      */     }
/*  371 */     this.mice2new.writeResults2File = false;
/*  372 */     this.alreadyRun = true;
/*  373 */     this.mice2new.simulate("");
/*      */     
/*      */ 
/*  376 */     this.lastestRunParameters = new double[] { lambdaA, lambdaB, muA, muB, alphaA, alphaB, 
/*  377 */       nuA, nuB, this.cellChanceRate };
/*  378 */     if (this.displayParameters) {
/*  379 */       recordCurrentRunParameters(System.out);
/*      */     }
/*      */   }
/*      */   
/*      */   private JLabel totalLabel;
/*      */   private JTextField totalWeeksTextField;
/*      */   private JLabel weekLabel1;
/*      */   private JLabel weekLabel2;
/*      */   private JLabel weekLabel3;
/*      */   
/*      */   private void setParamInits(String organism)
/*      */   {
/*  385 */     if (organism.equalsIgnoreCase("cat")) {
/*  386 */       this.lambdaInit = 10.0D;
/*  387 */       this.nuInit = 12.5D;
/*  388 */       this.muInit = 6.7D;
/*  389 */       this.alphaInit = 1000.0D;
/*  390 */       this.totalWeeks = 400;
/*  391 */       this.R0 = 30;
/*  392 */     } else if (organism.equalsIgnoreCase("mouse")) {
/*  393 */       this.lambdaInit = 2.5D;
/*  394 */       this.nuInit = 3.4D;
/*  395 */       this.muInit = 6.9D;
/*  396 */       this.alphaInit = 20.0D;
/*  397 */       this.totalWeeks = 100;
/*  398 */       this.R0 = 100; //Pro.Janis request 
				 
/*  399 */     } else if (organism.equalsIgnoreCase("baboon")) {
/*  400 */       this.lambdaInit = 36.0D;
/*  401 */       this.nuInit = 51.0D;
/*  402 */       this.muInit = 6.7D;
/*  403 */       this.alphaInit = 257.0D;
/*  404 */       this.totalWeeks = 400;
/*  405 */       this.R0 = 300;
/*  406 */     } else if (organism.equalsIgnoreCase("human")) {
/*  407 */       this.lambdaInit = 40.0D;
/*  408 */       this.nuInit = 56.0D;
/*  409 */       this.muInit = 10.0D;
/*  410 */       this.alphaInit = 285.0D;
/*  411 */       this.totalWeeks = 400;
/*  412 */       this.R0 = 200;
/*      */     }
/*      */     
/*  415 */     this.C0 = ((int)((double)this.R0 / (double)this.nuInit / (1.0D / (double)this.lambdaInit - 1.0D / (double)this.alphaInit - 1.0D / (double)this.nuInit + 1.0D / (double)this.muInit)));
/*      */     
/*  417 */     this.N = 10000;
/*  418 */     this.N2 = 10000;
/*  419 */     this.percentR0a = 50.0D;
/*  420 */     this.percentC0a = 50.0D;
/*      */   }
/*      */   
/*      */   private JLabel weekLabel4;
/*      */   private JLabel weekLabel6;
/*      */   private double lambda;
/*      */   private double nu;
/*      */   private double mu;
/*      */   private int R0;
/*      */   private int C0;
/*      */   private int N;
/*      */   private int sampleSize;
/*      */   
/*      */   private void setSliderInitValues()
/*      */   {
/*  426 */     this.lambdaSlider.setMinimum(this.lambdaLB * this.scale);
/*  427 */     this.lambdaSlider.setMaximum(this.lambdaUB * this.scale);
/*  428 */     this.lambdaSlider.setValue((int)(this.lambdaInit * this.scale)); // this must an integer
/*      */     
/*  430 */     this.lambdaSliderA.setMinimum(this.lambdaLB * this.scale);
/*  431 */     this.lambdaSliderA.setMaximum(this.lambdaUB * this.scale);
/*  432 */     this.lambdaSliderA.setValue((int)(this.lambdaInit * this.scale));
/*      */     
/*  434 */     this.lambdaSliderB.setMinimum(this.lambdaLB * this.scale);
/*  435 */     this.lambdaSliderB.setMaximum(this.lambdaUB * this.scale);
/*  436 */     this.lambdaSliderB.setValue((int)(this.lambdaInit * this.scale));
/*      */     
/*  438 */     this.nuSlider.setMinimum(this.nuLB * this.scale);
/*  439 */     this.nuSlider.setMaximum(this.nuUB * this.scale);
/*  440 */     this.nuSlider.setValue((int)(this.nuInit * this.scale));
/*      */     
/*  442 */     this.nuSliderA.setMinimum(this.nuLB * this.scale);
/*  443 */     this.nuSliderA.setMaximum(this.nuUB * this.scale);
/*  444 */     this.nuSliderA.setValue((int)(this.nuInit * this.scale));
/*      */     
/*  446 */     this.nuSliderB.setMinimum(this.nuLB * this.scale);
/*  447 */     this.nuSliderB.setMaximum(this.nuUB * this.scale);
/*  448 */     this.nuSliderB.setValue((int)(this.nuInit * this.scale));
/*      */     
/*  450 */     this.muSlider.setMinimum(this.muLB * this.scale);
/*  451 */     this.muSlider.setMaximum(this.muUB * this.scale);
/*  452 */     this.muSlider.setValue((int)(this.muInit * this.scale));
/*      */     
/*  454 */     this.muSliderA.setMinimum(this.muLB * this.scale);
/*  455 */     this.muSliderA.setMaximum(this.muUB * this.scale);
/*  456 */     this.muSliderA.setValue((int)(this.muInit * this.scale));
/*      */     
/*  458 */     this.muSliderB.setMinimum(this.muLB * this.scale);
/*  459 */     this.muSliderB.setMaximum(this.muUB * this.scale);
/*  460 */     this.muSliderB.setValue((int)(this.muInit * this.scale));
/*      */     
/*  462 */     this.alphaSlider.setMinimum(this.alphaLB * this.scale);
/*  463 */     this.alphaSlider.setMaximum(this.alphaUB * this.scale);
/*  464 */     this.alphaSlider.setValue((int)(this.alphaInit * this.scale));
/*      */     
/*  466 */     this.alphaSliderA.setMinimum(this.alphaLB * this.scale);
/*  467 */     this.alphaSliderA.setMaximum(this.alphaUB * this.scale);
/*  468 */     this.alphaSliderA.setValue((int)(this.alphaInit * this.scale));
/*      */     
/*  470 */     this.alphaSliderB.setMinimum(this.alphaLB * this.scale);
/*  471 */     this.alphaSliderB.setMaximum(this.alphaUB * this.scale);
/*  472 */     this.alphaSliderB.setValue((int)(this.alphaInit * this.scale));
/*      */     
/*  474 */     this.intResSlider.setMinimum(0);
/*  475 */     this.intResSlider.setMaximum(500);
/*  476 */     this.intResSlider.setValue(this.R0);
/*      */     
/*  478 */     this.intConSlider.setMinimum(0);
/*  479 */     setIntConSliderMax();
/*  480 */     this.intConSlider.setValue(this.C0);
/*      */     
/*  482 */     this.maxCellSlider.setMaximum(20000);
/*  483 */     this.maxCellSlider.setMinimum(0);
/*  484 */     this.maxCellSlider.setValue(this.N);
/*      */     
/*  486 */     this.maxCellSlider2.setMaximum(20000);
/*  487 */     this.maxCellSlider2.setMinimum(0);
/*  488 */     this.maxCellSlider2.setValue(this.N2);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  494 */     this.sampleIntervalTextField.setText(Double.toString(this.sampleInterval));
/*  495 */     this.percentR0TextField.setText(Double.toString(this.percentR0a));
/*  496 */     this.percentC0TextField.setText(Double.toString(this.percentC0a));
/*  497 */     this.totalWeeksTextField.setText(Integer.toString(this.totalWeeks));
/*      */   }
/*      */   
/*      */   private double alpha;
/*      */   private double sampleInterval;
/*      */   private int L;
/*      */   private double percentR0a;
/*      */   private double percentC0a;
/*      */   private long seed;
/*      */   private long plottingDelayMilseconds;
/*      */   private int resTotal;
/*      */   private int conTotal;
/*      */   private void setIntConSliderMax()
/*      */   {
/*  503 */     if (this.creaturesComboBox.getSelectedIndex() == 1) {
/*  504 */       this.intConSlider.setMaximum((int)(500.0D * this.muInit / this.nuInit));
/*      */     } else {
/*  506 */       this.intConSlider.setMaximum(500);
/*      */     }
/*      */   }
/*      */   
/*      */   private void initComponents()
/*      */   {
/*  512 */
/*      */     
/*  514 */
/*  515 */
/*  516 */
/*  517 */
/*  518 */
/*  519 */
/*  520 */
/*  521 */
/*  522 */
/*  523 */
/*  524 */
/*  525 */
/*  526 */
/*  527 */
/*  528 */
/*  529 */
/*  530 */
/*  531 */
/*  532 */
/*  533 */
/*  534 */
/*  535 */
/*  536 */
/*  537 */
/*  538 */
/*  539 */
/*  540 */
/*  541 */
/*  542 */
/*  543 */
/*  544 */
/*  545 */
/*  546 */
/*  547 */
/*  548 */
/*  549 */
/*  550 */
/*  551 */
/*      */     
/*      */ 
/*  554 */
/*  555 */
/*  556 */
/*  557 */
/*      */     
/*  559 */
/*  560 */
/*  561 */
/*  562 */
/*  563 */
/*  564 */
/*  565 */
/*  566 */
/*  567 */
/*  568 */
/*  569 */
/*  570 */     this.lambdaSliderB = new JSlider();
/*  571 */     this.lambdaLabelB = new JLabel();
/*  572 */     this.lambdaLabelA = new JLabel();
/*  573 */     this.lambdaSliderA = new JSlider();
/*  574 */     this.lambdaTextFieldA = new JTextField(6);
/*  575 */     this.lambdaTextFieldB = new JTextField(6);
/*  576 */     this.muLabelA = new JLabel();
/*  577 */     this.muLabelB = new JLabel();
/*  578 */     this.alphaLabelA = new JLabel();
/*  579 */     this.alphaLabelB = new JLabel();
/*  580 */     this.alphaSliderA = new JSlider();
/*  581 */     this.alphaTextFieldA = new JTextField(6);
/*  582 */     this.alphaSliderB = new JSlider();
/*  583 */     this.alphaTextFieldB = new JTextField(6);
/*  584 */     this.muSliderA = new JSlider();
/*  585 */     this.muTextFieldA = new JTextField(6);
/*  586 */     this.muSliderB = new JSlider();
/*  587 */     this.muTextFieldB = new JTextField(6);
/*  601 */     this.resPercentGraphicsPanel = new PlotCanvasBean2();
/*  602 */
/*  603 */
/*  604 */
/*  605 */
/*  606 */
/*  607 */
/*  608 */
/*  609 */
/*  610 */
/*  611 */
/*  612 */
/*  613 */
/*  614 */
/*  615 */
/*  616 */
/*  617 */
/*  618 */
/*  619 */
/*  620 */
/*  621 */
/*  622 */
/*  623 */
/*  624 */
/*  625 */
/*      */     
/*  627 */     this.nuLabelA = new JLabel();
/*  628 */     this.nuLabelB = new JLabel();
/*  629 */     this.nuSliderA = new JSlider();
/*  630 */     this.nuSliderB = new JSlider();
/*  631 */     this.nuTextFieldA = new JTextField(6);
/*  632 */     this.nuTextFieldB = new JTextField(6);
/*  633 */
/*  634 */
/*  635 */
/*  636 */
/*  637 */
/*  638 */
/*  639 */
/*  640 */
/*  641 */
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  647 */     this.menuBar = new JMenuBar();
/*      */     
/*  649 */     this.menu = new JMenu("Options");
/*  650 */     this.menu.setMnemonic(79);
/*  651 */     this.menu.getAccessibleContext().setAccessibleDescription("More Options");
/*  652 */     this.menuBar.add(this.menu);
/*      */     
/*      */ 
/*  655 */     this.menuItem1 = new JMenuItem("Export results as R file");
/*  656 */     this.menuItem1.addActionListener(new ActionListener() {
/*      */       public void actionPerformed(ActionEvent evt) {
/*  658 */         StatFrame2.this.exportResultsToRButtonActionPerformed(evt);
/*      */       }
/*  660 */     });
/*  661 */     this.menu.add(this.menuItem1);
/*  662 */     this.menu.addSeparator();
/*      */     
/*  664 */     this.subMenu1 = new JMenu("Multiple runs:");
/*  665 */     this.menuItem2 = new JMenuItem("Export results as TXT file");
/*  666 */     this.menuItem2.addActionListener(new ActionListener() {
/*      */       public void actionPerformed(ActionEvent evt) {
/*  668 */         StatFrame2.this.multipleRunsExportToTXTButtonActionPerformed(evt);
/*      */       }
/*  670 */     });
/*  671 */     this.subMenu1.add(this.menuItem2);
/*      */     
/*  673 */     this.menuItem3 = new JMenuItem("Export results as R file");
/*  674 */     this.menuItem3.addActionListener(new ActionListener() {
/*      */       public void actionPerformed(ActionEvent evt) {
/*  676 */         StatFrame2.this.multipleRunsExportToRButtonActionPerformed(evt);
/*      */       }
/*  678 */     });
/*  679 */     this.subMenu1.add(this.menuItem3);
/*  680 */     this.menu.add(this.subMenu1);
/*      */     
/*  682 */     this.menu = new JMenu("Cell Mutation");
/*  683 */     this.menu.setMnemonic(77);
/*  684 */     this.menu.getAccessibleContext().setAccessibleDescription("Setting for Mutated Cells");
/*  685 */     this.menuBar.add(this.menu);
/*      */     
/*  687 */     this.subMenu1 = new JMenu("Mutation Probability of Regular Cells:");
/*  688 */     ButtonGroup group1 = new ButtonGroup();
/*  689 */     this.radioButtonMenuItem1 = new JRadioButtonMenuItem("1/1000");
/*  690 */     this.radioButtonMenuItem1.addItemListener(new ItemListener() {
/*      */       public void itemStateChanged(ItemEvent event) {
/*  692 */         StatFrame2.this.setMutationProb();
/*      */       }
/*  694 */     });
/*  695 */     this.radioButtonMenuItem1.setSelected(true);
/*  696 */     group1.add(this.radioButtonMenuItem1);
/*  697 */     this.subMenu1.add(this.radioButtonMenuItem1);
/*  698 */     this.radioButtonMenuItem2 = new JRadioButtonMenuItem("1/100");
/*  699 */     this.radioButtonMenuItem2.addItemListener(new ItemListener() {
/*      */       public void itemStateChanged(ItemEvent event) {
/*  701 */         StatFrame2.this.setMutationProb();
/*      */       }
/*  703 */     });
/*  704 */     group1.add(this.radioButtonMenuItem2);
/*  705 */     this.subMenu1.add(this.radioButtonMenuItem2);
/*  706 */     this.menu.add(this.subMenu1);
/*      */     
/*      */ 
/*  709 */     this.subMenu2 = new JMenu("Mutation Change Proportion:");
/*  710 */     this.subMenu2.getAccessibleContext().setAccessibleDescription("Mutated cell with brith rate (rate of parental cell * ( 1 + epsilon)), whereepsilon ~ Unif(0, mutation change rate)");
/*      */     
/*      */ 
/*  713 */     ButtonGroup group2 = new ButtonGroup();
/*  714 */     this.radioButtonMenuItem3 = new JRadioButtonMenuItem("1/1000");
/*  715 */     this.radioButtonMenuItem3.setSelected(true);
/*  716 */     this.radioButtonMenuItem3.addItemListener(new ItemListener() {
/*      */       public void itemStateChanged(ItemEvent event) {
/*  718 */         StatFrame2.this.setChangeProportion();
/*      */       }
/*  720 */     });
/*  721 */     group2.add(this.radioButtonMenuItem3);
/*  722 */     this.subMenu2.add(this.radioButtonMenuItem3);
/*  723 */     this.radioButtonMenuItem4 = new JRadioButtonMenuItem("1/100");
/*  724 */     this.radioButtonMenuItem4.addItemListener(new ItemListener() {
/*      */       public void itemStateChanged(ItemEvent event) {
/*  726 */         StatFrame2.this.setChangeProportion();
/*      */       }
/*  728 */     });
/*  729 */     group2.add(this.radioButtonMenuItem4);
/*  730 */     this.subMenu2.add(this.radioButtonMenuItem4);
/*  731 */     this.menu.add(this.subMenu2);
/*      */     
/*  733 */     this.checkBoxMenuItem1 = new JCheckBoxMenuItem("No upper limit in Reserve compartment");
/*  734 */     this.checkBoxMenuItem1.setSelected(false);
/*  735 */     this.checkBoxMenuItem1.addActionListener(new ActionListener() {
/*      */       public void actionPerformed(ActionEvent evt) {
/*  737 */         StatFrame2.this.noUpperLimitRes = (!StatFrame2.this.checkBoxMenuItem1.isSelected());
/*      */       }
/*  739 */     });
/*  740 */     this.menu.add(this.checkBoxMenuItem1);
/*      */     
/*  742 */     this.menu.addSeparator();
/*      */     
/*  744 */     this.menuItem4 = new JMenuItem("Click to run Random Mutation Mode");
/*  745 */     this.menuItem4.getAccessibleContext().setAccessibleDescription("Clickto run Random Mutation Mode; using human parameter as default");
/*      */     
/*  747 */     this.menuItem4.addActionListener(new ActionListener() {
/*      */       public void actionPerformed(ActionEvent evt) {
				   
	               clearButtonActionPerformed(null);
/*  749 */         StatFrame2.this.runRandomeMutationMode = true;
/*  750 */         StatFrame2.this.run();
/*  751 */         StatFrame2.this.runRandomeMutationMode = false;
/*      */       }
/*  753 */     });
/*  754 */     this.menu.add(this.menuItem4);
/*      */     
/*  756 */     setJMenuBar(this.menuBar);
/*  761 */     setDefaultCloseOperation(3);
/*  762 */     setBackground(new Color(153, 255, 153));
/* 1229 */     setJPanel5();
/* 1230 */     GridBagLayout gridBagLayout = new GridBagLayout();

     gridBagLayout.columnWidths = new int[]{397, 350, 140, 0};
     gridBagLayout.rowHeights = new int[]{370, 220, 0};
     gridBagLayout.columnWeights = new double[]{1.0, 1.0, 1.0, Double.MIN_VALUE};
     gridBagLayout.rowWeights = new double[]{1.0, 1.0, Double.MIN_VALUE};
     getContentPane().setLayout(gridBagLayout);
     
     
/*      */     
/* 1232 */
/* 1233 */
/* 1234 */
/*      */     
/* 1236 */
/* 1238 */
/* 1244 */
/* 1245 */
/* 1246 */
/* 1252 */
/* 1253 */
/* 1254 */
/* 1260 */
/* 1261 */
/* 1262 */
/* 1263 */
/* 1269 */
/* 1270 */
/* 1271 */
/* 1277 */     this.jTabbedPane1 = new JTabbedPane();
     this.initParamPanel = new JPanel();
     this.r0Label = new JLabel();
     this.c0Label = new JLabel();
     this.kLabel = new JLabel();
     this.intResSlider = new JSlider();
     this.intConSlider = new JSlider();
     this.maxCellSlider = new JSlider();
     this.intResTextField = new JTextField();
     intResTextField.setColumns(5);
     intResTextField.setHorizontalAlignment(SwingConstants.LEFT);
     this.intConTextField = new JTextField();
     intConTextField.setColumns(5);
     intConTextField.setHorizontalAlignment(SwingConstants.LEFT);
     this.maxCellTextField = new JTextField();
     maxCellTextField.setColumns(5);
     maxCellTextField.setHorizontalAlignment(SwingConstants.LEFT);
     this.percentR0Label = new JLabel();
     this.percentC0Label = new JLabel();
     this.percentR0TextField = new JTextField();
     this.percentC0TextField = new JTextField();
     this.totalWeeksLabel = new JLabel();
     this.sampleIntervalLabel = new JLabel();
     this.totalWeeksTextField = new JTextField();
     totalWeeksTextField.setColumns(10);
     totalWeeksTextField.setHorizontalAlignment(SwingConstants.LEFT);
     this.sampleIntervalTextField = new JTextField();
     sampleIntervalTextField.setColumns(10);
     sampleIntervalTextField.setHorizontalAlignment(SwingConstants.LEFT);
     this.simLengthWeeksLabel = new JLabel();
     this.obsLengthWeeksLabel = new JLabel();
     this.randomSeedLabel = new JLabel();
     this.sampleSizeLabel = new JLabel();
     this.randomSeedTextField = new JTextField();
     randomSeedTextField.setColumns(10);
     randomSeedTextField.setHorizontalAlignment(SwingConstants.LEFT);
     this.sampleSizeTextField = new JTextField();
     sampleSizeTextField.setColumns(10);
     sampleSizeTextField.setHorizontalAlignment(SwingConstants.LEFT);
     this.samplingCheckbox = new JCheckBox();
     this.ratesPanel = new JPanel();
     this.lambdaLabel = new JLabel();
     lambdaLabel.setText("\u03BB");
     this.nuLabel = new JLabel();
     this.alphaLabel = new JLabel();
     this.muLabel = new JLabel();
     this.lambdaSlider = new JSlider();
     this.nuSlider = new JSlider();
     this.alphaSlider = new JSlider();
     this.muSlider = new JSlider();
     this.perLabel1 = new JLabel();
     this.perLabel2 = new JLabel();
     this.perLabel3 = new JLabel();
     this.perLabel4 = new JLabel();
     this.lambdaTextField = new JTextField(6);
     this.nuTextField = new JTextField(6);
     this.alphaTextField = new JTextField(6);
     this.muTextField = new JTextField(6);
     this.weekLabel1 = new JLabel();
     this.weekLabel2 = new JLabel();
     this.weekLabel3 = new JLabel();
     this.weekLabel4 = new JLabel();
     this.lambdaNuRatioLabel = new JLabel();
     this.nuMuRatioLabel = new JLabel();
     this.lambdaNuRatioTextField = new JLabel();
     this.nuMuRatioTextField = new JLabel();
     this.jPanel4 = new JPanel();
     this.cellChance = new JCheckBox();
     this.abDiffBox = new JCheckBox();
     this.jPanel5 = new JPanel();
     this.maxCellConCheckBox = new JCheckBox();
     this.kLabel2 = new JLabel();
     this.maxCellSlider2 = new JSlider();
     this.maxCellTextField2 = new JTextField();
     maxCellTextField2.setColumns(5);
     maxCellTextField2.setHorizontalAlignment(SwingConstants.LEFT);
     this.jTabbedPane1.setBackground(new Color(153, 255, 153));
     this.jTabbedPane1.setBorder(BorderFactory.createTitledBorder(
/*  768 */       BorderFactory.createLineBorder(new Color(0, 0, 0)), 
/*  769 */       "Parameters", 0, 
/*  770 */       0, 
/*  771 */       new Font("Arial", 3, 18)));
     this.initParamPanel.setBackground(new Color(153, 255, 153));
     this.r0Label.setFont(new Font("Tahoma", 1, 14));
     this.r0Label.setText("R0");
     this.c0Label.setFont(new Font("Tahoma", 1, 14));
     this.c0Label.setText("C0");
     this.kLabel.setFont(new Font("Tahoma", 1, 14));
     this.kLabel.setText("K_R");
     this.kLabel2.setFont(new Font("Tahoma", 1, 14));
     this.kLabel2.setText("K_C");
     this.kLabel2.setVisible(false);
     this.intResSlider.setBackground(new Color(153, 255, 153));
     this.intResSlider.addChangeListener(new ChangeListener() {
/*      */       public void stateChanged(ChangeEvent evt) {
/*  798 */         StatFrame2.this.intResSliderStateChanged(evt);
/*      */       }
/*      */       
/*  801 */     });
     this.intConSlider.setBackground(new Color(153, 255, 153));
     this.intConSlider.addChangeListener(new ChangeListener() {
/*      */       public void stateChanged(ChangeEvent evt) {
/*  805 */         StatFrame2.this.intConSliderStateChanged(evt);
/*      */       }
/*      */       
/*  808 */     });
     this.maxCellSlider.setBackground(new Color(153, 255, 153));
     this.maxCellSlider.addChangeListener(new ChangeListener() {
/*      */       public void stateChanged(ChangeEvent evt) {
/*  812 */         StatFrame2.this.maxCellSliderStateChanged(evt);
/*      */       }
/*      */       
/*  815 */     });
     this.maxCellSlider2.setBackground(new Color(153, 255, 153));
     this.maxCellSlider2.addChangeListener(new ChangeListener()
/*      */     {
/*  819 */       public void stateChanged(ChangeEvent evt) { StatFrame2.this.maxCellTextField2.setText(String.valueOf(StatFrame2.this.maxCellSlider2.getValue())); }
/*  820 */     });
     this.maxCellSlider2.setVisible(false);
     this.intResTextField.addActionListener(new ActionListener() {
/*      */       public void actionPerformed(ActionEvent evt) {
/*  825 */         StatFrame2.this.intResTextFieldActionPerformed(evt);
/*      */       }
/*      */       
/*  828 */     });
     this.intConTextField.addActionListener(new ActionListener() {
/*      */       public void actionPerformed(ActionEvent evt) {
/*  831 */         StatFrame2.this.intConTextFieldActionPerformed(evt);
/*      */       }
/*      */       
/*  834 */     });
     this.maxCellTextField.addActionListener(new ActionListener() {
/*      */       public void actionPerformed(ActionEvent evt) {
/*  837 */         StatFrame2.this.maxCellTextFieldActionPerformed(evt);
/*      */       }
/*      */       
/*  840 */     });
     this.maxCellTextField2.addActionListener(new ActionListener() {
/*      */       public void actionPerformed(ActionEvent evt) {
/*  843 */         StatFrame2.this.maxCellTextField2ActionPerformed(evt);
/*      */       }
/*  845 */     });
     this.maxCellTextField2.setVisible(false);
     this.percentR0Label.setFont(new Font("Tahoma", 1, 14));
     this.percentR0Label.setText("R0-a %");
     this.percentC0Label.setFont(new Font("Tahoma", 1, 14));
     this.percentC0Label.setText("C0-a %");
     this.percentR0TextField.addActionListener(new ActionListener() {
/*      */       public void actionPerformed(ActionEvent evt) {
/*  856 */         StatFrame2.this.percentR0TextFieldActionPerformed(evt);
/*      */       }
/*      */       
/*  859 */     });
     this.percentC0TextField.addActionListener(new ActionListener() {
/*      */       public void actionPerformed(ActionEvent evt) {
/*  862 */         StatFrame2.this.percentC0TextFieldActionPerformed(evt);
/*      */       }
/*      */       
/*  865 */     });
     this.totalWeeksLabel.setFont(new Font("Tahoma", 1, 12));
     this.totalWeeksLabel.setText("Simulation Length:");
     this.sampleIntervalLabel.setFont(new Font("Tahoma", 1, 12));
     this.sampleIntervalLabel.setText("Observation Interval:");
     this.totalWeeksTextField.addActionListener(new ActionListener() {
/*      */       public void actionPerformed(ActionEvent evt) {
/*  874 */         StatFrame2.this.totalWeeksTextFieldActionPerformed(evt);
/*      */       }
/*      */       
/*  877 */     });
     this.sampleIntervalTextField.addActionListener(new ActionListener() {
/*      */       public void actionPerformed(ActionEvent evt) {
/*  880 */         StatFrame2.this.sampleIntervalTextFieldActionPerformed(evt);
/*      */       }
/*      */       
/*  883 */     });
     this.simLengthWeeksLabel.setFont(new Font("Tahoma", 1, 12));
     this.simLengthWeeksLabel.setText("weeks");
     this.obsLengthWeeksLabel.setFont(new Font("Tahoma", 1, 12));
     this.obsLengthWeeksLabel.setText("weeks");
     this.randomSeedLabel.setFont(new Font("Tahoma", 1, 12));
     this.randomSeedLabel.setText("Random Seed:");
     this.sampleSizeLabel.setFont(new Font("Tahoma", 1, 12));
     this.sampleSizeLabel.setText("Sample Size:");
     this.randomSeedTextField.addActionListener(new ActionListener() {
/*      */       public void actionPerformed(ActionEvent evt) {
/*  898 */         StatFrame2.this.randomSeedTextFieldActionPerformed(evt);
/*      */       }
/*      */       
/*  901 */     });
     this.sampleSizeTextField.setText("70");
     this.sampleSizeTextField.addActionListener(new ActionListener() {
/*      */       public void actionPerformed(ActionEvent evt) {
/*  905 */         StatFrame2.this.sampleSizeTextFieldActionPerformed(evt);
/*      */       }
/*      */       
/*  908 */     });
     this.samplingCheckbox.setBackground(new Color(153, 255, 153));
     this.samplingCheckbox.setFont(new Font("Tahoma", 1, 12));
     this.samplingCheckbox.setText("Sampling");
     this.samplingCheckbox.addActionListener(new ActionListener() {
/*      */       public void actionPerformed(ActionEvent evt) {
/*  914 */         StatFrame2.this.samplingCheckboxActionPerformed(evt);
/*      */       }
/*      */       
/*  917 */     });
     this.maxCellConCheckBox.setBackground(new Color(153, 255, 153));
     this.maxCellConCheckBox.setFont(new Font("Tahoma", 1, 12));
     this.maxCellConCheckBox.setText("Max Cells in Con.");
     this.maxCellConCheckBox.addActionListener(new ActionListener() {
/*      */       public void actionPerformed(ActionEvent evt) {
/*  923 */         StatFrame2.this.maxCellConCheckboxActionPerformed(evt);
/*      */       }
/*      */       
/*  926 */     });
     
     setAdvanceOptionsJTabbedPanel();
     
     GroupLayout initParamPanelLayout = new GroupLayout(this.initParamPanel);
     initParamPanelLayout.setHorizontalGroup(
     	initParamPanelLayout.createParallelGroup(Alignment.LEADING)
     		.addGroup(initParamPanelLayout.createSequentialGroup()
     			.addGroup(initParamPanelLayout.createParallelGroup(Alignment.LEADING, false)
     				.addGroup(initParamPanelLayout.createSequentialGroup()
     					.addContainerGap()
     					.addGroup(initParamPanelLayout.createParallelGroup(Alignment.LEADING)
     						.addComponent(randomSeedLabel, Alignment.TRAILING)
     						.addComponent(sampleSizeLabel, Alignment.TRAILING)
     						.addComponent(sampleIntervalLabel, Alignment.TRAILING)
     						.addComponent(totalWeeksLabel, Alignment.TRAILING))
     					.addPreferredGap(ComponentPlacement.RELATED)
     					.addGroup(initParamPanelLayout.createParallelGroup(Alignment.LEADING)
     						.addComponent(sampleSizeTextField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
     						.addComponent(randomSeedTextField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
     						.addGroup(initParamPanelLayout.createSequentialGroup()
     							.addComponent(sampleIntervalTextField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
     							.addPreferredGap(ComponentPlacement.RELATED)
     							.addComponent(obsLengthWeeksLabel))
     						.addGroup(initParamPanelLayout.createSequentialGroup()
     							.addComponent(totalWeeksTextField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
     							.addPreferredGap(ComponentPlacement.RELATED)
     							.addComponent(simLengthWeeksLabel))))
     				.addGroup(initParamPanelLayout.createSequentialGroup()
     					.addGap(12)
     					.addGroup(initParamPanelLayout.createParallelGroup(Alignment.LEADING)
     						.addComponent(kLabel, Alignment.TRAILING)
     						.addComponent(kLabel2, Alignment.TRAILING)
     						.addComponent(c0Label, Alignment.TRAILING)
     						.addComponent(r0Label, Alignment.TRAILING))
     					.addPreferredGap(ComponentPlacement.RELATED)
     					.addGroup(initParamPanelLayout.createParallelGroup(Alignment.LEADING)
     						.addGroup(initParamPanelLayout.createSequentialGroup()
     							.addGroup(initParamPanelLayout.createParallelGroup(Alignment.LEADING)
     								.addGroup(initParamPanelLayout.createSequentialGroup()
     									.addComponent(intResSlider, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
     									.addPreferredGap(ComponentPlacement.RELATED)
     									.addComponent(intResTextField, GroupLayout.PREFERRED_SIZE, 27, GroupLayout.PREFERRED_SIZE))
     								.addGroup(initParamPanelLayout.createSequentialGroup()
     									.addComponent(intConSlider, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
     									.addPreferredGap(ComponentPlacement.RELATED)
     									.addComponent(intConTextField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
     								.addGroup(initParamPanelLayout.createSequentialGroup()
     									.addComponent(maxCellSlider2, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
     									.addPreferredGap(ComponentPlacement.RELATED)
     									.addComponent(maxCellTextField2, GroupLayout.PREFERRED_SIZE, 27, GroupLayout.PREFERRED_SIZE)))
     							.addGap(44)
     							.addGroup(initParamPanelLayout.createParallelGroup(Alignment.LEADING, false)
     								.addGroup(initParamPanelLayout.createSequentialGroup()
     									.addComponent(percentR0Label)
     									.addPreferredGap(ComponentPlacement.RELATED)
     									.addComponent(percentR0TextField, 70, 70, 70))
     								.addGroup(initParamPanelLayout.createSequentialGroup()
     									.addComponent(percentC0Label)
     									.addPreferredGap(ComponentPlacement.RELATED)
     									.addComponent(percentC0TextField))
     								.addComponent(maxCellConCheckBox, GroupLayout.PREFERRED_SIZE, 131, GroupLayout.PREFERRED_SIZE)))
     						.addGroup(initParamPanelLayout.createSequentialGroup()
     							.addComponent(maxCellSlider, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
     							.addPreferredGap(ComponentPlacement.RELATED)
     							.addGroup(initParamPanelLayout.createParallelGroup(Alignment.LEADING, false)
     								.addComponent(maxCellTextField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
     								.addGroup(initParamPanelLayout.createSequentialGroup()
     									.addGap(81)
     									.addComponent(samplingCheckbox)))
     							.addGap(50)))))
     			.addContainerGap())
     );
     initParamPanelLayout.setVerticalGroup(
     	initParamPanelLayout.createParallelGroup(Alignment.LEADING)
     		.addGroup(initParamPanelLayout.createSequentialGroup()
     			.addContainerGap()
     			.addGroup(initParamPanelLayout.createParallelGroup(Alignment.LEADING)
     				.addGroup(initParamPanelLayout.createSequentialGroup()
     					.addGroup(initParamPanelLayout.createParallelGroup(Alignment.LEADING)
     						.addComponent(r0Label)
     						.addComponent(intResSlider, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
     						.addComponent(intResTextField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
     					.addPreferredGap(ComponentPlacement.RELATED)
     					.addGroup(initParamPanelLayout.createParallelGroup(Alignment.LEADING)
     						.addComponent(c0Label)
     						.addComponent(intConSlider, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
     						.addComponent(intConTextField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
     					.addPreferredGap(ComponentPlacement.RELATED)
     					.addGroup(initParamPanelLayout.createParallelGroup(Alignment.LEADING)
     						.addComponent(maxCellTextField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
     						.addComponent(maxCellSlider, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
     						.addComponent(kLabel))
     					.addPreferredGap(ComponentPlacement.RELATED)
     					.addGroup(initParamPanelLayout.createParallelGroup(Alignment.LEADING, false)
     						.addComponent(kLabel2)
     						.addComponent(maxCellTextField2, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
     						.addComponent(maxCellSlider2, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
     					.addGap(18)
     					.addGroup(initParamPanelLayout.createParallelGroup(Alignment.BASELINE)
     						.addComponent(totalWeeksLabel)
     						.addComponent(totalWeeksTextField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
     						.addComponent(simLengthWeeksLabel))
     					.addPreferredGap(ComponentPlacement.RELATED)
     					.addGroup(initParamPanelLayout.createParallelGroup(Alignment.BASELINE)
     						.addComponent(sampleIntervalLabel)
     						.addComponent(sampleIntervalTextField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
     						.addComponent(obsLengthWeeksLabel))
     					.addPreferredGap(ComponentPlacement.RELATED)
     					.addGroup(initParamPanelLayout.createParallelGroup(Alignment.BASELINE)
     						.addComponent(randomSeedLabel)
     						.addComponent(randomSeedTextField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)))
     				.addGroup(initParamPanelLayout.createSequentialGroup()
     					.addGroup(initParamPanelLayout.createParallelGroup(Alignment.BASELINE)
     						.addComponent(percentR0Label)
     						.addComponent(percentR0TextField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
     					.addPreferredGap(ComponentPlacement.RELATED)
     					.addGroup(initParamPanelLayout.createParallelGroup(Alignment.BASELINE)
     						.addComponent(percentC0Label)
     						.addComponent(percentC0TextField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
     					.addGap(38)
     					.addGroup(initParamPanelLayout.createSequentialGroup()
     						.addGap(1)
     						.addComponent(maxCellConCheckBox))))
     			.addGap(6)
     			.addGroup(initParamPanelLayout.createParallelGroup(Alignment.BASELINE)
     				.addComponent(sampleSizeLabel)
     				.addComponent(sampleSizeTextField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
     				.addComponent(samplingCheckbox, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
     			.addGap(77))
     );
     initParamPanelLayout.linkSize(SwingConstants.HORIZONTAL, new Component[] {intResTextField, intConTextField, maxCellTextField, totalWeeksTextField, sampleIntervalTextField, randomSeedTextField, sampleSizeTextField, maxCellTextField2});
     this.initParamPanel.setLayout(initParamPanelLayout);
     this.jTabbedPane1.addTab("Basic", this.initParamPanel);
     this.ratesPanel.setBackground(new Color(153, 255, 153));
     this.lambdaLabel.setFont(new Font("Tahoma", 1, 14));
     this.nuLabel.setFont(new Font("Tahoma", 1, 14));
     this.nuLabel.setText("\u03BD");
     this.alphaLabel.setFont(new Font("Tahoma", 1, 14));
     this.alphaLabel.setText("\u03B1");
     this.muLabel.setFont(new Font("Tahoma", 1, 14));
     this.muLabel.setText("\u03BC");
     this.lambdaSlider.setBackground(new Color(153, 255, 153));
     this.lambdaSlider.addChangeListener(new ChangeListener() {
/*      */       public void stateChanged(ChangeEvent evt) {
/* 1071 */         StatFrame2.this.lambdaSliderStateChanged(evt);
/*      */       }
/*      */       
/* 1074 */     });
     this.nuSlider.setBackground(new Color(153, 255, 153));
     this.nuSlider.addChangeListener(new ChangeListener() {
/*      */       public void stateChanged(ChangeEvent evt) {
/* 1078 */         StatFrame2.this.nuSliderStateChanged(evt);
/*      */       }
/*      */       
/* 1081 */     });
     this.alphaSlider.setBackground(new Color(153, 255, 153));
     this.alphaSlider.addChangeListener(new ChangeListener() {
/*      */       public void stateChanged(ChangeEvent evt) {
/* 1085 */         StatFrame2.this.alphaSliderStateChanged(evt);
/*      */       }
/*      */       
/* 1088 */     });
     this.muSlider.setBackground(new Color(153, 255, 153));
     this.muSlider.addChangeListener(new ChangeListener() {
/*      */       public void stateChanged(ChangeEvent evt) {
/* 1092 */         StatFrame2.this.muSliderStateChanged(evt);
/*      */       }
/*      */       
/* 1095 */     });
     this.perLabel1.setFont(new Font("Tahoma", 0, 14));
     this.perLabel1.setText("1 per");
     this.perLabel2.setFont(new Font("Tahoma", 0, 14));
     this.perLabel2.setText("1 per");
     this.perLabel3.setFont(new Font("Tahoma", 0, 14));
     this.perLabel3.setText("1 per");
     this.perLabel4.setFont(new Font("Tahoma", 0, 14));
     this.perLabel4.setText("1 per");
     this.lambdaTextField.setText("10");
     this.lambdaTextField.addActionListener(new ActionListener() {
/*      */       public void actionPerformed(ActionEvent evt) {
/* 1108 */         StatFrame2.this.lambdaTextFieldActionPerformed(evt);
/*      */       }
/*      */       
/* 1111 */     });
     this.nuTextField.setText("12.5");
     this.nuTextField.addActionListener(new ActionListener() {
/*      */       public void actionPerformed(ActionEvent evt) {
/* 1115 */         StatFrame2.this.nuTextFieldActionPerformed(evt);
/*      */       }
/*      */       
/* 1118 */     });
     this.alphaTextField.setText("0.0001");
     this.alphaTextField.addActionListener(new ActionListener() {
/*      */       public void actionPerformed(ActionEvent evt) {
/* 1122 */         StatFrame2.this.alphaTextFieldActionPerformed(evt);
/*      */       }
/*      */       
/* 1125 */     });
     this.muTextField.setText("6.7");
     this.muTextField.addActionListener(new ActionListener() {
/*      */       public void actionPerformed(ActionEvent evt) {
/* 1129 */         StatFrame2.this.muTextFieldActionPerformed(evt);
/*      */       }
/*      */       
/* 1132 */     });
     this.jPanel2 = new JPanel();
     this.percentG6PDLabel = new JLabel();
     this.currentTimeLabel = new JLabel();
     this.weekLabel6 = new JLabel();
     this.contributingCompLabel = new JLabel();
     this.timeScrollBar = new JScrollBar();
     this.conPercentGraphicsPanel = new PlotCanvasBean();
     this.currentTimeValueTextField = new JTextField();
     this.plotComboBox = new JComboBox();
     this.jPanel2.setBackground(new Color(153, 255, 153));
     this.jPanel2.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0)));
     this.percentG6PDLabel.setHorizontalAlignment(0);
     this.percentG6PDLabel.setText("Percent Type a Cells");
     this.currentTimeLabel.setHorizontalAlignment(0);
     this.currentTimeLabel.setText("Current Time:");
     this.weekLabel6.setHorizontalAlignment(0);
     this.weekLabel6.setText("weeks");
     this.contributingCompLabel.setFont(new Font("Tahoma", 1, 14));
     this.contributingCompLabel.setHorizontalAlignment(0);
     this.contributingCompLabel.setText("Contributing Compartment");
     this.timeScrollBar.setBackground(new Color(204, 204, 204));
     this.timeScrollBar.setMaximum(1000000);
     this.timeScrollBar.setOrientation(0);
     this.timeScrollBar.setVisibleAmount(1);
     this.timeScrollBar.setAutoscrolls(true);
     this.timeScrollBar.setDoubleBuffered(true);
     this.timeScrollBar.addAdjustmentListener(new java.awt.event.AdjustmentListener() {
/*      */       public void adjustmentValueChanged(AdjustmentEvent evt) {
/* 1361 */         StatFrame2.this.timeScrollBarAdjustmentValueChanged(evt);
/*      */       }
/*      */       
/* 1364 */     });
     this.conPercentGraphicsPanel.setBackground(new Color(240, 246, 251));
     this.conPercentGraphicsPanel.setBorder(BorderFactory.createLineBorder(new Color(153, 153, 255), 2));
     GroupLayout GraphGraphicsPanelLayout = new GroupLayout(this.conPercentGraphicsPanel);
     this.conPercentGraphicsPanel.setLayout(GraphGraphicsPanelLayout);
     GraphGraphicsPanelLayout.setHorizontalGroup(
/* 1392 */       GraphGraphicsPanelLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 1393 */       .addGap(0, 322, 32767));
     GraphGraphicsPanelLayout.setVerticalGroup(
/* 1396 */       GraphGraphicsPanelLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 1397 */       .addGap(0, 228, 32767));
     this.currentTimeValueTextField.setText("0.000");
     this.currentTimeValueTextField.addActionListener(new ActionListener() {
/*      */       public void actionPerformed(ActionEvent evt) {
/* 1403 */         StatFrame2.this.currentTimeValueTextFieldActionPerformed(evt);
/*      */       }
/*      */       
/* 1406 */     });
     this.plotComboBox.setModel(new javax.swing.DefaultComboBoxModel(
/* 1408 */       new String[] { "Con", "Res" }));
     this.plotComboBox.addActionListener(new ActionListener() {
/*      */       public void actionPerformed(ActionEvent evt) {
/* 1411 */         StatFrame2.this.plotComboBoxActionPerformed(evt);
/*      */       }
/*      */       
/* 1414 */     });
     this.jPanel2Layout = new GroupLayout(this.jPanel2);
     jPanel2Layout.setHorizontalGroup(
     	jPanel2Layout.createParallelGroup(Alignment.LEADING)
     		.addGroup(jPanel2Layout.createSequentialGroup()
     			.addGap(45)
     			.addGroup(jPanel2Layout.createParallelGroup(Alignment.LEADING)
     				.addGroup(jPanel2Layout.createSequentialGroup()
     					.addComponent(currentTimeLabel, GroupLayout.PREFERRED_SIZE, 95, GroupLayout.PREFERRED_SIZE)
     					.addGap(1)
     					.addComponent(currentTimeValueTextField, GroupLayout.PREFERRED_SIZE, 67, GroupLayout.PREFERRED_SIZE)
     					.addPreferredGap(ComponentPlacement.RELATED)
     					.addComponent(weekLabel6, GroupLayout.PREFERRED_SIZE, 69, GroupLayout.PREFERRED_SIZE)
     					.addPreferredGap(ComponentPlacement.RELATED)
     					.addComponent(plotComboBox, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
     				.addComponent(timeScrollBar, GroupLayout.DEFAULT_SIZE, 340, Short.MAX_VALUE)
     				.addGroup(jPanel2Layout.createSequentialGroup()
     					.addGroup(jPanel2Layout.createParallelGroup(Alignment.LEADING)
     						.addComponent(conPercentGraphicsPanel, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     						.addComponent(contributingCompLabel, GroupLayout.DEFAULT_SIZE, 326, Short.MAX_VALUE)
     						.addComponent(percentG6PDLabel, GroupLayout.PREFERRED_SIZE, 292, GroupLayout.PREFERRED_SIZE))
     					.addGap(14)))
     			.addContainerGap())
     );
     jPanel2Layout.setVerticalGroup(
     	jPanel2Layout.createParallelGroup(Alignment.LEADING)
     		.addGroup(jPanel2Layout.createSequentialGroup()
     			.addContainerGap()
     			.addComponent(contributingCompLabel)
     			.addPreferredGap(ComponentPlacement.RELATED)
     			.addComponent(percentG6PDLabel)
     			.addGap(18)
     			.addComponent(conPercentGraphicsPanel, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     			.addPreferredGap(ComponentPlacement.RELATED)
     			.addComponent(timeScrollBar, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
     			.addGap(18)
     			.addGroup(jPanel2Layout.createParallelGroup(Alignment.BASELINE)
     				.addComponent(currentTimeLabel)
     				.addComponent(currentTimeValueTextField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
     				.addComponent(weekLabel6)
     				.addComponent(plotComboBox, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
     			.addGap(25))
     );
     this.jPanel2.setLayout(this.jPanel2Layout);
     GridBagConstraints gbc_jPanel2 = new GridBagConstraints();
     gbc_jPanel2.fill = GridBagConstraints.BOTH;
     gbc_jPanel2.insets = new Insets(0, 0, 5, 5);
     gbc_jPanel2.gridx = 0;
     gbc_jPanel2.gridy = 0;
     getContentPane().add(this.jPanel2, gbc_jPanel2);
     this.weekLabel1.setText("week(s)");
     this.weekLabel2.setText("week(s)");
     this.weekLabel3.setText("week(s)");
     this.weekLabel4.setText("week(s)");
     this.lambdaNuRatioLabel.setFont(new Font("Tahoma", 3, 12));
     this.lambdaNuRatioLabel.setText("\u03BB/\u03BD:");
     this.nuMuRatioLabel.setFont(new Font("Tahoma", 3, 12));
     this.nuMuRatioLabel.setText("\u03BD/\u03BC:");
     GroupLayout ratesPanelLayout = new GroupLayout(this.ratesPanel);
     this.ratesPanel.setLayout(ratesPanelLayout);
     ratesPanelLayout.setHorizontalGroup(
/* 1147 */       ratesPanelLayout.createSequentialGroup()
/* 1148 */       .addGroup(ratesPanelLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 1149 */       .addGroup(ratesPanelLayout.createSequentialGroup()
/* 1150 */       .addComponent(this.lambdaLabel, -2, -1, -2)
/* 1151 */       .addComponent(this.lambdaSlider, -2, -1, -2))
/* 1152 */       .addGroup(ratesPanelLayout.createSequentialGroup()
/* 1153 */       .addComponent(this.nuLabel, -2, -1, -2)
/* 1154 */       .addComponent(this.nuSlider, -2, -1, -2))
/* 1155 */       .addGroup(ratesPanelLayout.createSequentialGroup()
/* 1156 */       .addComponent(this.alphaLabel, -2, -1, -2)
/* 1157 */       .addComponent(this.alphaSlider, -2, -1, -2))
/* 1158 */       .addGroup(ratesPanelLayout.createSequentialGroup()
/* 1159 */       .addComponent(this.muLabel, -2, -1, -2)
/* 1160 */       .addComponent(this.muSlider, -2, -1, -2))
/* 1161 */       .addGroup(ratesPanelLayout.createSequentialGroup()
/* 1162 */       .addComponent(this.lambdaNuRatioLabel, -2, -1, -2)
/* 1163 */       .addComponent(this.lambdaNuRatioTextField, -2, -1, -2))
/* 1164 */       .addGroup(ratesPanelLayout.createSequentialGroup()
/* 1165 */       .addComponent(this.nuMuRatioLabel, -2, -1, -2)
/* 1166 */       .addComponent(this.nuMuRatioTextField, -2, -1, -2)))
/* 1167 */       .addGroup(ratesPanelLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 1168 */       .addComponent(this.perLabel1, -2, -1, -2)
/* 1169 */       .addComponent(this.perLabel2, -2, -1, -2)
/* 1170 */       .addComponent(this.perLabel3, -2, -1, -2)
/* 1171 */       .addComponent(this.perLabel4, -2, -1, -2))
/* 1172 */       .addGroup(ratesPanelLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 1173 */       .addComponent(this.lambdaTextField, -2, -1, -2)
/* 1174 */       .addComponent(this.nuTextField, -2, -1, -2)
/* 1175 */       .addComponent(this.alphaTextField, -2, -1, -2)
/* 1176 */       .addComponent(this.muTextField, -2, -1, -2))
/* 1177 */       .addGroup(ratesPanelLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 1178 */       .addComponent(this.weekLabel1, -2, -1, -2)
/* 1179 */       .addComponent(this.weekLabel2, -2, -1, -2)
/* 1180 */       .addComponent(this.weekLabel3, -2, -1, -2)
/* 1181 */       .addComponent(this.weekLabel4, -2, -1, -2)));
     ratesPanelLayout.setVerticalGroup(
/* 1185 */       ratesPanelLayout.createSequentialGroup()
/* 1186 */       .addContainerGap()
/* 1187 */       .addGroup(ratesPanelLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 1188 */       .addComponent(this.lambdaLabel, -2, -1, -2)
/* 1189 */       .addComponent(this.lambdaSlider, -2, -1, -2)
/* 1190 */       .addComponent(this.perLabel1, -2, -1, -2)
/* 1191 */       .addComponent(this.lambdaTextField, -2, -1, -2)
/* 1192 */       .addComponent(this.weekLabel1, -2, -1, -2))
/* 1193 */       .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 1194 */       .addGroup(ratesPanelLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 1195 */       .addComponent(this.nuLabel, -2, -1, -2)
/* 1196 */       .addComponent(this.nuSlider, -2, -1, -2)
/* 1197 */       .addComponent(this.perLabel2, -2, -1, -2)
/* 1198 */       .addComponent(this.nuTextField, -2, -1, -2)
/* 1199 */       .addComponent(this.weekLabel2, -2, -1, -2))
/* 1200 */       .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 1201 */       .addGroup(ratesPanelLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 1202 */       .addComponent(this.alphaLabel, -2, -1, -2)
/* 1203 */       .addComponent(this.alphaSlider, -2, -1, -2)
/* 1204 */       .addComponent(this.perLabel3, -2, -1, -2)
/* 1205 */       .addComponent(this.alphaTextField, -2, -1, -2)
/* 1206 */       .addComponent(this.weekLabel3, -2, -1, -2))
/* 1207 */       .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 1208 */       .addGroup(ratesPanelLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 1209 */       .addComponent(this.muLabel, -2, -1, -2)
/* 1210 */       .addComponent(this.muSlider, -2, -1, -2)
/* 1211 */       .addComponent(this.perLabel4, -2, -1, -2)
/* 1212 */       .addComponent(this.muTextField, -2, -1, -2)
/* 1213 */       .addComponent(this.weekLabel4, -2, -1, -2))
/* 1214 */       .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
/* 1215 */       .addGroup(ratesPanelLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 1216 */       .addComponent(this.lambdaNuRatioLabel, -2, -1, -2)
/* 1217 */       .addComponent(this.lambdaNuRatioTextField, -2, -1, -2))
/* 1218 */       .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 1219 */       .addGroup(ratesPanelLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 1220 */       .addComponent(this.nuMuRatioLabel, -2, -1, -2)
/* 1221 */       .addComponent(this.nuMuRatioTextField, -2, -1, -2))
/* 1222 */       .addContainerGap());
     this.jTabbedPane1.addTab("Rates", this.ratesPanel);
     this.jTabbedPane1.addTab("Advanced", this.jPanel4);
     this.jPanel5.setBackground(new Color(153, 255, 153));
     this.jTabbedPane1.addTab("I/O", this.jPanel5);
     GridBagConstraints gbc_jTabbedPane1 = new GridBagConstraints();
     gbc_jTabbedPane1.fill = GridBagConstraints.BOTH;
     gbc_jTabbedPane1.insets = new Insets(0, 0, 5, 0);
     gbc_jTabbedPane1.gridwidth = 2;
     gbc_jTabbedPane1.gridx = 1;
     gbc_jTabbedPane1.gridy = 0;
     getContentPane().add(this.jTabbedPane1, gbc_jTabbedPane1);
     this.cellChanceRateLabel = new JLabel("50%");
     this.cellChanceRateLabel.setBackground(new Color(153, 255, 153));
     this.cellChanceRateLabel.setVisible(false);
     this.cellChanceRateSlider = new JSlider(0, 100);
     this.cellChanceRateSlider.setBackground(new Color(153, 255, 153));
     this.cellChanceRateSlider.addChangeListener(new ChangeListener() {
/*      */       public void stateChanged(ChangeEvent evt) {
/* 1723 */         StatFrame2.this.cellChanceRate = (StatFrame2.this.cellChanceRateSlider.getValue() / 100.0D);
/* 1724 */         StatFrame2.this.cellChanceRateLabel.setText(StatFrame2.this.cellChanceRateSlider.getValue() + "%");
/*      */       }
/*      */       
/* 1727 */     });
     this.cellChanceRateSlider.setVisible(false);
     GridLayout gl = new GridLayout(10, 1);
     this.jPanel4.setLayout(gl);
     BorderLayout bl_1 = new BorderLayout();
     this.cellChanceSubPanel = new JPanel(bl_1);
     this.cellChanceSubPanel.setBackground(new Color(153, 255, 153));
     this.cellChanceSubPanel.add(this.cellChance, "West");
     this.cellChanceSubPanel.add(this.cellChanceRateSlider, "Center");
     this.cellChanceSubPanel.add(this.cellChanceRateLabel, "East");
     this.jPanel4.add(this.cellChanceSubPanel);
     this.outputJTextArea = new JTextArea("The parameters for the latest run will \r\nbe shown here if the display option \r\n is selected.\r\n");
     this.outputJTextArea.setEditable(false);
     this.scrollPane = new javax.swing.JScrollPane(this.outputJTextArea);
     this.clearOutput = new JButton("Clear Output");
     this.clearOutput.setFont(new Font("Tahoma", 1, 12));
     this.clearOutput.addActionListener(new ActionListener() {
/*      */       public void actionPerformed(ActionEvent evt) {
/* 1970 */         StatFrame2.this.outputJTextArea.setText("The parameters for the latest run will \nbe shown here if the dispaly option \n is selected.\n");
/*      */       }
/*      */       
/*      */ 
/* 1974 */     });
     this.exportParameters = new JButton("Export Parameters");
     this.exportParameters.setFont(new Font("Tahoma", 1, 12));
     this.exportParameters.addActionListener(new ActionListener() {
/*      */       public void actionPerformed(ActionEvent evt) {
/* 1979 */         String outputFileName = JOptionPane.showInputDialog("Enter the file name for the output parameters: (without suffix \" .txt\")");
/*      */         
/*      */ 
/* 1982 */         if (!outputFileName.equalsIgnoreCase("null")) {
/* 1983 */           outputFileName = outputFileName + ".txt";
/*      */           try
/*      */           {
/* 1986 */             PrintStream output = new PrintStream(new File(outputFileName));
/* 1987 */             output.println("WARNNING: do NOT change the format.");
/* 1988 */             StatFrame2.this.recordCurrentRunParameters(output);
/*      */           } catch (Exception e) {
/* 1990 */             JOptionPane.showMessageDialog(null, "Invalid file name! Try again.", "ERROR", 
/* 1991 */               0);
/*      */           }
/*      */           
/*      */         }
/*      */       }
/* 1996 */     });
     this.importParameters = new JButton("Import Parameters");
     this.importParameters.setFont(new Font("Tahoma", 1, 12));
     this.importParameters.addActionListener(new ActionListener() {
/*      */       public void actionPerformed(ActionEvent evt) {
/* 2001 */         String inputFileName = JOptionPane.showInputDialog("Enter the file name for the input parameters: (without suffix \" .txt\")");
/*      */         
/*      */ 
/* 2004 */         if (!inputFileName.equalsIgnoreCase("null")) {
/* 2005 */           inputFileName = inputFileName + ".txt";
/*      */           try
/*      */           {
/* 2008 */             Scanner input = new Scanner(new File(inputFileName));
/* 2009 */             StatFrame2.this.processInput(input);
/*      */           } catch (Exception e) {
/* 2011 */             JOptionPane.showMessageDialog(null, "Invalid file! Try again.", "ERROR", 
/* 2012 */               0);
/*      */           }
/*      */           
/*      */         }
/*      */         
/*      */       }
/* 2018 */     });
     this.display = new JCheckBox("Display parameters");
     this.display.setBackground(new Color(153, 255, 153));
     this.display.addActionListener(new ActionListener() {
/*      */       public void actionPerformed(ActionEvent evt) {
/* 2023 */         if (StatFrame2.this.display.isSelected()) {
/* 2024 */           StatFrame2.this.displayParameters = true;
/*      */         } else {
/* 2026 */           StatFrame2.this.displayParameters = false;
/*      */         }
/*      */         
/*      */       }
/* 2030 */     });
     this.useParaSameAsLastTime = new JCheckBox("Use same parameters as last run");
     this.useParaSameAsLastTime.setBackground(new Color(153, 255, 153));
     this.useParaSameAsLastTime.addActionListener(new ActionListener() {
/*      */       public void actionPerformed(ActionEvent evt) {
/* 2035 */         if (StatFrame2.this.useParaSameAsLastTime.isSelected()) {
/* 2036 */           StatFrame2.this.useParaSameAsLastTimeBoolean = true;
/* 2037 */           if (StatFrame2.this.alreadyRun) {
/* 2038 */             StatFrame2.this.useParaSameAsLastTimeFileName = (StatFrame2.this.seed + "para.txt");
/*      */             try
/*      */             {
/* 2041 */               PrintStream output = new PrintStream(new File(StatFrame2.this.useParaSameAsLastTimeFileName));
/* 2042 */               output.println("WARNNING: do NOT change the format.");
/* 2043 */               StatFrame2.this.recordCurrentRunParameters(output);
/*      */             } catch (java.io.FileNotFoundException e) {
/* 2045 */               JOptionPane.showMessageDialog(null, "Fail to record the parameters of last run.", "ERROR", 
/* 2046 */                 0);
/*      */             }
/*      */           } else {
/* 2049 */             JOptionPane.showMessageDialog(null, "Please run simulation at least once.", "ERROR", 
/* 2050 */               0);
/* 2051 */             StatFrame2.this.useParaSameAsLastTimeBoolean = false;
/* 2052 */             StatFrame2.this.useParaSameAsLastTime.setSelected(false);
/*      */           }
/*      */         } else {
/* 2055 */           StatFrame2.this.useParaSameAsLastTimeBoolean = false;
/* 2056 */           int r1 = (int)(System.currentTimeMillis() % 1000000000L);
/* 2057 */           StatFrame2.this.randomSeedTextField.setText(String.valueOf(Math.abs(r1)));
/*      */           try {
/* 2059 */             File f = new File(StatFrame2.this.useParaSameAsLastTimeFileName);
/* 2060 */             f.delete();
/*      */ 
/*      */           }
/*      */           catch (Exception localException) {}
/*      */         }
/*      */         
/*      */       }
/*      */       
/* 2068 */     });
     GroupLayout jPanel5Layout = new GroupLayout(this.jPanel5);
     this.jPanel5.setLayout(jPanel5Layout);
     jPanel5Layout.setHorizontalGroup(
/* 2072 */       jPanel5Layout.createSequentialGroup()
/* 2073 */       .addComponent(this.scrollPane)
/* 2074 */       .addGroup(jPanel5Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 2075 */       .addComponent(this.useParaSameAsLastTime)
/* 2076 */       .addComponent(this.display)
/* 2077 */       .addComponent(this.clearOutput)
/* 2078 */       .addComponent(this.exportParameters)
/* 2079 */       .addComponent(this.importParameters)));
     jPanel5Layout.setVerticalGroup(
/* 2083 */       jPanel5Layout.createParallelGroup()
/* 2084 */       .addComponent(this.scrollPane)
/* 2085 */       .addGroup(jPanel5Layout.createSequentialGroup()
/* 2086 */       .addContainerGap()
/* 2087 */       .addComponent(this.useParaSameAsLastTime)
/* 2088 */       .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 2089 */       .addComponent(this.display)
/* 2090 */       .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 2091 */       .addComponent(this.clearOutput)
/* 2092 */       .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 2093 */       .addComponent(this.exportParameters)
/* 2094 */       .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 2095 */       .addComponent(this.importParameters)
/* 2096 */       .addContainerGap()));
/* 1278 */
/* 1279 */
/*      */     
/* 1298 */
/*      */     
/*      */ 
/* 1314 */
/*      */     
/* 1316 */
/* 1317 */
/*      */     
/* 1319 */
/* 1320 */
/*      */     
/* 1322 */
/* 1323 */
/*      */     
/* 1325 */
/* 1326 */
/*      */     
/*      */ 
/* 1329 */
/* 1330 */
/* 1331 */
/*      */     
/* 1333 */
/* 1334 */
/* 1335 */
/* 1336 */
/* 1337 */
/* 1344 */
/* 1345 */
/* 1346 */
/* 1347 */
/*      */     
/* 1349 */
/* 1350 */
/* 1351 */
/*      */     
/* 1353 */
/* 1354 */
/* 1355 */
/* 1356 */
/* 1357 */
/* 1358 */
/* 1359 */
/* 1365 */
/* 1366 */
/* 1367 */     this.resPercentGraphicsPanel.setBackground(new Color(240, 246, 251));
/* 1368 */     this.resPercentGraphicsPanel.setBorder(BorderFactory.createLineBorder(new Color(153, 153, 255), 2));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1378 */     GroupLayout GraphGraphicsPanelLayout2 = new GroupLayout(this.resPercentGraphicsPanel);
/* 1379 */     this.resPercentGraphicsPanel.setLayout(GraphGraphicsPanelLayout2);
/* 1380 */     GraphGraphicsPanelLayout2.setHorizontalGroup(
/* 1381 */       GraphGraphicsPanelLayout2.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 1382 */       .addGap(0, 322, 32767));
/*      */     
/* 1384 */     GraphGraphicsPanelLayout2.setVerticalGroup(
/* 1385 */       GraphGraphicsPanelLayout2.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 1386 */       .addGap(0, 228, 32767));
/*      */     
/*      */ 
/* 1389 */
/* 1390 */
/* 1391 */
/*      */     
/* 1395 */
/*      */     
/*      */ 
/* 1400 */
/* 1401 */
/* 1407 */
/* 1409 */
/* 1415 */
/* 1416 */
/* 1417 */
/*      */     
/* 1437 */
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1459 */
/*      */     
/*      */ 
/* 1462 */     this.jPanel1 = new JPanel();
     this.creaturesComboBox = new JComboBox();
     this.clearButton = new JButton();
     this.exportButton = new JButton();
     this.screenshotButton = new JButton();
     this.runPauseButton = new JToggleButton();
     this.jPanel1.setBackground(new Color(153, 255, 153));
     this.jPanel1.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0)));
     this.creaturesComboBox.setModel(new javax.swing.DefaultComboBoxModel(
/* 1237 */       new String[] { "Cat", "Mouse", "Human", "Baboon" }));
     this.creaturesComboBox.addActionListener(new ActionListener() {
/*      */       public void actionPerformed(ActionEvent evt) {
/* 1240 */         StatFrame2.this.creaturesComboBoxActionPerformed(evt);
/*      */       }
/*      */       
/* 1243 */     });
     this.clearButton.setFont(new Font("Tahoma", 1, 12));
     this.clearButton.setText("Clear");
     this.clearButton.addActionListener(new ActionListener() {
/*      */       public void actionPerformed(ActionEvent evt) {
/* 1248 */         StatFrame2.this.clearButtonActionPerformed(evt);
/*      */       }
/*      */       
/* 1251 */     });
     this.exportButton.setFont(new Font("Tahoma", 1, 12));
     this.exportButton.setText("Export");
     this.exportButton.addActionListener(new ActionListener() {
/*      */       public void actionPerformed(ActionEvent evt) {
/* 1256 */         StatFrame2.this.exportButtonActionPerformed(evt);
/*      */       }
/*      */       
/* 1259 */     });
     this.screenshotButton.setFont(new Font("Tahoma", 1, 12));
     this.screenshotButton.setText("Screenshot");
     this.screenshotButton.setToolTipText("move the window to upper-left corner for full capture");
     this.screenshotButton.addActionListener(new ActionListener() {
/*      */       public void actionPerformed(ActionEvent evt) {
/* 1265 */         StatFrame2.this.screenshotButtonActionPerformed(evt);
/*      */       }
/*      */       
/* 1268 */     });
     this.runPauseButton.setFont(new Font("Tahoma", 1, 14));
     this.runPauseButton.setText("Run");
     this.runPauseButton.addActionListener(new ActionListener() {
/*      */       public void actionPerformed(ActionEvent evt) {
/* 1273 */         StatFrame2.this.runPauseButtonActionPerformed(evt);
/*      */       }
/*      */       
/* 1276 */     });
     this.jPanel3 = new JPanel();
     this.ReserveGraphicsPanel = new paintCanvasBean();
     this.ReserveCompartmentLabel = new JLabel();
     this.ReserveCompartmentLabel1 = new JLabel();
     this.ContributingGraphicsPanel = new paintCanvasBean();
     this.statsPanel = new JPanel();
     this.jLabel30 = new JLabel();
     this.jLabel4 = new JLabel();
     this.totalLabel = new JLabel();
     this.dtypeLabel = new JLabel();
     this.gtypeLabel = new JLabel();
     this.percentLabel = new JLabel();
     this.sampleLabel = new JLabel();
     this.resTotalLabel = new JLabel();
     this.resDtypeLabel = new JLabel();
     this.resGtypeLabel = new JLabel();
     this.resPercentlLabel = new JLabel(); // sumFun: this label's value need to be exported
     this.conTotalLabel = new JLabel();
     this.conDtypeLabel = new JLabel();
     this.conGtypeLabel = new JLabel();
     this.conPercentlLabel = new JLabel(); // sumFun: this label's value need to be exported
     this.conSamplelLabel = new JLabel();
     this.resSamplelLabel = new JLabel();
     this.plottingDelaySubPanel = new JPanel();
     this.plottingDelaySlider = new JSlider();
     this.plottingDelayLabel = new JLabel();
     BorderLayout bl = new BorderLayout();
     this.plottingDelaySubPanel.setLayout(bl);
     this.plottingDelaySubPanel.setBackground(new Color(153, 255, 153));
     this.plottingDelaySlider.setMinimum(0);
     this.plottingDelaySlider.setMaximum(100);
     this.plottingDelaySlider.setValue(0);
     this.plottingDelaySlider.setBackground(new Color(153, 255, 153));
     this.plottingDelaySlider.addChangeListener(new ChangeListener() {
/*      */       public void stateChanged(ChangeEvent evt) {
/* 1339 */         StatFrame2.this.plottingDelayMilseconds = (StatFrame2.this.plottingDelaySlider.getValue() * 10L);
/* 1340 */         StatFrame2.this.plottingDelayLabel.setText("Plotting Delay: " + 
/* 1341 */           StatFrame2.this.plottingDelayMilseconds / 1000.0D + " s");
/*      */       }
/* 1343 */     });
     this.plottingDelayLabel.setBackground(new Color(153, 255, 153));
     this.plottingDelayLabel.setText("Plotting Delay: " + this.plottingDelayMilseconds / 1000.0D + " s");
     this.plottingDelaySubPanel.add(this.plottingDelaySlider, "West");
     this.plottingDelaySubPanel.add(this.plottingDelayLabel, "Center");
     this.jPanel3.setBackground(new Color(153, 255, 153));
     this.jPanel3.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0)));
     this.ReserveGraphicsPanel.setBackground(new Color(240, 246, 251));
     this.ReserveGraphicsPanel.setBorder(BorderFactory.createLineBorder(new Color(153, 153, 255), 2));
     GroupLayout ReserveGraphicsPanelLayout = new GroupLayout(this.ReserveGraphicsPanel);
     this.ReserveGraphicsPanel.setLayout(ReserveGraphicsPanelLayout);
     ReserveGraphicsPanelLayout.setHorizontalGroup(
/* 1471 */       ReserveGraphicsPanelLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 1472 */       .addGap(0, 175, 32767));
     ReserveGraphicsPanelLayout.setVerticalGroup(
/* 1475 */       ReserveGraphicsPanelLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 1476 */       .addGap(0, 169, 32767));
     this.ReserveCompartmentLabel.setFont(new Font("Tahoma", 1, 14));
     this.ReserveCompartmentLabel.setHorizontalAlignment(0);
     this.ReserveCompartmentLabel.setText("Reserve Compartment");
     this.ReserveCompartmentLabel1.setFont(new Font("Tahoma", 1, 14));
     this.ReserveCompartmentLabel1.setHorizontalAlignment(0);
     this.ReserveCompartmentLabel1.setText("Contributing Compartment");
     this.ContributingGraphicsPanel.setBackground(new Color(240, 246, 251));
     this.ContributingGraphicsPanel.setBorder(BorderFactory.createLineBorder(new Color(153, 153, 255), 2));
     GroupLayout ContributingGraphicsPanelLayout = new GroupLayout(this.ContributingGraphicsPanel);
     this.ContributingGraphicsPanel.setLayout(ContributingGraphicsPanelLayout);
     ContributingGraphicsPanelLayout.setHorizontalGroup(
/* 1493 */       ContributingGraphicsPanelLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 1494 */       .addGap(0, 175, 32767));
     ContributingGraphicsPanelLayout.setVerticalGroup(
/* 1497 */       ContributingGraphicsPanelLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 1498 */       .addGap(0, 169, 32767));
     this.statsPanel.setBackground(new Color(153, 255, 153));
     this.jLabel30.setFont(new Font("Tahoma", 1, 12));
     this.jLabel30.setText("Reserve");
     this.jLabel4.setFont(new Font("Tahoma", 1, 12));
     this.jLabel4.setText("Contributing");
     this.totalLabel.setFont(new Font("Tahoma", 1, 12));
     this.totalLabel.setHorizontalAlignment(4);
     this.totalLabel.setText("Total number of cells:");
     this.dtypeLabel.setFont(new Font("Tahoma", 1, 12));
     this.dtypeLabel.setHorizontalAlignment(4);
     this.dtypeLabel.setText("Type a:");
     this.gtypeLabel.setFont(new Font("Tahoma", 1, 12));
     this.gtypeLabel.setHorizontalAlignment(4);
     this.gtypeLabel.setText("Type b:");
     this.percentLabel.setFont(new Font("Tahoma", 1, 12));
     this.percentLabel.setHorizontalAlignment(4);
     this.percentLabel.setText("% type a:");
     this.sampleLabel.setFont(new Font("Tahoma", 1, 12));
     this.sampleLabel.setHorizontalAlignment(4);
     this.sampleLabel.setText("% type a in sample:");
     this.resTotalLabel.setText("30");
     this.resTotalLabel.setDoubleBuffered(true);
     this.resDtypeLabel.setText("15");
     this.resDtypeLabel.setDoubleBuffered(true);
     this.resGtypeLabel.setText("15");
     this.resGtypeLabel.setDoubleBuffered(true);
     this.resPercentlLabel.setText("50.0");
     this.resPercentlLabel.setDoubleBuffered(true);
     this.conTotalLabel.setFont(new Font("Tahoma", 0, 12));
     this.conTotalLabel.setText("16");
     this.conTotalLabel.setDoubleBuffered(true);
     this.conDtypeLabel.setFont(new Font("Tahoma", 0, 12));
     this.conDtypeLabel.setText("8");
     this.conDtypeLabel.setDoubleBuffered(true);
     this.conGtypeLabel.setFont(new Font("Tahoma", 0, 12));
     this.conGtypeLabel.setText("8");
     this.conGtypeLabel.setDoubleBuffered(true);
     this.conPercentlLabel.setFont(new Font("Tahoma", 0, 12));
     this.conPercentlLabel.setText("50.0");
     this.conPercentlLabel.setDoubleBuffered(true);
     this.conSamplelLabel.setFont(new Font("Tahoma", 0, 12));
     this.conSamplelLabel.setText("50.0");
     this.conSamplelLabel.setDoubleBuffered(true);
     GroupLayout statsPanelLayout = new GroupLayout(this.statsPanel);
     statsPanelLayout.setHorizontalGroup(
     	statsPanelLayout.createParallelGroup(Alignment.LEADING)
     		.addGroup(statsPanelLayout.createSequentialGroup()
     			.addContainerGap()
     			.addGroup(statsPanelLayout.createParallelGroup(Alignment.TRAILING)
     				.addGroup(statsPanelLayout.createSequentialGroup()
     					.addGroup(statsPanelLayout.createParallelGroup(Alignment.LEADING)
     						.addGroup(statsPanelLayout.createParallelGroup(Alignment.LEADING)
     							.addGroup(statsPanelLayout.createParallelGroup(Alignment.TRAILING)
     								.addGroup(statsPanelLayout.createSequentialGroup()
     									.addComponent(sampleLabel)
     									.addGap(17))
     								.addGroup(statsPanelLayout.createSequentialGroup()
     									.addComponent(totalLabel)
     									.addGap(18)))
     							.addGroup(statsPanelLayout.createSequentialGroup()
     								.addComponent(dtypeLabel, GroupLayout.DEFAULT_SIZE, 132, Short.MAX_VALUE)
     								.addPreferredGap(ComponentPlacement.RELATED))
     							.addGroup(statsPanelLayout.createSequentialGroup()
     								.addComponent(gtypeLabel, GroupLayout.DEFAULT_SIZE, 132, Short.MAX_VALUE)
     								.addPreferredGap(ComponentPlacement.RELATED)))
     						.addGroup(statsPanelLayout.createSequentialGroup()
     							.addComponent(percentLabel)
     							.addPreferredGap(ComponentPlacement.RELATED)))
     					.addGroup(statsPanelLayout.createParallelGroup(Alignment.LEADING)
     						.addComponent(resTotalLabel, GroupLayout.PREFERRED_SIZE, 38, GroupLayout.PREFERRED_SIZE)
     						.addComponent(resDtypeLabel, GroupLayout.PREFERRED_SIZE, 38, GroupLayout.PREFERRED_SIZE)
     						.addComponent(resGtypeLabel, GroupLayout.PREFERRED_SIZE, 38, GroupLayout.PREFERRED_SIZE)
     						.addComponent(resPercentlLabel, GroupLayout.PREFERRED_SIZE, 38, GroupLayout.PREFERRED_SIZE)
     						.addComponent(resSamplelLabel, GroupLayout.PREFERRED_SIZE, 38, GroupLayout.PREFERRED_SIZE))
     					.addGap(29))
     				.addGroup(statsPanelLayout.createSequentialGroup()
     					.addComponent(jLabel30, GroupLayout.PREFERRED_SIZE, 61, GroupLayout.PREFERRED_SIZE)
     					.addGap(18)))
     			.addGroup(statsPanelLayout.createParallelGroup(Alignment.LEADING)
     				.addComponent(conTotalLabel, GroupLayout.PREFERRED_SIZE, 38, GroupLayout.PREFERRED_SIZE)
     				.addComponent(conDtypeLabel, GroupLayout.PREFERRED_SIZE, 38, GroupLayout.PREFERRED_SIZE)
     				.addComponent(conGtypeLabel, GroupLayout.PREFERRED_SIZE, 38, GroupLayout.PREFERRED_SIZE)
     				.addComponent(conPercentlLabel, GroupLayout.PREFERRED_SIZE, 38, GroupLayout.PREFERRED_SIZE)
     				.addGroup(statsPanelLayout.createSequentialGroup()
     					.addGap(2)
     					.addComponent(jLabel4, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
     				.addComponent(conSamplelLabel, GroupLayout.PREFERRED_SIZE, 38, GroupLayout.PREFERRED_SIZE))
     			.addContainerGap())
     );
     statsPanelLayout.setVerticalGroup(
     	statsPanelLayout.createParallelGroup(Alignment.TRAILING)
     		.addGroup(statsPanelLayout.createSequentialGroup()
     			.addGap(13)
     			.addGroup(statsPanelLayout.createParallelGroup(Alignment.LEADING)
     				.addGroup(statsPanelLayout.createParallelGroup(Alignment.BASELINE)
     					.addComponent(jLabel4)
     					.addComponent(jLabel30))
     				.addGroup(statsPanelLayout.createSequentialGroup()
     					.addGap(21)
     					.addGroup(statsPanelLayout.createParallelGroup(Alignment.LEADING)
     						.addGroup(statsPanelLayout.createSequentialGroup()
     							.addGap(88)
     							.addGroup(statsPanelLayout.createParallelGroup(Alignment.BASELINE)
     								.addComponent(sampleLabel, GroupLayout.DEFAULT_SIZE, 20, Short.MAX_VALUE)
     								.addComponent(conSamplelLabel)))
     						.addGroup(statsPanelLayout.createSequentialGroup()
     							.addGroup(statsPanelLayout.createParallelGroup(Alignment.BASELINE)
     								.addComponent(resTotalLabel)
     								.addComponent(conTotalLabel)
     								.addComponent(totalLabel, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
     							.addPreferredGap(ComponentPlacement.RELATED)
     							.addGroup(statsPanelLayout.createParallelGroup(Alignment.BASELINE)
     								.addComponent(resDtypeLabel)
     								.addComponent(conDtypeLabel)
     								.addComponent(dtypeLabel))
     							.addPreferredGap(ComponentPlacement.RELATED)
     							.addGroup(statsPanelLayout.createParallelGroup(Alignment.BASELINE)
     								.addComponent(resGtypeLabel)
     								.addComponent(conGtypeLabel)
     								.addComponent(gtypeLabel))
     							.addPreferredGap(ComponentPlacement.RELATED)
     							.addGroup(statsPanelLayout.createParallelGroup(Alignment.BASELINE)
     								.addComponent(resPercentlLabel)
     								.addComponent(conPercentlLabel)
     								.addComponent(percentLabel))
     							.addPreferredGap(ComponentPlacement.RELATED)
     							.addComponent(resSamplelLabel)
     							.addGap(24)))))
     			.addContainerGap())
     );
     statsPanelLayout.linkSize(SwingConstants.HORIZONTAL, new Component[] {totalLabel, dtypeLabel, gtypeLabel, percentLabel, sampleLabel});
     this.statsPanel.setLayout(statsPanelLayout);
     GroupLayout jPanel3Layout = new GroupLayout(this.jPanel3);
     jPanel3Layout.setHorizontalGroup(
     	jPanel3Layout.createParallelGroup(Alignment.LEADING)
     		.addGroup(jPanel3Layout.createSequentialGroup()
     			.addContainerGap()
     			.addGroup(jPanel3Layout.createParallelGroup(Alignment.LEADING)
     				.addComponent(ReserveGraphicsPanel, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     				.addComponent(ReserveCompartmentLabel, GroupLayout.PREFERRED_SIZE, 179, GroupLayout.PREFERRED_SIZE))
     			.addGroup(jPanel3Layout.createParallelGroup(Alignment.LEADING)
     				.addGroup(jPanel3Layout.createSequentialGroup()
     					.addGap(13)
     					.addComponent(ReserveCompartmentLabel1)
     					.addPreferredGap(ComponentPlacement.RELATED)
     					.addComponent(plottingDelaySubPanel, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
     				.addGroup(jPanel3Layout.createSequentialGroup()
     					.addPreferredGap(ComponentPlacement.UNRELATED)
     					.addComponent(ContributingGraphicsPanel, GroupLayout.DEFAULT_SIZE, 179, Short.MAX_VALUE)
     					.addGap(18)
     					.addComponent(statsPanel, GroupLayout.PREFERRED_SIZE, 337, GroupLayout.PREFERRED_SIZE)))
     			.addGap(27))
     );
     jPanel3Layout.setVerticalGroup(
     	jPanel3Layout.createParallelGroup(Alignment.TRAILING)
     		.addGroup(jPanel3Layout.createSequentialGroup()
     			.addContainerGap()
     			.addGroup(jPanel3Layout.createParallelGroup(Alignment.LEADING)
     				.addGroup(jPanel3Layout.createParallelGroup(Alignment.BASELINE)
     					.addComponent(ReserveCompartmentLabel1, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     					.addComponent(ReserveCompartmentLabel, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
     				.addComponent(plottingDelaySubPanel, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
     			.addGroup(jPanel3Layout.createParallelGroup(Alignment.LEADING)
     				.addGroup(jPanel3Layout.createSequentialGroup()
     					.addPreferredGap(ComponentPlacement.RELATED)
     					.addGroup(jPanel3Layout.createParallelGroup(Alignment.TRAILING)
     						.addComponent(ReserveGraphicsPanel, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     						.addComponent(ContributingGraphicsPanel, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
     					.addGap(54))
     				.addGroup(jPanel3Layout.createSequentialGroup()
     					.addGap(18)
     					.addComponent(statsPanel, GroupLayout.DEFAULT_SIZE, 205, Short.MAX_VALUE)
     					.addContainerGap())))
     );
     this.jPanel3.setLayout(jPanel3Layout);
     GridBagConstraints gbc_jPanel3 = new GridBagConstraints();
     gbc_jPanel3.fill = GridBagConstraints.BOTH;
     gbc_jPanel3.insets = new Insets(0, 0, 0, 5);
     gbc_jPanel3.gridwidth = 2;
     gbc_jPanel3.gridx = 0;
     gbc_jPanel3.gridy = 1;
     getContentPane().add(this.jPanel3, gbc_jPanel3);
     GroupLayout jPanel1Layout = new GroupLayout(this.jPanel1);
     this.jPanel1.setLayout(jPanel1Layout);
     jPanel1Layout.setHorizontalGroup(
/* 1280 */       jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 1281 */       .addGroup(jPanel1Layout.createSequentialGroup()
/* 1282 */       .addContainerGap()
/* 1283 */       .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 1284 */       .addGroup(jPanel1Layout.createSequentialGroup()
/* 1285 */       .addComponent(this.screenshotButton)
/* 1286 */       .addContainerGap(10, 32767))
/* 1287 */       .addGroup(GroupLayout.Alignment.TRAILING, 
/* 1288 */       jPanel1Layout.createSequentialGroup()
/*      */       
/* 1290 */       .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.TRAILING).addComponent(this.runPauseButton, GroupLayout.Alignment.LEADING, -1, 104, 32767).addComponent(this.creaturesComboBox, 0, -1, 32767))
/* 1291 */       .addContainerGap())
/* 1292 */       .addGroup(jPanel1Layout.createSequentialGroup()
/* 1293 */       .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.TRAILING, false)
/* 1294 */       .addComponent(this.clearButton, GroupLayout.Alignment.LEADING, -1, -1, 32767)
/* 1295 */       .addComponent(this.exportButton, GroupLayout.Alignment.LEADING, -1, -1, 32767))
/* 1296 */       .addContainerGap(38, 32767)))));
     jPanel1Layout.setVerticalGroup(
/* 1299 */       jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 1300 */       .addGroup(jPanel1Layout.createSequentialGroup()
/* 1301 */       .addGap(9, 9, 9)
/* 1302 */       .addComponent(this.runPauseButton, -2, 52, -2)
/* 1303 */       .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
/* 1304 */       .addComponent(this.creaturesComboBox, -2, -1, -2)
/* 1305 */       .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 1306 */       .addComponent(this.clearButton)
/* 1307 */       .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 1308 */       .addComponent(this.exportButton)
/* 1309 */       .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 1310 */       .addComponent(this.screenshotButton)
/* 1311 */       .addContainerGap(29, 32767)));
     GridBagConstraints gbc_jPanel1 = new GridBagConstraints();
     gbc_jPanel1.fill = GridBagConstraints.BOTH;
     gbc_jPanel1.gridx = 2;
     gbc_jPanel1.gridy = 1;
     getContentPane().add(this.jPanel1, gbc_jPanel1);
/* 1463 */
/* 1699 */     pack();
/*      */   }
/*      */   
/*      */   private void setAdvanceOptionsJTabbedPanel()
/*      */   {
/* 1705 */     this.jPanel4.setBackground(new Color(153, 255, 153));
/*      */     
/* 1707 */     this.cellChance.setBackground(new Color(153, 255, 153));
/* 1708 */     this.cellChance.setText("Adjust Replication Fates When N >= K");
/* 1709 */     this.cellChance.addActionListener(new ActionListener() {
/*      */       public void actionPerformed(ActionEvent evt) {
/* 1711 */         StatFrame2.this.cellChanceActionPerformed(evt);
/*      */       }
/*      */       
/* 1714 */     });
/* 1715 */
/* 1716 */
/* 1717 */
/*      */     
/* 1719 */
/* 1720 */
/* 1721 */
/* 1728 */
/*      */     
/* 1730 */     this.abDiffBox.setBackground(new Color(153, 255, 153));
/* 1731 */     this.abDiffBox.setText("Adjust Rates Separately for A and B");
/* 1732 */     this.abDiffBox.addActionListener(new ActionListener() {
/*      */       public void actionPerformed(ActionEvent evt) {
/* 1734 */         StatFrame2.this.abDiffBoxActionPerformed(evt);
/*      */       }
/*      */       
/* 1737 */     });
/* 1738 */     this.lambdaLabelA.setFont(new Font("Tahoma", 1, 14));
/* 1739 */     this.lambdaLabelA.setText("��a");
/* 1740 */     this.lambdaLabelA.setBackground(new Color(153, 255, 153));
/* 1741 */     this.lambdaLabelB.setFont(new Font("Tahoma", 1, 14));
/* 1742 */     this.lambdaLabelB.setText("��b");
/* 1743 */     this.lambdaLabelB.setBackground(new Color(153, 255, 153));
/*      */     
/*      */ 
/* 1746 */     this.lambdaSliderA.setBackground(new Color(153, 255, 153));
/* 1747 */     this.lambdaSliderA.addChangeListener(new ChangeListener() {
/*      */       public void stateChanged(ChangeEvent evt) {
/* 1749 */         StatFrame2.this.lambdaSliderAStateChanged(evt);
/*      */       }
/*      */       
/*      */ 
/* 1753 */     });
/* 1754 */     this.lambdaTextFieldA.setText("10");
/* 1755 */     this.lambdaTextFieldA.addActionListener(new ActionListener() {
/*      */       public void actionPerformed(ActionEvent evt) {
/* 1757 */         StatFrame2.this.lambdaTextFieldAActionPerformed(evt);
/*      */       }
/*      */       
/* 1760 */     });
/* 1761 */     this.lambdaSliderB.setBackground(new Color(153, 255, 153));
/* 1762 */     this.lambdaSliderB.addChangeListener(new ChangeListener() {
/*      */       public void stateChanged(ChangeEvent evt) {
/* 1764 */         StatFrame2.this.lambdaSliderBStateChanged(evt);
/*      */       }
/*      */       
/* 1767 */     });
/* 1768 */     this.lambdaTextFieldB.setText("10");
/* 1769 */     this.lambdaTextFieldB.addActionListener(new ActionListener() {
/*      */       public void actionPerformed(ActionEvent evt) {
/* 1771 */         StatFrame2.this.lambdaTextFieldBActionPerformed(evt);
/*      */       }
/*      */       
/*      */ 
/* 1775 */     });
/* 1776 */     this.muLabelA.setFont(new Font("Tahoma", 1, 14));
/* 1777 */     this.muLabelA.setText("��a");
/* 1778 */     this.muLabelA.setBackground(new Color(153, 255, 153));
/*      */     
/* 1780 */     this.muLabelB.setFont(new Font("Tahoma", 1, 14));
/* 1781 */     this.muLabelB.setText("��b");
/* 1782 */     this.muLabelB.setBackground(new Color(153, 255, 153));
/*      */     
/* 1784 */     this.alphaLabelA.setFont(new Font("Tahoma", 1, 14));
/* 1785 */     this.alphaLabelA.setText("��a");
/* 1786 */     this.alphaLabelA.setBackground(new Color(153, 255, 153));
/*      */     
/* 1788 */     this.alphaLabelB.setFont(new Font("Tahoma", 1, 14));
/* 1789 */     this.alphaLabelB.setText("��b");
/* 1790 */     this.alphaLabelB.setBackground(new Color(153, 255, 153));
/*      */     
/* 1792 */     this.alphaSliderA.setBackground(new Color(153, 255, 153));
/* 1793 */     this.alphaSliderA.addChangeListener(new ChangeListener() {
/*      */       public void stateChanged(ChangeEvent evt) {
/* 1795 */         StatFrame2.this.alphaSliderAStateChanged(evt);
/*      */       }
/*      */       
/* 1798 */     });
/* 1799 */     this.alphaTextFieldA.setText("0.0001");
/* 1800 */     this.alphaTextFieldA.addActionListener(new ActionListener() {
/*      */       public void actionPerformed(ActionEvent evt) {
/* 1802 */         StatFrame2.this.alphaTextFieldAActionPerformed(evt);
/*      */       }
/*      */       
/* 1805 */     });
/* 1806 */     this.alphaSliderB.setBackground(new Color(153, 255, 153));
/* 1807 */     this.alphaSliderB.addChangeListener(new ChangeListener() {
/*      */       public void stateChanged(ChangeEvent evt) {
/* 1809 */         StatFrame2.this.alphaSliderBStateChanged(evt);
/*      */       }
/*      */       
/* 1812 */     });
/* 1813 */     this.alphaTextFieldB.setText("0.0001");
/* 1814 */     this.alphaTextFieldB.addActionListener(new ActionListener() {
/*      */       public void actionPerformed(ActionEvent evt) {
/* 1816 */         StatFrame2.this.alphaTextFieldBActionPerformed(evt);
/*      */       }
/*      */       
/* 1819 */     });
/* 1820 */     this.muSliderA.setBackground(new Color(153, 255, 153));
/* 1821 */     this.muSliderA.addChangeListener(new ChangeListener() {
/*      */       public void stateChanged(ChangeEvent evt) {
/* 1823 */         StatFrame2.this.muSliderAStateChanged(evt);
/*      */       }
/*      */       
/* 1826 */     });
/* 1827 */     this.muTextFieldA.setText("6.7");
/* 1828 */     this.muTextFieldA.addActionListener(new ActionListener() {
/*      */       public void actionPerformed(ActionEvent evt) {
/* 1830 */         StatFrame2.this.muTextFieldAActionPerformed(evt);
/*      */       }
/*      */       
/* 1833 */     });
/* 1834 */     this.muSliderB.setBackground(new Color(153, 255, 153));
/* 1835 */     this.muSliderB.addChangeListener(new ChangeListener() {
/*      */       public void stateChanged(ChangeEvent evt) {
/* 1837 */         StatFrame2.this.muSliderBStateChanged(evt);
/*      */       }
/*      */       
/* 1840 */     });
/* 1841 */     this.muTextFieldB.setText("6.7");
/* 1842 */     this.muTextFieldB.addActionListener(new ActionListener() {
/*      */       public void actionPerformed(ActionEvent evt) {
/* 1844 */         StatFrame2.this.muTextFieldBActionPerformed(evt);
/*      */       }
/*      */       
/* 1847 */     });
/* 1848 */     this.nuLabelA.setFont(new Font("Tahoma", 1, 14));
/* 1849 */     this.nuLabelA.setText("��a");
/* 1850 */     this.nuLabelA.setBackground(new Color(153, 255, 153));
/*      */     
/* 1852 */     this.nuLabelB.setFont(new Font("Tahoma", 1, 14));
/* 1853 */     this.nuLabelB.setText("��b");
/* 1854 */     this.nuLabelB.setBackground(new Color(153, 255, 153));
/*      */     
/* 1856 */     this.nuSliderA.setBackground(new Color(153, 255, 153));
/* 1857 */     this.nuSliderA.addChangeListener(new ChangeListener() {
/*      */       public void stateChanged(ChangeEvent evt) {
/* 1859 */         StatFrame2.this.nuSliderAStateChanged(evt);
/*      */       }
/*      */       
/* 1862 */     });
/* 1863 */     this.nuTextFieldA.setText("12.5");
/* 1864 */     this.nuTextFieldA.addActionListener(new ActionListener() {
/*      */       public void actionPerformed(ActionEvent evt) {
/* 1866 */         StatFrame2.this.nuTextFieldAActionPerformed(evt);
/*      */       }
/*      */       
/* 1869 */     });
/* 1870 */     this.nuSliderB.setBackground(new Color(153, 255, 153));
/* 1871 */     this.nuSliderB.addChangeListener(new ChangeListener() {
/*      */       public void stateChanged(ChangeEvent evt) {
/* 1873 */         StatFrame2.this.nuSliderBStateChanged(evt);
/*      */       }
/*      */       
/* 1876 */     });
/* 1877 */     this.nuTextFieldB.setText("12.5");
/* 1878 */     this.nuTextFieldB.addActionListener(new ActionListener() {
/*      */       public void actionPerformed(ActionEvent evt) {
/* 1880 */         StatFrame2.this.nuTextFieldBActionPerformed(evt);
/*      */       }
/*      */       
/* 1883 */     });
/* 1884 */
/* 1885 */
/*      */     
/* 1887 */     FlowLayout fl = new FlowLayout();
/* 1888 */     fl.setAlignment(0);
/*      */     
/* 1890 */
/*      */     
/* 1892 */
/* 1893 */
/* 1894 */
/* 1895 */
/* 1896 */
/*      */     
/* 1898 */
/* 1899 */     this.jPanel4.add(this.abDiffBox);
/*      */     
/* 1901 */     JPanel[] subJPanels = new JPanel[8];
/* 1902 */     for (int i = 0; i < 8; i++) {
/* 1903 */       subJPanels[i] = new JPanel();
/* 1904 */       subJPanels[i].setBackground(new Color(153, 255, 153));
/* 1905 */       subJPanels[i].setLayout(fl);
/*      */     }
/*      */     
/* 1908 */     subJPanels[0].add(this.lambdaLabelA);
/* 1909 */     subJPanels[0].add(this.lambdaSliderA);
/* 1910 */     subJPanels[1].add(this.lambdaLabelB);
/* 1911 */     subJPanels[1].add(this.lambdaSliderB);
/* 1912 */     subJPanels[2].add(this.nuLabelA);
/* 1913 */     subJPanels[2].add(this.nuSliderA);
/* 1914 */     subJPanels[3].add(this.nuLabelB);
/* 1915 */     subJPanels[3].add(this.nuSliderB);
/* 1916 */     subJPanels[4].add(this.alphaLabelA);
/* 1917 */     subJPanels[4].add(this.alphaSliderA);
/* 1918 */     subJPanels[5].add(this.alphaLabelB);
/* 1919 */     subJPanels[5].add(this.alphaSliderB);
/* 1920 */     subJPanels[6].add(this.muLabelA);
/* 1921 */     subJPanels[6].add(this.muSliderA);
/* 1922 */     subJPanels[7].add(this.muLabelB);
/* 1923 */     subJPanels[7].add(this.muSliderB);
/*      */     
/* 1925 */     JLabel[] perLabels = new JLabel[8];
/* 1926 */     for (int i = 0; i < 8; i++) {
/* 1927 */       perLabels[i] = new JLabel("1 per");
/* 1928 */       perLabels[i].setFont(new Font("Tahoma", 0, 14));
/* 1929 */       perLabels[i].setBackground(new Color(153, 255, 153));
/* 1930 */       subJPanels[i].add(perLabels[i]);
/*      */     }
/*      */     
/* 1933 */     subJPanels[0].add(this.lambdaTextFieldA);
/* 1934 */     subJPanels[1].add(this.lambdaTextFieldB);
/* 1935 */     subJPanels[2].add(this.nuTextFieldA);
/* 1936 */     subJPanels[3].add(this.nuTextFieldB);
/* 1937 */     subJPanels[4].add(this.alphaTextFieldA);
/* 1938 */     subJPanels[5].add(this.alphaTextFieldB);
/* 1939 */     subJPanels[6].add(this.muTextFieldA);
/* 1940 */     subJPanels[7].add(this.muTextFieldB);
/*      */     
/* 1942 */     JLabel[] weekLabels = new JLabel[8];
/* 1943 */     for (int i = 0; i < 8; i++)
/*      */     {
/* 1944 */       weekLabels[i] = new JLabel("week(s)");
/* 1945 */       weekLabels[i].setFont(new Font("Tahoma", 0, 14));
/* 1946 */       weekLabels[i].setBackground(new Color(153, 255, 153));
/* 1947 */       subJPanels[i].add(weekLabels[i]);
/* 1948 */       this.jPanel4.add(subJPanels[i]);
/*      */     }
/*      */   }
/*      */   
/*      */   private void setJPanel5()
/*      */   {
/* 1954 */
/*      */     
/* 1956 */
/* 1957 */
/*      */     
/* 1959 */     this.newOut = new PrintStream(System.out) {
/*      */       public void println(String text) {
/* 1961 */         StatFrame2.this.outputJTextArea.append(text + "\n");
/*      */       }
/* 1963 */     };
/* 1964 */     System.setOut(this.newOut);
/*      */     
/* 1966 */
/* 1967 */
/* 1968 */
/* 1975 */
/* 1976 */
/* 1977 */
/* 1997 */
/* 1998 */
/* 1999 */
/* 2019 */
/* 2020 */
/* 2021 */
/* 2031 */
/* 2032 */
/* 2033 */
/* 2069 */
/* 2070 */
/* 2071 */
/*      */     
/*      */ 
/* 2082 */
/*      */   }
/*      */   private int resDtypeTotal;
/*      */   private int conDtypeTotal;
/*      */   private int resGtypeTotal;
/*      */   private int conGtypeTotal;
/*      */   private boolean paused;
/*      */   private boolean newModel;
/*      */   private Mice2new mice2new;
/*      */   private Thread t;
/*      */   private int lambdaLB;
/*      */   private int lambdaUB;
/*      */   
/*      */   private void recordCurrentRunParameters(PrintStream output)
/*      */   {
/* 2102 */     output.println("The paremeters for the latest run are:");
/* 2103 */     output.println("Creature: \t" + this.creaturesComboBox.getSelectedItem().toString());
/* 2104 */     output.println("lambda \t" + this.lambda + "\nlambdaA \t" + this.lastestRunParameters[0] + 
/* 2105 */       "\nlambdaB \t" + this.lastestRunParameters[1] + "\nmu \t" + this.mu + "\nmuA \t" + 
/* 2106 */       this.lastestRunParameters[2] + "\nmuB \t" + this.lastestRunParameters[3] + "\nnu \t" + this.nu + 
/* 2107 */       "\nnuA \t" + this.lastestRunParameters[6] + "\nnuB \t" + this.lastestRunParameters[7] + 
/* 2108 */       "\nalpha \t" + this.alpha + "\nalphaA \t" + this.lastestRunParameters[4] + "\nalphaB \t" + 
/* 2109 */       this.lastestRunParameters[5] + "\nR0 \t" + this.R0 + "\nC0 \t" + this.C0 + "\nN \t" + this.N + 
/* 2110 */       "\nN2 \t" + this.N2 + "\nmaxCellConBoolean \t" + this.maxCellConBoolean + 
/* 2111 */       "\nsampleSize \t" + this.sampleSize + 
/* 2112 */       "\nsampleInterval \t" + this.sampleInterval + "\npercentR0a \t" + this.percentR0a + 
/* 2113 */       "\npercentC0a \t" + this.percentC0a + "\nseed \t" + this.seed + "\nabDifference \t" + 
/* 2114 */       this.abDifference + "\ntotalWeeks \t" + this.totalWeeks + "\nsetCellChance \t" + 
/* 2115 */       this.setCellChance + "\ncellChanceRate \t" + this.cellChanceRate + "\n");
/* 2116 */     output.println();
/*      */   }
/*      */   
/*      */   private void processInput(Scanner input)
/*      */   {
/* 2121 */     input.nextLine();
/* 2122 */     input.nextLine();
/* 2123 */     input.next();
/* 2124 */     this.creaturesComboBox.setSelectedItem(input.next());
/* 2125 */     input.next();
/* 2126 */     this.lambdaTextField.setText(input.next());
/* 2127 */     lambdaTextFieldActionPerformed(null);
/* 2128 */     input.next();
/* 2129 */     this.lambdaTextFieldA.setText(input.next());
/* 2130 */     lambdaTextFieldAActionPerformed(null);
/* 2131 */     input.next();
/* 2132 */     this.lambdaTextFieldB.setText(input.next());
/* 2133 */     lambdaTextFieldBActionPerformed(null);
/* 2134 */     input.next();
/* 2135 */     this.muTextField.setText(input.next());
/* 2136 */     muTextFieldActionPerformed(null);
/* 2137 */     input.next();
/* 2138 */     this.muTextFieldA.setText(input.next());
/* 2139 */     muTextFieldAActionPerformed(null);
/* 2140 */     input.next();
/* 2141 */     this.muTextFieldB.setText(input.next());
/* 2142 */     muTextFieldBActionPerformed(null);
/* 2143 */     input.next();
/* 2144 */     this.nuTextField.setText(input.next());
/* 2145 */     nuTextFieldActionPerformed(null);
/* 2146 */     input.next();
/* 2147 */     this.nuTextFieldA.setText(input.next());
/* 2148 */     nuTextFieldAActionPerformed(null);
/* 2149 */     input.next();
/* 2150 */     this.nuTextFieldB.setText(input.next());
/* 2151 */     nuTextFieldBActionPerformed(null);
/* 2152 */     input.next();
/* 2153 */     this.alphaTextField.setText(input.next());
/* 2154 */     alphaTextFieldActionPerformed(null);
/* 2155 */     input.next();
/* 2156 */     this.alphaTextFieldA.setText(input.next());
/* 2157 */     alphaTextFieldAActionPerformed(null);
/* 2158 */     input.next();
/* 2159 */     this.alphaTextFieldB.setText(input.next());
/* 2160 */     alphaTextFieldBActionPerformed(null);
/*      */     
/* 2162 */     input.next();
/* 2163 */     this.intResTextField.setText(input.next());
/* 2164 */     intResTextFieldActionPerformed(null);
/* 2165 */     input.next();
/* 2166 */     this.intConTextField.setText(input.next());
/* 2167 */     intConTextFieldActionPerformed(null);
/* 2168 */     input.next();
/* 2169 */     this.maxCellTextField.setText(input.next());
/* 2170 */     maxCellTextFieldActionPerformed(null);
/* 2171 */     input.next();
/* 2172 */     this.maxCellTextField2.setText(input.next());
/* 2173 */     maxCellTextField2ActionPerformed(null);
/*      */     
/* 2175 */     input.next();
/* 2176 */     String maxCellCon = input.next();
/* 2177 */     this.maxCellConCheckBox.setSelected(maxCellCon.startsWith("t"));
/* 2178 */     this.maxCellConBoolean = maxCellCon.startsWith("t");
/* 2179 */     maxCellConCheckboxActionPerformed(null);
/*      */     
/* 2181 */     input.next();
/* 2182 */     this.sampleSizeTextField.setText(input.next());
/* 2183 */     input.next();
/* 2184 */     this.sampleIntervalTextField.setText(input.next());
/* 2185 */     input.next();
/* 2186 */     this.percentR0TextField.setText(input.next());
/* 2187 */     input.next();
/* 2188 */     this.percentC0TextField.setText(input.next());
/* 2189 */     input.next();
/* 2190 */     this.randomSeedTextField.setText(input.next());
/*      */     
/*      */ 
/*      */ 
/* 2194 */     input.next();
/* 2195 */     String adDiffString = input.next();
/* 2196 */     this.abDiffBox.setSelected(adDiffString.startsWith("t"));
/* 2197 */     this.abDifference = adDiffString.startsWith("t");
/*      */     
/*      */ 
/* 2200 */     input.next();
/* 2201 */     this.totalWeeks = input.nextInt();
/* 2202 */     this.totalWeeksTextField.setText(String.valueOf(this.totalWeeks));
/*      */     
/* 2204 */     input.next();
/* 2205 */     String cellChanceString = input.next();
/* 2206 */     this.setCellChance = cellChanceString.startsWith("t");
/* 2207 */     this.cellChance.setSelected(this.setCellChance);
/* 2208 */     input.next();
/* 2209 */     this.cellChanceRateSlider.setValue((int)(input.nextDouble() * 100.0D));
/*      */   }
/*      */   
/*      */   private void lambdaTextFieldActionPerformed(ActionEvent evt)
/*      */   {
/*      */     try
/*      */     {
/* 2214 */       this.lambdaSlider.setValue((int)(Double.parseDouble(this.lambdaTextField.getText()) * (double)this.scale));
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/* 2216 */       this.lambdaTextField.setText(String.valueOf(10));
/*      */     }
/*      */   }
/*      */   
/*      */   private void nuTextFieldActionPerformed(ActionEvent evt)
/*      */   {
/*      */     try
/*      */     {
/* 2222 */       this.nuSlider.setValue((int)(Double.parseDouble(this.nuTextField.getText()) * (double)this.scale));
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/* 2224 */       this.nuTextField.setText(String.valueOf(12.5D));
/*      */     }
/*      */   }
/*      */   
/*      */   private void alphaTextFieldActionPerformed(ActionEvent evt)
/*      */   {
/*      */     try
/*      */     {
/* 2230 */       this.alphaSlider.setValue((int)(Double.parseDouble(this.alphaTextField.getText()) * (double)this.scale));
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/* 2232 */       this.alphaTextField.setText(String.valueOf(1.0E-4D * this.scale));
/*      */     }
/*      */   }
/*      */   
/*      */   private void muTextFieldActionPerformed(ActionEvent evt)
/*      */   {
/*      */     try
/*      */     {
/* 2238 */       this.muSlider.setValue((int)(Double.parseDouble(this.muTextField.getText()) * (double)this.scale));
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/* 2240 */       this.muTextField.setText(String.valueOf(6.7D));
/*      */     }
/*      */   }
/*      */   
/*      */   private void intConTextFieldActionPerformed(ActionEvent evt)
/*      */   {
/*      */     try
/*      */     {
/* 2246 */       this.intConSlider.setValue(Integer.parseInt(this.intConTextField.getText()));
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/* 2248 */       this.intConTextField.setText(String.valueOf(8));
/*      */     }
/*      */   }
/*      */   
/*      */   private void maxCellTextFieldActionPerformed(ActionEvent evt)
/*      */   {
/*      */     try
/*      */     {
/* 2254 */       this.maxCellSlider.setValue(Integer.parseInt(this.maxCellTextField.getText()));
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/* 2256 */       this.maxCellTextField.setText(String.valueOf(this.N));
/*      */     }
/*      */   }
/*      */   
/*      */   private void maxCellTextField2ActionPerformed(ActionEvent evt)
/*      */   {
/*      */     try
/*      */     {
/* 2262 */       this.maxCellSlider2.setValue(Integer.parseInt(this.maxCellTextField2.getText()));
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/* 2264 */       this.maxCellTextField2.setText(String.valueOf(this.N2));
/*      */     }
/*      */   }
/*      */   
/*      */   private void percentR0TextFieldActionPerformed(ActionEvent evt)
/*      */   {
/*      */     try
/*      */     {
/* 2270 */       if (Double.parseDouble(this.percentR0TextField.getText()) < 0.0D) {
/* 2271 */         this.percentR0TextField.setText("0.0");
/*      */       }
/* 2273 */       if (Double.parseDouble(this.percentR0TextField.getText()) > 100.0D) {
/* 2274 */         this.percentR0TextField.setText("100");
/*      */       }
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/* 2277 */       this.percentR0TextField.setText(String.valueOf(50));
/*      */     }
/*      */   }
/*      */   private double lambdaInit;
/*      */   private int nuLB;
/*      */   private int nuUB;
/*      */   private double nuInit;
/*      */   private int muLB;
/*      */   
/*      */   private void percentC0TextFieldActionPerformed(ActionEvent evt)
/*      */   {
/*      */     try
/*      */     {
/* 2283 */       if (Double.parseDouble(this.percentC0TextField.getText()) < 0.0D) {
/* 2284 */         this.percentC0TextField.setText("0.0");
/*      */       }
/* 2286 */       if (Double.parseDouble(this.percentC0TextField.getText()) > 100.0D) {
/* 2287 */         this.percentC0TextField.setText("100");
/*      */       }
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/* 2290 */       this.percentC0TextField.setText(String.valueOf(50));
/*      */     }
/*      */   }
/*      */   
/*      */   private int muUB;
/*      */   private double muInit;
/*      */   private int alphaLB;
/*      */   private int alphaUB;
/*      */   
/*      */   private void sampleSizeTextFieldActionPerformed(ActionEvent evt) {}
/*      */   private double alphaInit;
/*      */   private int scale;
/*      */   private boolean alreadyRun;
/*      */   private int totalWeeks;
/*      */   private long firstSeed;
/*      */   private boolean setCellChance;
/*      */   private boolean abDifference;
/*      */   private JLabel nuLabelA;
/*      */   private JLabel nuLabelB;
/*      */   private JSlider nuSliderA;
/*      */   
/*      */   private void samplingCheckboxActionPerformed(ActionEvent evt)
/*      */   {
/* 2303 */     if (this.samplingCheckbox.isSelected())
/*      */     {
/* 2304 */       this.sampleSizeLabel.setVisible(true);
/* 2305 */       this.sampleSizeTextField.setVisible(true);
/*      */       
/*      */ 
/* 2308 */       this.conPercentGraphicsPanel.sampling = true;
/*      */     }
/*      */     else
/*      */     {
/* 2310 */       this.sampleSizeLabel.setVisible(false);
/* 2311 */       this.sampleSizeTextField.setVisible(false);
/*      */       
/*      */ 
/* 2314 */       this.conPercentGraphicsPanel.sampling = false;
/*      */     }
/*      */   }
/*      */   
/*      */   private JSlider nuSliderB;
/*      */   private JTextField nuTextFieldA;
/*      */   private JTextField nuTextFieldB;
/*      */   private JPanel jPanel5;
/*      */   private JTextArea outputJTextArea;
/*      */   private javax.swing.JScrollPane scrollPane;
/*      */   private PrintStream newOut;
/*      */   private JButton exportParameters;
/*      */   private JButton importParameters;
/*      */   private void intResSliderStateChanged(ChangeEvent evt)
/*      */   {
/* 2319 */     this.intResTextField.setText(String.valueOf(this.intResSlider.getValue()));
/* 2320 */     this.nu = Double.parseDouble(this.nuTextField.getText());
/* 2321 */     this.mu = Double.parseDouble(this.muTextField.getText());
/* 2322 */     this.intConSlider.setValue((int)(Integer.parseInt(this.intResTextField.getText()) * (double)this.mu / (double)this.nu));
/*      */   }
/*      */   
/*      */   private void lambdaSliderStateChanged(ChangeEvent evt)
/*      */   {
/* 2326 */     this.lambdaTextField.setText(Util.Precision(this.lambdaSlider.getValue()/ ((double)this.scale), 1));
/* 2327 */     this.lambdaNuRatioTextField.setText(
/* 2328 */       Util.Precision(Float.parseFloat(this.nuTextField.getText()) / Float.parseFloat(this.lambdaTextField.getText()), 2));
/*      */   }
/*      */   
/*      */   private void nuSliderStateChanged(ChangeEvent evt)
/*      */   {
/* 2332 */     this.nuTextField.setText(Util.Precision(this.nuSlider.getValue() / ((double)this.scale), 1));
/* 2333 */     this.lambdaNuRatioTextField.setText(
/* 2334 */       Util.Precision(Float.parseFloat(this.nuTextField.getText()) / Float.parseFloat(this.lambdaTextField.getText()), 2));
/* 2335 */     this.nuMuRatioTextField.setText(
/* 2336 */       Util.Precision(Float.parseFloat(this.muTextField.getText()) / Float.parseFloat(this.nuTextField.getText()), 2));
/*      */   }
/*      */   
/*      */   private void creaturesComboBoxActionPerformed(ActionEvent evt)
/*      */   {
/* 2340 */     String s = this.creaturesComboBox.getSelectedItem().toString();
/* 2341 */     setParamInits(s.toLowerCase());
/* 2342 */     setSliderInitValues();
/* 2343 */     clearButtonActionPerformed(null);
/*      */     
/* 2345 */     this.abDiffBox.setSelected(false);
/* 2346 */     this.abDifference = false;
/*      */     
/* 2348 */     this.cellChance.setSelected(false);
/* 2349 */     cellChanceActionPerformed(null);
/*      */     
/* 2351 */     this.maxCellConCheckBox.setSelected(false);
/* 2352 */     this.maxCellConBoolean = false;
/* 2353 */     maxCellConCheckboxActionPerformed(null);
/*      */   }
/*      */   
/*      */   private void plotComboBoxActionPerformed(ActionEvent evt)
/*      */   {
/* 2358 */     String s = this.plotComboBox.getSelectedItem().toString();
/* 2359 */     if (s.startsWith("C"))
/*      */     {
/* 2360 */       this.contributingCompLabel.setText("Contributing Compartment");
/*      */       try
/*      */       {
/* 2362 */         this.jPanel2Layout.replace(this.resPercentGraphicsPanel, this.conPercentGraphicsPanel);
/*      */       }
/*      */       catch (IllegalArgumentException localIllegalArgumentException) {}
/*      */     }
/*      */     else
/*      */     {
/* 2367 */       this.contributingCompLabel.setText("Reserve Compartment");
/*      */       try
/*      */       {
/* 2369 */         this.jPanel2Layout.replace(this.conPercentGraphicsPanel, this.resPercentGraphicsPanel);
/*      */       }
/*      */       catch (IllegalArgumentException localIllegalArgumentException1) {}
/*      */     }
/*      */   }
/*      */   
/*      */   private JButton clearOutput;
/*      */   private double[] lastestRunParameters;
/*      */   private double cellChanceRate;
/*      */   private JSlider cellChanceRateSlider;
/*      */   private JLabel cellChanceRateLabel;
/*      */   private JPanel cellChanceSubPanel;
/*      */   private JCheckBox display;
/*      */   private JCheckBox useParaSameAsLastTime;
/*      */   private boolean displayParameters;
/*      */   private boolean useParaSameAsLastTimeBoolean;
/*      */   private String useParaSameAsLastTimeFileName;
/*      */   private JSlider plottingDelaySlider;
/*      */   private JLabel plottingDelayLabel;
/*      */   private JPanel plottingDelaySubPanel;
/*      */   private JComboBox plotComboBox;
/*      */   private GroupLayout jPanel2Layout;
/*      */   private JLabel kLabel2;
/*      */   private JSlider maxCellSlider2;
/*      */   private JTextField maxCellTextField2;
/*      */   
/*      */   private void totalWeeksTextFieldActionPerformed(ActionEvent evt) {}
/*      */   
/*      */   private void sampleIntervalTextFieldActionPerformed(ActionEvent evt) {}
/*      */   
/*      */   private void randomSeedTextFieldActionPerformed(ActionEvent evt) {}
/*      */   
/*      */   private void timeScrollBarAdjustmentValueChanged(AdjustmentEvent evt)
/*      */   {
/* 2389 */     this.ReserveGraphicsPanel.clearStat();
/* 2390 */     this.ContributingGraphicsPanel.clearStat();
/* 2391 */     double temp2 = this.timeScrollBar.getValue();
/* 2392 */     double value = Math.round(this.totalWeeks * temp2 / 1000.0D) / 1000.0D;
/*      */     
/* 2394 */     this.conPercentGraphicsPanel.setTimeLine(value);
/* 2395 */     this.resPercentGraphicsPanel.setTimeLine(value);
/*      */     
/*      */ 
/* 2398 */     this.ReserveGraphicsPanel.clearStat();
/* 2399 */     this.ContributingGraphicsPanel.clearStat();
/*      */     
/* 2401 */     int j = (int)Math.round(value / this.sampleInterval);
/* 2402 */     if (j > this.totalWeeks / this.sampleInterval) {
/* 2403 */       j--;
/*      */     }
/* 2405 */     this.ContributingGraphicsPanel.numOfA = this.mice2new.recCd[j];
/* 2406 */     this.ContributingGraphicsPanel.numOfB = (this.mice2new.recC[j] - this.mice2new.recCd[j]);
/* 2407 */     this.ReserveGraphicsPanel.numOfA = this.mice2new.recRd[j];
/* 2408 */     this.ReserveGraphicsPanel.numOfB = (this.mice2new.recR[j] - this.mice2new.recRd[j]);
/*      */     
/* 2410 */     this.currentTimeValueTextField.setText(String.valueOf(j * this.sampleInterval));
/*      */     
/* 2412 */     this.resTotalLabel.setText(String.valueOf(this.mice2new.recR[j]));
/* 2413 */     this.conTotalLabel.setText(String.valueOf(this.mice2new.recC[j]));
/* 2414 */     this.resDtypeLabel.setText(String.valueOf(this.mice2new.recRd[j]));
/* 2415 */     this.resGtypeLabel.setText(String.valueOf(this.mice2new.recR[j] - this.mice2new.recRd[j]));
/* 2416 */     this.conDtypeLabel.setText(String.valueOf(this.mice2new.recCd[j]));
/* 2417 */     this.conGtypeLabel.setText(String.valueOf(this.mice2new.recC[j] - this.mice2new.recCd[j]));
/* 2418 */     this.resPercentlLabel.setText(Util.Precision(100.0D * this.mice2new.recRd[j] / this.mice2new.recR[j], 1));
/* 2419 */     this.conPercentlLabel.setText(Util.Precision(100.0D * this.mice2new.recCd[j] / this.mice2new.recC[j], 1));
/* 2420 */     this.conSamplelLabel.setText(Util.Precision(100.0D * this.mice2new.recY[j] / this.sampleSize, 1));
/*      */     
/* 2422 */      this.ReserveGraphicsPanel.repaint();
				this.ContributingGraphicsPanel.repaint();
				this.resPercentGraphicsPanel.repaint();
				this.conPercentGraphicsPanel.repaint();
/*      */   }
/*      */   
/*      */   private void alphaSliderStateChanged(ChangeEvent evt)
/*      */   {
/* 2426 */     this.alphaTextField.setText(Util.Precision(this.alphaSlider.getValue() / (double)this.scale, 1));
/*      */   }
/*      */   
/*      */   private void muSliderStateChanged(ChangeEvent evt)
/*      */   {
/* 2430 */     this.muTextField.setText(Util.Precision(this.muSlider.getValue() / (double)this.scale, 1));
/* 2431 */     this.nuMuRatioTextField.setText(
/* 2432 */       Util.Precision(Float.parseFloat(this.muTextField.getText()) / Float.parseFloat(this.nuTextField.getText()), 2));
/*      */   }
/*      */   
/*      */   private void clearButtonActionPerformed(ActionEvent evt)
/*      */   {
/* 2437 */     this.totalWeeks = Integer.parseInt(this.totalWeeksTextField.getText());
/* 2438 */     this.conPercentGraphicsPanel.setTotalWeeks(this.totalWeeks);
/* 2439 */     this.resPercentGraphicsPanel.setTotalWeeks(this.totalWeeks);
/* 2440 */     this.conPercentGraphicsPanel.clearModel();
/* 2441 */     this.resPercentGraphicsPanel.clearModel();
/* 2442 */     this.timeScrollBar.setValue(0);
/* 2443 */     this.currentTimeValueTextField.setText("0.000");
/*      */     
/* 2445 */     this.R0 = Integer.parseInt(this.intResTextField.getText());
/* 2446 */     this.C0 = Integer.parseInt(this.intConTextField.getText());
/* 2447 */     this.percentR0a = Double.parseDouble(this.percentR0TextField.getText());
/* 2448 */     this.percentC0a = Double.parseDouble(this.percentC0TextField.getText());
/*      */     
/* 2450 */     this.resTotalLabel.setText(String.valueOf(this.R0));
/* 2451 */     this.conTotalLabel.setText(String.valueOf(this.C0));
/* 2452 */     this.resDtypeLabel.setText(" ");
/* 2453 */     this.resGtypeLabel.setText(" ");
/* 2454 */     this.resPercentlLabel.setText(" ");
/* 2455 */     this.conDtypeLabel.setText(" ");
/* 2456 */     this.conGtypeLabel.setText(" ");
/* 2457 */     this.conPercentlLabel.setText(" ");
/* 2458 */     this.conSamplelLabel.setText(" ");

/* 2461 */     this.ReserveGraphicsPanel.clearStat();
/* 2462 */     this.ContributingGraphicsPanel.clearStat();
				

				
/* 2463 */     
/*      */   }
/*      */   
/*      */   private void intConSliderStateChanged(ChangeEvent evt)
/*      */   {
/* 2467 */     this.intConTextField.setText(String.valueOf(this.intConSlider.getValue()));
/*      */   }
/*      */   private JCheckBox maxCellConCheckBox;
/*      */   private boolean maxCellConBoolean;
/*      */   private int N2;
/*      */   private double mutationProb;
/*      */   private double proportion;
/*      */   
/*      */   private void maxCellSliderStateChanged(ChangeEvent evt)
/*      */   {
/* 2471 */     this.maxCellTextField.setText(String.valueOf(this.maxCellSlider.getValue()));
/*      */   }
/*      */   
/*      */   private boolean noUpperLimitRes;
/*      */   private boolean runRandomeMutationMode;
/*      */   private JMenuBar menuBar;
/*      */   private JMenu menu;
/*      */   private JMenu subMenu1;
/*      */   
/*      */   private void intResTextFieldActionPerformed(ActionEvent evt)
/*      */   {
/*      */     try
/*      */     {
/* 2476 */       this.intResSlider.setValue(Integer.parseInt(this.intResTextField.getText()));
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/* 2478 */       this.intResTextField.setText(String.valueOf(30));
/*      */     }
/*      */   }
/*      */   
/*      */   private JMenu subMenu2;
/*      */   private JMenuItem menuItem1;
/*      */   private JMenuItem menuItem2;
/*      */   private JMenuItem menuItem3;
/*      */   private JMenuItem menuItem4;
/*      */   private JRadioButtonMenuItem radioButtonMenuItem1;
/*      */   private JRadioButtonMenuItem radioButtonMenuItem2;
/*      */   private JRadioButtonMenuItem radioButtonMenuItem3;
/*      */   private JRadioButtonMenuItem radioButtonMenuItem4;
/*      */   private JCheckBoxMenuItem checkBoxMenuItem1;
/*      */   private void exportButtonActionPerformed(ActionEvent evt)
/*      */   {
/* 2486 */     if (!this.alreadyRun) {
/* 2487 */       JOptionPane.showMessageDialog(this, "Please run simulation at least once.", "ERROR", 
/* 2488 */         0);
/*      */     } else {
/* 2490 */       outputResultsToTXT(1);
/*      */     }
/*      */   }
/*      */   
/*      */   private void writeResutlsOfSingleRunToTXT(PrintStream p, String runNumSep)
/*      */   {
/* 2495 */     int i = 0;
/* 2496 */     while (i <= this.L) {
/* 2497 */       p.printf(runNumSep + "%10.0f %10d %10d %10d %10d %10d \n", new Object[] { 
							Double.valueOf(i*this.sampleInterval), 
/* 2498 */         			Integer.valueOf(this.mice2new.recCd[i]), 
							Integer.valueOf(this.mice2new.recC[i]), 
							Integer.valueOf(this.mice2new.recRd[i]), 
/* 2499 */         			Integer.valueOf(this.mice2new.recR[i]), 
							Integer.valueOf(this.mice2new.recY[i])
							});
/* 2500 */       i++;
/*      */     }
/*      */   }

			 //sumFun : summary statistic functions
			 private static double mean(double[] m) {
				   double sum = 0;
				   for (int i = 0; i < m.length; i++) {
				        sum += m[i];
				   }
				   return sum / m.length;
			 }
			 
			 private static double var(double[] m) {
				 double sum = 0;
				 double stat_m = mean(m);
				 for (double a: m) {
					 sum += (a-stat_m)*(a-stat_m);
				 }
				 return sum/(m.length-1); 
			 }
			 
			 private static double Percentile(double[] array, double Percentile)
			 {
				 	java.util.Arrays.sort(array);
			        int Index = (int)Math.ceil(((double)Percentile / (double)100) * (double)array.length);
			        return array[Index-1];
			 }
			 
			 //output with summary statistics
			 private void outputWithSummaryToTxT(int runNum) {
				 //window for filename
				 String outputFileName = JOptionPane.showInputDialog("Enter the file name for the output results: (without suffix \" .txt\")");
				 
				 if (!outputFileName.equalsIgnoreCase("null")) {
					  //file for output result
					  String outputFileName_txt = outputFileName + ".txt";
					  String summaryFileName_txt = outputFileName + "sum.txt";

				      try
				      {
				    	// the original part for writing to files
				        File file = new File(outputFileName_txt);
				        File file_sum = new File(summaryFileName_txt);
				        
				        FileOutputStream updatedResults = new FileOutputStream(file, false);
				        FileOutputStream sumResults = new FileOutputStream(file_sum, false);
				        
				        PrintStream p = new PrintStream(updatedResults);
				        PrintStream p_sum = new PrintStream(sumResults);
				        
				        p.println("current creature is: " + this.creaturesComboBox.getSelectedItem().toString());
				        p_sum.println("current creature is: "  + this.creaturesComboBox.getSelectedItem().toString());
				        		         
				        if (runNum == 1) {
				           p.printf("%10s %10s %10s %10s %10s %10s \n", new Object[] { "Time", "Cd", "C", "Rd", "R", "Y" });
				           writeResutlsOfSingleRunToTXT(p, "");
				           
				           p_sum.printf("%10s %10s %10s %10s %10s %10s %10s %10s \n", 
				        		   new Object[] {"statistic","Cd", "C", "Rd", "R", "Y", "Cd/C","Rd/R"});
				           // more to go
	           
				           int i = this.L; // set to index representing the 400th weeks
			           
				           p_sum.printf("%10s %10d %10d %10d %10d %10d %10.04f %10.04f   \n", 
				        			new Object[] { "Mean", 
				        					Integer.valueOf(this.mice2new.recCd[i]),
				        					Integer.valueOf(this.mice2new.recC[i]),
				        					Integer.valueOf(this.mice2new.recRd[i]), 
				        					Integer.valueOf(this.mice2new.recR[i]), 
				        					Integer.valueOf(this.mice2new.recY[i])
				        					,Double.valueOf(((double)this.mice2new.recCd[this.L]/(double)this.mice2new.recC[this.L])),
				        					Double.valueOf(((double)this.mice2new.recRd[this.L]/(double)this.mice2new.recR[this.L]))
				        					});
				           
				           // more to go
				           p_sum.printf("%10s %10s %10s %10s %10s %10s %10s %10s \n", 
				        			new Object[] { "Var","-","-","-","-","-","-","-"
				        					});
				           
				           
				           p_sum.printf("%10s %10d %10d %10d %10d %10d %10.04f %10.04f  \n", 
				        			new Object[] { "5% Lower.B", 
				        					Integer.valueOf(this.mice2new.recCd[i]),
				        					Integer.valueOf(this.mice2new.recC[i]),
				        					Integer.valueOf(this.mice2new.recRd[i]), 
				        					Integer.valueOf(this.mice2new.recR[i]), 
				        					Integer.valueOf(this.mice2new.recY[i])
				        					,Double.valueOf(((double)this.mice2new.recCd[this.L]/(double)this.mice2new.recC[this.L])),
				        					Double.valueOf(((double)this.mice2new.recRd[this.L]/(double)this.mice2new.recR[this.L]))
				        					});
				           
				           p_sum.printf("%10s %10d %10d %10d %10d %10d %10.04f %10.04f  \n", 
				        			new Object[] { "95% Upper.B", 
				        					Integer.valueOf(this.mice2new.recCd[i]),
				        					Integer.valueOf(this.mice2new.recC[i]),
				        					Integer.valueOf(this.mice2new.recRd[i]), 
				        					Integer.valueOf(this.mice2new.recR[i]), 
				        					Integer.valueOf(this.mice2new.recY[i])
				        					,Double.valueOf(((double)this.mice2new.recCd[this.L]/(double)this.mice2new.recC[this.L])),
				        					Double.valueOf(((double)this.mice2new.recRd[this.L]/(double)this.mice2new.recR[this.L]))
				        					});
				           
				           
				        } else {
				           p.printf("%10s %10s %10s %10s %10s %10s %10s \n", new Object[] { "RunNum", "Time", "Cd", "C", 
				             "Rd", "R", "Y" });
				           
				           
				           p_sum.printf("%10s %10s %10s %10s %10s %10s %10s %10s \n", 
				        			new Object[] { "statistics","Cd", "C", "Rd", "R", "Y", "Cd/C","Rd/R"  });
				           
				           // add arrays
				           double[] Cd_array = new double[runNum];
				           double[] C_array = new double[runNum];
				           double[] Rd_array = new double[runNum];
				           double[] R_array = new double[runNum];
				           double[] Y_array = new double[runNum];
				           double[] CdC_array = new double[runNum];
				           double[] RdR_array = new double[runNum];
			           
				           for (int j = 0; j < runNum; j++){
				             performSimulation_noExtSeed();
				             writeResutlsOfSingleRunToTXT(p, (j+1) + "\t");
				             
				             Cd_array[j] = (double)Integer.valueOf(this.mice2new.recCd[this.L]);
				        	 C_array[j] = (double)Integer.valueOf(this.mice2new.recC[this.L]);
				        	 Rd_array[j] = (double)Integer.valueOf(this.mice2new.recRd[this.L]);
				        	 R_array[j] = (double)Integer.valueOf(this.mice2new.recR[this.L]);
				        	 Y_array[j] = (double)Integer.valueOf(this.mice2new.recY[this.L]);
				        	 CdC_array[j] = (double)this.mice2new.recCd[this.L]/(double)this.mice2new.recC[this.L];
				        	 RdR_array[j] = (double)this.mice2new.recRd[this.L]/(double)this.mice2new.recR[this.L];
				   
				           }
		           
				           p_sum.printf("%10s \t %.4f \t %.4f \t %.4f \t %.4f \t %.4f \t %.4f \t %.4f \n", 
				        			new Object[] { "Mean", 
				        					mean(Cd_array), 
				        					mean(C_array), 
				        					mean(Rd_array), 
				        					mean(R_array), 
				        					mean(Y_array),
				        					mean(CdC_array),
				        					mean(RdR_array)
				        					});
				           
				           p_sum.printf("%10s \t %.4f \t %.4f \t %.4f \t %.4f \t %.4f \t %.4f \t %.4f \n", 
				        			new Object[] { "Var", 
				        					var(Cd_array), 
				        					var(C_array), 
				        					var(Rd_array), 
				        					var(R_array), 
				        					var(Y_array),
				        					var(CdC_array),
				        					var(RdR_array)
				        					});
				           
				           p_sum.printf("%10s \t %.4f \t %.4f \t %.4f \t %.4f \t %.4f \t %.4f \t %.4f \n", 
				        			new Object[] { "5% Lower.B", 
				        					Percentile(Cd_array,5),
				        					Percentile(C_array,5), 
				        					Percentile(Rd_array,5), 
				        					Percentile(R_array,5), 
				        					Percentile(Y_array,5),
				        					Percentile(CdC_array,5),
				        					Percentile(RdR_array,5)
				        					});
				           
				           p_sum.printf("%10s \t %.4f \t %.4f \t %.4f \t %.4f \t %.4f \t %.4f \t %.4f \n", 
				        			new Object[] { "95% Upper.B", 
				        					Percentile(Cd_array,95),
				        					Percentile(C_array,95), 
				        					Percentile(Rd_array,95), 
				        					Percentile(R_array,95), 
				        					Percentile(Y_array,95),
				        					Percentile(CdC_array,95),
				        					Percentile(RdR_array,95)
				        					});
				        }
				         
				        p.close();
				        p_sum.close();
				        
				        //the above functions save results and the following part saves summary result
				        JOptionPane.showMessageDialog(this, "Simulation Results saved in " + outputFileName_txt);
				        JOptionPane.showMessageDialog(this, "Summary statistics saved in " + summaryFileName_txt);

				      }catch (Exception e) {
				         if ((e instanceof IOException)) {
				           JOptionPane.showMessageDialog(this, "Error in writing file! Try again.", "ERROR",0);
				         }
				      }
				}
			 }
/*      */   
/*      */   private void outputResultsToTXT(int runNum) {
/* 2505 */     String outputFileName = JOptionPane.showInputDialog("Enter the file name for the output results: (without suffix \" .txt\")");
/*      */     
/*      */ 
/* 2508 */     if (!outputFileName.equalsIgnoreCase("null")) {
/* 2509 */       outputFileName = outputFileName + ".txt";
/*      */       try
/*      */       {
/* 2512 */         File file = new File(outputFileName);
/* 2517 */         FileOutputStream updatedResults = new FileOutputStream(file, false);
/* 2518 */         PrintStream p = new PrintStream(updatedResults);
/* 2519 */         p.println("current creature is: " + this.creaturesComboBox.getSelectedItem().toString());
/*      */         
/* 2521 */         if (runNum == 1) {
/* 2522 */           p.printf("%10s %10s %10s %10s %10s %10s \n", new Object[] { "Time", "Cd", "C", "Rd", "R", "Y" });
/* 2523 */           writeResutlsOfSingleRunToTXT(p, "");
/*      */         } else {
/* 2525 */           p.printf("%6s %10s %10s %10s %10s %10s %10s \n", new Object[] { "RunNum", "Time", "Cd", "C", 
/* 2526 */             "Rd", "R", "Y" });
/* 2527 */           for (int j = 1; j <= runNum; j++) {
/* 2528 */             performSimulation_noExtSeed();
/* 2529 */             writeResutlsOfSingleRunToTXT(p, j + "\t");
/*      */           }
/*      */         }
/*      */         
/* 2533 */         p.close();
/*      */         
/* 2540 */         JOptionPane.showMessageDialog(this, "Results saved in " + outputFileName);
				   
/*      */       }
/*      */       catch (Exception e) {
/* 2543 */         if ((e instanceof IOException)) {
/* 2544 */           JOptionPane.showMessageDialog(this, "Error in writing file! Try again.", "ERROR", 
/* 2545 */             0);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private void exportResultsToRButtonActionPerformed(ActionEvent evt)
/*      */   {
/* 2553 */     if (!this.alreadyRun) {
/* 2554 */       JOptionPane.showMessageDialog(this, "Please run simulation at least once.", "ERROR", 
/* 2555 */         0);
/*      */     } else {
/* 2557 */       outputResultsToR(1);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private void writeResultsOfSingleRunToR(PrintStream p, String runNumSep)
/*      */   {
/* 2565 */     int i = 0;
/* 2496 */     while (i < this.L) {
/* 2497 */       p.printf(runNumSep + "%10.0f, %10d, %10d, %10d, %10d, %10d, \n", new Object[] { 
							Double.valueOf(i*this.sampleInterval), 
/* 2498 */         			Integer.valueOf(this.mice2new.recCd[i]), 
							Integer.valueOf(this.mice2new.recC[i]), 
							Integer.valueOf(this.mice2new.recRd[i]), 
/* 2499 */         			Integer.valueOf(this.mice2new.recR[i]), 
							Integer.valueOf(this.mice2new.recY[i])
							});
/* 2500 */       i++;
/*      */     };
			   p.printf(runNumSep + "%10.0f, %10d, %10d, %10d, %10d, %10d \n", new Object[] { 
						Double.valueOf(i*this.sampleInterval), 
						Integer.valueOf(this.mice2new.recCd[i]), 
						Integer.valueOf(this.mice2new.recC[i]), 
						Integer.valueOf(this.mice2new.recRd[i]), 
						Integer.valueOf(this.mice2new.recR[i]), 
						Integer.valueOf(this.mice2new.recY[i])
						});
/*      */   }
/*      */   
/*      */   private void outputResultsToR(int totalRunNum) {
/* 2577 */     String outputFileName = JOptionPane.showInputDialog("Enter the file name for the output results: (without suffix \" .R\")");
/*      */     String outputFileName_txt = outputFileName + ".R";
			   String summaryFileName_txt = outputFileName + "sum.txt";

				
/* 2581 */     if (!outputFileName.equalsIgnoreCase("null")) {
/* 2582 */       outputFileName = outputFileName + ".R";
/*      */       try
/*      */       {
/* 2585 */         File file = new File(outputFileName);
				   File file_sum = new File(summaryFileName_txt);

/* 2588 */         FileOutputStream updatedResults = new FileOutputStream(file, false);
				   FileOutputStream sumResults = new FileOutputStream(file_sum, false);
/* 2589 */         
				   PrintStream p = new PrintStream(updatedResults);
				   PrintStream p_sum = new PrintStream(sumResults);

/*      */         
/* 2591 */         p.println("# current creature is: " + this.creaturesComboBox.getSelectedItem().toString());
/* 2592 */         p.println(this.creaturesComboBox.getSelectedItem().toString().toLowerCase() + 
/* 2593 */           ".dat <- matrix(c(");

				   p_sum.println("current creature is: "  + this.creaturesComboBox.getSelectedItem().toString());
/*      */         
/* 2595 */         String runCol = "";
/* 2596 */         if (totalRunNum == 1) {
/* 2597 */           writeResultsOfSingleRunToR(p, " ");
/* 2598 */           p.println("), ncol=6, byrow=TRUE) \n");

					 p_sum.printf("%10s %10s %10s %10s %10s %10s %10s %10s \n", 
							 new Object[] {"statistic","Cd", "C", "Rd", "R", "Y", "Cd/C","Rd/R"});
					 
					 int i = this.L; // set to index representing the 400th weeks
			           
			         p_sum.printf("%10s %10d %10d %10d %10d %10d %10.4f %10.4f \n", 
			        			new Object[] { "Mean", 
			        					Integer.valueOf(this.mice2new.recCd[i]),
			        					Integer.valueOf(this.mice2new.recC[i]),
			        					Integer.valueOf(this.mice2new.recRd[i]), 
			        					Integer.valueOf(this.mice2new.recR[i]), 
			        					Integer.valueOf(this.mice2new.recY[i])
			        					,Double.valueOf(((double)this.mice2new.recCd[this.L]/(double)this.mice2new.recC[this.L])),
			        					Double.valueOf(((double)this.mice2new.recRd[this.L]/(double)this.mice2new.recR[this.L]))
			        					});
			           
			           // more to go
			         p_sum.printf("%10s %10s %10s %10s %10s %10s %10s %10s \n", 
			        			new Object[] { "Var","-","-","-","-","-","-","-"
			        					});
			         
			         p_sum.printf("%10s %10d %10d %10d %10d %10d %10.04f %10.04f  \n", 
			        			new Object[] { "5% Lower.B", 
			        					Integer.valueOf(this.mice2new.recCd[i]),
			        					Integer.valueOf(this.mice2new.recC[i]),
			        					Integer.valueOf(this.mice2new.recRd[i]), 
			        					Integer.valueOf(this.mice2new.recR[i]), 
			        					Integer.valueOf(this.mice2new.recY[i])
			        					,Double.valueOf(((double)this.mice2new.recCd[this.L]/(double)this.mice2new.recC[this.L])),
			        					Double.valueOf(((double)this.mice2new.recRd[this.L]/(double)this.mice2new.recR[this.L]))
			        					});
			           
			           p_sum.printf("%10s %10d %10d %10d %10d %10d %10.04f %10.04f  \n", 
			        			new Object[] { "95% Upper.B", 
			        					Integer.valueOf(this.mice2new.recCd[i]),
			        					Integer.valueOf(this.mice2new.recC[i]),
			        					Integer.valueOf(this.mice2new.recRd[i]), 
			        					Integer.valueOf(this.mice2new.recR[i]), 
			        					Integer.valueOf(this.mice2new.recY[i])
			        					,Double.valueOf(((double)this.mice2new.recCd[this.L]/(double)this.mice2new.recC[this.L])),
			        					Double.valueOf(((double)this.mice2new.recRd[this.L]/(double)this.mice2new.recR[this.L]))
			        					});
			         
			         
			         
/*      */         } 
				   else {
					   
					 p_sum.printf("%10s %10s %10s %10s %10s %10s %10s %10s \n", 
			        			new Object[] { "statistics","Cd", "C", "Rd", "R", "Y", "Cd/C","Rd/R"  });
					 
					// add arrays
			           double[] Cd_array = new double[totalRunNum];
			           double[] C_array = new double[totalRunNum];
			           double[] Rd_array = new double[totalRunNum];
			           double[] R_array = new double[totalRunNum];
			           double[] Y_array = new double[totalRunNum];
			           double[] CdC_array = new double[totalRunNum];
			           double[] RdR_array = new double[totalRunNum];
					 
/* 2600 */           for (int j = 0; j < totalRunNum; j++) {
/* 2601 */             performSimulation_noExtSeed();
/* 2602 */             writeResultsOfSingleRunToR(p, (j+1) + ",");
/* 2603 */             if (j < totalRunNum - 1) {
/* 2604 */               p.print(", \n");
/*      */            }

						Cd_array[j] = (double)Integer.valueOf(this.mice2new.recCd[this.L]);
						C_array[j] = (double)Integer.valueOf(this.mice2new.recC[this.L]);
						Rd_array[j] = (double)Integer.valueOf(this.mice2new.recRd[this.L]);
						R_array[j] = (double)Integer.valueOf(this.mice2new.recR[this.L]);
						Y_array[j] = (double)Integer.valueOf(this.mice2new.recY[this.L]);
						CdC_array[j] = (double)this.mice2new.recCd[this.L]/(double)this.mice2new.recC[this.L];
						RdR_array[j] = (double)this.mice2new.recRd[this.L]/(double)this.mice2new.recR[this.L];
					}

						p_sum.printf("%10s \t %.4f \t %.4f \t %.4f \t %.4f \t %.4f \t %.4f \t %.4f \n", 
								new Object[] { "Mean", 
										mean(Cd_array), 
										mean(C_array), 
										mean(Rd_array), 
										mean(R_array), 
										mean(Y_array),
										mean(CdC_array),
										mean(RdR_array)
										});
						
						p_sum.printf("%10s \t %.4f \t %.4f \t %.4f \t %.4f \t %.4f \t %.4f \t %.4f \n", 
								new Object[] { "Var", 
										var(Cd_array), 
										var(C_array), 
										var(Rd_array), 
										var(R_array), 
										var(Y_array),
										var(CdC_array),
										var(RdR_array)
										});
						
						p_sum.printf("%10s \t %.4f \t %.4f \t %.4f \t %.4f \t %.4f \t %.4f \t %.4f \n", 
			        			new Object[] { "5% Lower.B", 
			        					Percentile(Cd_array,5),
			        					Percentile(C_array,5), 
			        					Percentile(Rd_array,5), 
			        					Percentile(R_array,5), 
			        					Percentile(Y_array,5),
			        					Percentile(CdC_array,5),
			        					Percentile(RdR_array,5)
			        					});
			           
						p_sum.printf("%10s \t %.4f \t %.4f \t %.4f \t %.4f \t %.4f \t %.4f \t %.4f \n", 
			        			new Object[] { "95% Upper.B", 
			        					Percentile(Cd_array,95),
			        					Percentile(C_array,95), 
			        					Percentile(Rd_array,95), 
			        					Percentile(R_array,95), 
			        					Percentile(Y_array,95),
			        					Percentile(CdC_array,95),
			        					Percentile(RdR_array,95)
			        					});
/*      */           
/* 2608 */           p.println("), ncol=7, byrow=TRUE) \n");
/* 2609 */           runCol = "\"run.num\",";
/*      */         }
/*      */         
/* 2612 */         String sep = "\", \"";
/*      */         
/* 2614 */         p.println("colnames(" + this.creaturesComboBox.getSelectedItem().toString().toLowerCase() + 
/* 2615 */           ".dat) <- c(" + runCol + "\"Time" + sep + "Cd" + sep + "C" + sep + 
/* 2616 */           "Rd" + sep + "R" + sep + "Y\") ");
/* 2617 */         p.println(this.creaturesComboBox.getSelectedItem().toString().toLowerCase() + 
/* 2618 */           ".dat <- as.data.frame(" + 
/* 2619 */           this.creaturesComboBox.getSelectedItem().toString().toLowerCase() + ".dat) ");
/* 2620 */         p.close();

				   p_sum.close();
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2628 */         JOptionPane.showMessageDialog(this, "Results saved in " + outputFileName_txt);
				   JOptionPane.showMessageDialog(this, "Results saved in " + summaryFileName_txt);
/*      */       }
/*      */       catch (Exception e) {
/* 2631 */         if ((e instanceof IOException)) {
/* 2632 */           JOptionPane.showMessageDialog(this, "Error in writing file! Try again.", "ERROR", 
/* 2633 */             0);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private void multipleRunsExportToTXTButtonActionPerformed(ActionEvent evt) {
			   performSimulation();
/* 2640 */     int n = numberOfRuns();
/* 2641 */     if (n > 0) {
/* 2642 */       //outputResultsToTXT(n);
			     outputWithSummaryToTxT(n);
				 
/*      */     }
/*      */   }
/*      */   
/*      */   private void multipleRunsExportToRButtonActionPerformed(ActionEvent evt) {
			   performSimulation();
/* 2647 */     int n = numberOfRuns();
/* 2648 */     if (n > 0) {
/* 2649 */       outputResultsToR(n);
	             //outputWithSummaryToTxT(n);
/*      */     }
/*      */   }
/*      */   
/*      */   private int numberOfRuns() {
/* 2654 */     int n = -1;
/*      */     try
/*      */     {
/* 2657 */       String numStr = JOptionPane.showInputDialog("Enter the number of runs:");
/*      */       
/*      */ 
/* 2660 */       if (!numStr.equalsIgnoreCase("null")) {
/* 2661 */         n = Integer.parseInt(numStr);
/*      */         
/* 2663 */         if (n <= 0) {
/* 2664 */           throw new Exception();
/*      */         }
/*      */       }
/*      */     } catch (Exception e) {
/* 2668 */       JOptionPane.showMessageDialog(this, "The number of runs must be positive integer! Try again.", 
/* 2669 */         "ERROR", 0);
/*      */     }
/*      */     
/* 2672 */     return n;
/*      */   }
/*      */   
/*      */   private void setMutationProb()
/*      */   {
/* 2677 */     if (this.radioButtonMenuItem1.isSelected()) {
/* 2678 */       this.mutationProb = 0.001D;
/* 2679 */     } else if (this.radioButtonMenuItem2.isSelected()) {
/* 2680 */       this.mutationProb = 0.01D;
/*      */     }
/*      */   }
/*      */   
/*      */   private void setChangeProportion() {
/* 2685 */     if (this.radioButtonMenuItem3.isSelected()) {
/* 2686 */       this.proportion = 0.001D;
/* 2687 */     } else if (this.radioButtonMenuItem4.isSelected()) {
/* 2688 */       this.proportion = 0.01D;
/*      */     }
/*      */   }
/*      */   
/*      */   private void cellChanceActionPerformed(ActionEvent evt) {
/* 2693 */     this.setCellChance = this.cellChance.isSelected();
/* 2694 */     this.cellChanceRateLabel.setVisible(this.setCellChance);
/* 2695 */     this.cellChanceRateSlider.setVisible(this.setCellChance);
/*      */     
/* 2697 */     if (!this.setCellChance) {
/* 2698 */       this.cellChanceRateSlider.setValue(50);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   private void currentTimeValueTextFieldActionPerformed(ActionEvent evt) {}
/*      */   
/*      */ 
/*      */   private void runPauseButtonActionPerformed(ActionEvent evt)
/*      */   {
/* 2708 */     if (this.runPauseButton.getText().equalsIgnoreCase("Run")) {
/* 2709 */       clearButtonActionPerformed(evt);
/* 2710 */       this.t = new Thread(this);
/* 2711 */       this.t.start();
/* 2712 */       this.runPauseButton.setText("Stop");
/*      */     } else {
/* 2714 */       this.paused = true;
/* 2715 */       this.runPauseButton.setText("Run");
/*      */     }
/*      */   }
/*      */   
/*      */   private void abDiffBoxActionPerformed(ActionEvent evt) {
/* 2720 */     if (this.abDiffBox.isSelected()) {
/* 2721 */       this.abDifference = true;
/*      */     } else {
/* 2723 */       this.abDifference = false;
/*      */     }
/*      */   }
/*      */   
/*      */   private void alphaSliderAStateChanged(ChangeEvent evt) {
/* 2728 */     String result = Util.Precision(this.alphaSliderA.getValue() / (double)this.scale, 1);
/* 2729 */     this.alphaTextFieldA.setText(result);
/* 2730 */     if (!this.abDifference) {
/* 2731 */       this.alphaSliderB.setValue((int)(Double.parseDouble(result) * (double)this.scale));
/*      */     }
/*      */   }
/*      */   
/*      */   private void alphaTextFieldAActionPerformed(ActionEvent evt) {
/*      */     try {
/* 2737 */       int num = (int)(Double.parseDouble(this.alphaTextFieldA.getText()) * (double)this.scale);
/* 2738 */       this.alphaSliderA.setValue(num);
/* 2739 */       if (!this.abDifference) {
/* 2740 */         this.alphaSliderB.setValue(num);
/* 2741 */         this.alphaTextFieldB.setText(Util.Precision(num / (double)this.scale, 1));
/*      */       }
/*      */     } catch (Exception e) {
/* 2744 */       this.alphaSliderA.setValue(1000 * this.scale);
/* 2745 */       this.alphaTextFieldA.setText(String.valueOf(1000));
/*      */       
/* 2747 */       if (!this.abDifference) {
/* 2748 */         this.alphaSliderB.setValue(1000 * this.scale);
/* 2749 */         this.alphaTextFieldB.setText(String.valueOf(1000));
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private void alphaSliderBStateChanged(ChangeEvent evt) {
/* 2755 */     String result = Util.Precision(this.alphaSliderB.getValue() / (double)this.scale, 1);
/* 2756 */     this.alphaTextFieldB.setText(result);
/* 2757 */     if (!this.abDifference) {
/* 2758 */       this.alphaSliderA.setValue((int)(Double.parseDouble(result) * (double)this.scale));
/*      */     }
/*      */   }
/*      */   
/*      */   private void alphaTextFieldBActionPerformed(ActionEvent evt) {
/*      */     try {
/* 2764 */       int num = (int)(Double.parseDouble(this.alphaTextFieldB.getText()) * (double)this.scale);
/* 2765 */       this.alphaSliderB.setValue(num);
/* 2766 */       if (!this.abDifference) {
/* 2767 */         this.alphaSliderA.setValue(num);
/* 2768 */         this.alphaTextFieldA.setText(Util.Precision(num / (double)this.scale, 1));
/*      */       }
/*      */     } catch (Exception e) {
/* 2771 */       this.alphaSliderB.setValue(1000 * this.scale);
/* 2772 */       this.alphaTextFieldB.setText(String.valueOf(1000));
/*      */       
/* 2774 */       if (!this.abDifference) {
/* 2775 */         this.alphaSliderA.setValue(1000 * this.scale);
/* 2776 */         this.alphaTextFieldA.setText(String.valueOf(1000));
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private void muSliderAStateChanged(ChangeEvent evt) {
/* 2782 */     String result = Util.Precision(this.muSliderA.getValue() / (double)this.scale, 1);
/* 2783 */     this.muTextFieldA.setText(result);
/* 2784 */     if (!this.abDifference) {
/* 2785 */       this.muSliderB.setValue((int)(Double.parseDouble(result) * (double)this.scale));
/*      */     }
/*      */   }
/*      */   
/*      */   private void muTextFieldAActionPerformed(ActionEvent evt) {
/*      */     try {
/* 2791 */       int num = (int)(Double.parseDouble(this.muTextFieldA.getText()) * (double)this.scale);
/* 2792 */       this.muSliderA.setValue(num);
/* 2793 */       if (!this.abDifference) {
/* 2794 */         this.muSliderB.setValue(num);
/* 2795 */         this.muTextFieldB.setText(Util.Precision(num / (double)this.scale, 1));
/*      */       }
/*      */     } catch (Exception e) {
/* 2798 */       this.muSliderA.setValue((int)(6.7D * (double)this.scale));
/* 2799 */       this.muTextFieldA.setText(String.valueOf(6.7D));
/*      */       
/* 2801 */       if (!this.abDifference) {
/* 2802 */         this.muSliderB.setValue((int)(6.7D * (double)this.scale));
/* 2803 */         this.muTextFieldB.setText(String.valueOf(6.7D));
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private void muSliderBStateChanged(ChangeEvent evt) {
/* 2809 */     String result = Util.Precision(this.muSliderB.getValue() / (double)this.scale, 1);
/* 2810 */     this.muTextFieldB.setText(result);
/* 2811 */     if (!this.abDifference) {
/* 2812 */       this.muSliderA.setValue((int)(Double.parseDouble(result) * (double)this.scale));
/*      */     }
/*      */   }
/*      */   
/*      */   private void muTextFieldBActionPerformed(ActionEvent evt) {
/*      */     try {
/* 2818 */       int num = (int)(Double.parseDouble(this.muTextFieldB.getText()) * (double)this.scale);
/* 2819 */       this.muSliderB.setValue(num);
/* 2820 */       if (!this.abDifference) {
/* 2821 */         this.muSliderA.setValue(num);
/* 2822 */         this.muTextFieldA.setText(Util.Precision(num / (double)this.scale, 1));
/*      */       }
/*      */     } catch (Exception e) {
/* 2825 */       this.muSliderB.setValue((int)(6.7D * (double)this.scale));
/* 2826 */       this.muTextFieldB.setText(String.valueOf(6.7D));
/*      */       
/* 2828 */       if (!this.abDifference) {
/* 2829 */         this.muSliderA.setValue((int)(6.7D * (double)this.scale));
/* 2830 */         this.muTextFieldA.setText(String.valueOf(6.7D));
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private void lambdaSliderAStateChanged(ChangeEvent evt) {
/* 2836 */     String result = Util.Precision(this.lambdaSliderA.getValue() / (double)this.scale, 1);
/* 2837 */     this.lambdaTextFieldA.setText(result);
/* 2838 */     if (!this.abDifference)
/*      */     {
/* 2840 */       this.lambdaSliderB.setValue((int)(Double.parseDouble(result) * (double)this.scale));
/*      */     }
/*      */   }
/*      */   
/*      */   private void lambdaTextFieldAActionPerformed(ActionEvent evt) {
/*      */     try {
/* 2846 */       int num = (int)(Double.parseDouble(this.lambdaTextFieldA.getText()) * (double)this.scale);
/* 2847 */       this.lambdaSliderA.setValue(num);
/* 2848 */       if (!this.abDifference) {
/* 2849 */         this.lambdaSliderB.setValue(num);
/* 2850 */         this.lambdaTextFieldB.setText(Util.Precision(num / (double)this.scale, 1));
/*      */       }
/*      */     } catch (Exception e) {
/* 2853 */       this.lambdaSliderA.setValue(1000);
/* 2854 */       this.lambdaTextFieldA.setText(String.valueOf(10));
/*      */       
/* 2856 */       if (!this.abDifference) {
/* 2857 */         this.lambdaSliderB.setValue(1000);
/* 2858 */         this.lambdaTextFieldB.setText(String.valueOf(10));
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private void lambdaSliderBStateChanged(ChangeEvent evt) {
/* 2864 */     String result = Util.Precision(this.lambdaSliderB.getValue() / (double)this.scale, 1);
/* 2865 */     this.lambdaTextFieldB.setText(result);
/* 2866 */     if (!this.abDifference)
/*      */     {
/* 2868 */       this.lambdaSliderA.setValue((int)(Double.parseDouble(result) * (double)this.scale));
/*      */     }
/*      */   }
/*      */   
/*      */   private void lambdaTextFieldBActionPerformed(ActionEvent evt) {
/*      */     try {
/* 2874 */       int num = (int)(Double.parseDouble(this.lambdaTextFieldB.getText()) * (double)this.scale);
/* 2875 */       this.lambdaSliderB.setValue(num);
/* 2876 */       if (!this.abDifference) {
/* 2877 */         this.lambdaSliderA.setValue(num);
/* 2878 */         this.lambdaTextFieldA.setText(Util.Precision(num / (double)this.scale, 1));
/*      */       }
/*      */     } catch (Exception e) {
/* 2881 */       this.lambdaSliderB.setValue(1000);
/* 2882 */       this.lambdaTextFieldB.setText(String.valueOf(10));
/*      */       
/* 2884 */       if (!this.abDifference) {
/* 2885 */         this.lambdaSliderA.setValue(1000);
/* 2886 */         this.lambdaTextFieldA.setText(String.valueOf(10));
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private void nuSliderAStateChanged(ChangeEvent evt) {
/* 2892 */     String result = Util.Precision(this.nuSliderA.getValue() / (double)this.scale, 1);
/* 2893 */     this.nuTextFieldA.setText(result);
/* 2894 */     if (!this.abDifference) {
/* 2895 */       this.nuSliderB.setValue((int)(Double.parseDouble(result) * (double)this.scale));
/*      */     }
/*      */   }
/*      */   
/*      */   private void nuTextFieldAActionPerformed(ActionEvent evt) {
/*      */     try {
/* 2901 */       int num = (int)(Double.parseDouble(this.nuTextFieldA.getText()) * (double)this.scale);
/* 2902 */       this.nuSliderA.setValue(num);
/* 2903 */       if (!this.abDifference) {
/* 2904 */         this.nuSliderB.setValue(num);
/* 2905 */         this.nuTextFieldB.setText(Util.Precision(num / (double)this.scale, 1));
/*      */       }
/*      */     } catch (Exception e) {
/* 2908 */       this.nuSliderA.setValue((int)(12.5D * (double)this.scale));
/* 2909 */       this.nuTextFieldA.setText(String.valueOf(12.5D));
/*      */       
/* 2911 */       if (!this.abDifference) {
/* 2912 */         this.nuSliderB.setValue((int)(12.5D * (double)this.scale));
/* 2913 */         this.nuTextFieldB.setText(String.valueOf(12.5D));
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private void nuSliderBStateChanged(ChangeEvent evt) {
/* 2919 */     String result = Util.Precision(this.nuSliderB.getValue() / (double)this.scale, 1);
/* 2920 */     this.nuTextFieldB.setText(result);
/* 2921 */     if (!this.abDifference) {
/* 2922 */       this.nuSliderA.setValue((int)(Double.parseDouble(result) * (double)this.scale));
/*      */     }
/*      */   }
/*      */   
/*      */   private void nuTextFieldBActionPerformed(ActionEvent evt) {
/*      */     try {
/* 2928 */       int num = (int)(Double.parseDouble(this.nuTextFieldB.getText()) * (double)this.scale);
/* 2929 */       this.nuSliderB.setValue(num);
/* 2930 */       if (!this.abDifference) {
/* 2931 */         this.nuSliderA.setValue(num);
/* 2932 */         this.nuTextFieldA.setText(Util.Precision(num / (double)this.scale, 1));
/*      */       }
/*      */     } catch (Exception e) {
/* 2935 */       this.nuSliderB.setValue((int)(12.5D * (double)this.scale));
/* 2936 */       this.nuTextFieldB.setText(String.valueOf(12.5D));
/*      */       
/* 2938 */       if (!this.abDifference) {
/* 2939 */         this.nuSliderA.setValue((int)(12.5D * (double)this.scale));
/* 2940 */         this.nuTextFieldA.setText(String.valueOf(12.5D));
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private void screenshotButtonActionPerformed(ActionEvent evt)
/*      */   {
/*      */     try
/*      */     {
/* 2949 */       Robot robot = new Robot();
/*      */       
/* 2951 */       java.awt.image.BufferedImage bi = robot.createScreenCapture(new java.awt.Rectangle(1200, 800));
/* 2952 */       String outputFileName = JOptionPane.showInputDialog("Enter the file name for the ScreenShot image: (without suffix \" .jpg\")") + 
/* 2953 */         ".jpg";
/* 2954 */       javax.imageio.ImageIO.write(bi, "jpg", new File(outputFileName));
/*      */     } catch (AWTException e) {
/* 2956 */       e.printStackTrace();
/*      */     } catch (IOException e) {
/* 2958 */       e.printStackTrace();
/*      */     }
/*      */   }
/*      */   
/*      */   private void maxCellConCheckboxActionPerformed(ActionEvent evt) {
/* 2963 */     boolean boo = this.maxCellConCheckBox.isSelected();
/* 2964 */     this.kLabel2.setVisible(boo);
/* 2965 */     this.maxCellSlider2.setVisible(boo);
/* 2966 */     this.maxCellTextField2.setVisible(boo);
/* 2967 */     this.maxCellConBoolean = boo;
/*      */   }
 }


/* Location:              /Users/jasonxu/Desktop/HematopoiesisSimulator.jar!/hematopoiesissimulator/StatFrame2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */