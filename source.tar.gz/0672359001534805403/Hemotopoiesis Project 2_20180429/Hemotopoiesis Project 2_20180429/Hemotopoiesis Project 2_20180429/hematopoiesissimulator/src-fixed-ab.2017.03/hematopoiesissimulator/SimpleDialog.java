/*    */ package hematopoiesissimulator;
/*    */ 
/*    */ import java.awt.Container;
/*    */ import java.awt.event.ActionEvent;
/*    */ import java.awt.event.ActionListener;
/*    */ import javax.swing.Box;
/*    */ import javax.swing.JButton;
/*    */ import javax.swing.JDialog;
/*    */ import javax.swing.JFrame;
/*    */ import javax.swing.JLabel;
/*    */ import javax.swing.JPanel;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SimpleDialog
/*    */   extends JDialog
/*    */ {
/*    */   public SimpleDialog(JFrame parent, String msg)
/*    */   {
/* 23 */     super(parent, "Message", true);
/*    */     
/* 25 */     Box b = Box.createVerticalBox();
/* 26 */     b.add(Box.createGlue());
/* 27 */     b.add(new JLabel(msg));
/* 28 */     b.add(Box.createGlue());
/* 29 */     getContentPane().add(b, "Center");
/*    */     
/* 31 */     JPanel p2 = new JPanel();
/* 32 */     JButton ok = new JButton("Ok");
/* 33 */     p2.add(ok);
/* 34 */     getContentPane().add(p2, "South");
/*    */     
/* 36 */     ok.addActionListener(new ActionListener() {
/*    */       public void actionPerformed(ActionEvent evt) {
/* 38 */         SimpleDialog.this.setVisible(false);
/*    */       }
/*    */       
/* 41 */     });
/* 42 */     setSize(250, 150);
/*    */   }
/*    */ }


/* Location:              /Users/jasonxu/Desktop/HematopoiesisSimulator.jar!/hematopoiesissimulator/SimpleDialog.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */