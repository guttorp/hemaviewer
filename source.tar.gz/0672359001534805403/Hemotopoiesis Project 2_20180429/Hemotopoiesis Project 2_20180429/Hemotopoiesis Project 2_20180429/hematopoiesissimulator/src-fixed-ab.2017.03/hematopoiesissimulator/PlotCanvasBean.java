/*     */ package hematopoiesissimulator;
/*     */ 
/*     */ import java.awt.BasicStroke;
/*     */ import java.awt.Color;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Font;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.beans.PropertyChangeListener;
/*     */ import java.beans.PropertyChangeSupport;
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import javax.swing.JPanel;

/*     */ public class PlotCanvasBean
/*     */   extends JPanel
/*     */   implements Serializable //class declaration
/*     */ {
/*     */   public static final String PROP_SAMPLE_PROPERTY = "sampleProperty";
/*     */   private String sampleProperty;
/*  23 */   public boolean sampling = true;
/*     */   private PropertyChangeSupport propertySupport;
/*     */   private ArrayList<XY> xAndYSample;
/*     */   
/*     */   public String getSampleProperty() {
/*  28 */     return this.sampleProperty;
/*     */   }
/*     */   
/*     */   public void setSampleProperty(String value) {
/*  32 */     String oldValue = this.sampleProperty;
/*  33 */     this.sampleProperty = value;
/*  34 */     this.propertySupport.firePropertyChange("sampleProperty", oldValue, this.sampleProperty);
/*     */   }
/*     */   
/*     */   public void addPropertyChangeListener(PropertyChangeListener listener)
/*     */   {
/*  39 */     this.propertySupport.addPropertyChangeListener(listener);
/*     */   }
/*     */   
/*     */   public void removePropertyChangeListener(PropertyChangeListener listener) {
/*  43 */     this.propertySupport.removePropertyChangeListener(listener);
/*     */   }
/*     */   
/*     */   private ArrayList<XY> xAndYContin;
/*     */   private int width;
/*     */   private int height;
/*  49 */   private Color color = Color.black;
/*     */   private int inset;
/*     */   private double ymax;
/*     */   private double ymin;
/*     */   private double xmax;
/*     */   private double xmin;
/*     */   private double timeLine;
/*  56 */   private PlotCoord pc; 
			private Graphics gg; 
			boolean hasTimeLine; 
			boolean outOfMemory; 
			private String t = new String("System Out Of Memory");
/*  57 */   private int totalWeeks = 400;

/*     */ 	//initialization
/*     */   public PlotCanvasBean()
/*     */   {
/*  71 */     this.propertySupport = new PropertyChangeSupport(this);
/*     */     
/*  73 */     this.outOfMemory = false;
/*  74 */     this.hasTimeLine = false;
/*  75 */     this.xAndYSample = new ArrayList();
/*  76 */     this.xAndYContin = new ArrayList();
/*  77 */     this.ymin = 0.0D;
/*  78 */     this.ymax = 1.0D;
/*  79 */     this.xmin = 0.0D;
/*  80 */     this.xmax = this.totalWeeks;
/*  81 */     Dimension d = getSize();
/*  82 */     this.width = ((int)d.getWidth());
/*  83 */     this.height = ((int)d.getHeight());
/*  84 */     this.inset = 20;
/*     */     
/*  86 */     this.pc = new PlotCoord(this.xmax, this.ymax, this.xmin, this.ymin, this.width, this.height, this.inset);
/*     */   }
/*     */   
			
/*     */   public void setTotalWeeks(int _totalWeeks)
/*     */   {
/*  91 */     this.totalWeeks = _totalWeeks;
/*  92 */     this.xmax = this.totalWeeks;
/*  93 */     this.pc = new PlotCoord(this.xmax, this.ymax, this.xmin, this.ymin, this.width, this.height, this.inset);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void changeColor(Color inColor)
/*     */   {
/* 100 */     this.color = inColor;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setXmin(float newXmin)
/*     */   {
/* 108 */     this.xmin = newXmin;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public double getXmin()
/*     */   {
/* 115 */     return this.xmin;
/*     */   }
/*     */ 
/*     */   public void setXmax(float newXmax)
/*     */   {
/* 122 */     this.xmax = newXmax;
/*     */   }

/*     */   public void setOutOfMemory(boolean memory)
/*     */   {
/* 129 */     this.outOfMemory = memory;
/*     */   }

/*     */   private void initComponents() {}

/*     */   public void paint(Graphics g)
/*     */   {
/* 154 */     super.paint(g);
/* 155 */     this.gg = g;
/* 156 */     Dimension d = getSize();
/* 157 */     this.height = ((int)d.getHeight());
/* 158 */     this.width = ((int)d.getWidth());
/* 159 */     g.drawRect(0, 0, d.width - 1, d.height - 1);
/* 160 */     this.pc = new PlotCoord(this.xmax, this.ymax, this.xmin, this.ymin, this.width, this.height, this.inset);
/* 161 */     g.setColor(this.color);

/* 170 */     int xcoord = 0;
			  int ycoord = 0;

/* 174 */     double xaxisStart = this.xmax;
			  double xaxisEnd = this.xmin;
/* 175 */     double yaxisStart = this.ymax;
			  double yaxisEnd = this.ymin;
/*     */     
/*     */ 
/*     */     double yaxisPosx;
/*     */    
/*     */   
/*     */     
/* 182 */     if ((this.xmin < 0.0D) && (this.xmax > 0.0D)) {
/* 183 */       yaxisPosx = 0.0D;
/*     */     } else
/* 185 */       yaxisPosx = this.xmin;
/*     */     double xaxisPosy;
/* 187 */     if ((this.ymin < 0.0D) && (this.ymax > 0.0D)) {
/* 188 */       xaxisPosy = 0.0D;
/*     */     } else {
/* 190 */       xaxisPosy = this.ymin;
/*     */     }
/* 192 */     Font f = new Font("Dialog", 0, 10);
/* 193 */     g.setFont(f);
/*     */     
/*     */ 	  
/* 196 */     g.drawLine(this.pc.xcoord(xaxisStart), this.pc.ycoord(xaxisPosy) + 5, this.pc.xcoord(xaxisEnd), this.pc.ycoord(xaxisPosy) + 5);
/*     */     
/* 198 */     g.drawLine(this.pc.xcoord(yaxisPosx), this.pc.ycoord(yaxisStart), this.pc.xcoord(yaxisPosx), this.pc.ycoord(yaxisEnd) + 5);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 203 */     if ((this.xmin < 0.0D) && (this.xmax > 0.0D)) {
/* 204 */       xcoord = this.pc.xcoord(0.0D);
/* 205 */       ycoord = this.pc.ycoord(xaxisPosy);
/* 206 */       g.drawLine(xcoord, ycoord + 3, xcoord, ycoord - 3);
/* 207 */       g.drawString("0", xcoord - 5, ycoord + 15);
/*     */     }
/*     */     
/* 210 */     if ((this.ymin < 0.0D) && (this.ymax > 0.0D)) {
/* 211 */       ycoord = this.pc.ycoord(0.0D);
/* 212 */       xcoord = this.pc.xcoord(yaxisPosx);
/* 213 */       g.drawLine(xcoord + 3, ycoord, xcoord - 3, ycoord);
/* 214 */       g.drawString("0", xcoord + 7, ycoord + 10);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 220 */     ycoord = this.pc.ycoord(this.ymax);
/* 221 */     xcoord = this.pc.xcoord(yaxisPosx);
/* 222 */     g.drawLine(xcoord + 3, ycoord, xcoord - 3, ycoord);
/* 223 */     g.drawString("100%", xcoord - 19, ycoord + 5);
/*     */     
/*     */ 
/* 226 */     ycoord = this.pc.ycoord(this.ymin + (this.ymax - this.ymin) / 2.0D);
/* 227 */     xcoord = this.pc.xcoord(yaxisPosx);
/* 228 */     g.drawLine(xcoord + 3, ycoord, xcoord - 3, ycoord);
/* 229 */     g.drawString("50%", xcoord - 17, ycoord + 5);
/* 230 */     if (this.outOfMemory) {
/* 231 */       g.drawString(this.t, xcoord + 60, ycoord + 5);
/*     */     }
/*     */     
/*     */ 
/* 235 */     ycoord = this.pc.ycoord(this.ymin);
/* 236 */     xcoord = this.pc.xcoord(yaxisPosx);
/* 237 */     g.drawLine(xcoord + 3, ycoord, xcoord - 3, ycoord);
/* 238 */     g.drawString("0%", xcoord - 17, ycoord + 5);
/* 239 */     if (this.outOfMemory) {
/* 240 */       g.drawString(this.t, xcoord + 60, ycoord + 5);
/*     */     }
/*     */     
/*     */ 
/* 244 */     xcoord = this.pc.xcoord(this.xmin);
/* 245 */     ycoord = this.pc.ycoord(xaxisPosy);
/* 246 */     g.drawLine(xcoord, ycoord + 3, xcoord, ycoord - 3);
/* 247 */     g.drawString("0", xcoord - 5, ycoord + 15);
/*     */     
/*     */ 
/* 250 */     xcoord = this.pc.xcoord(this.xmin + (this.xmax - this.xmin) / 2.0D);
/* 251 */     ycoord = this.pc.ycoord(xaxisPosy);
/* 252 */     g.drawLine(xcoord, ycoord + 4, xcoord, ycoord - 3);
/* 253 */     g.drawString(Integer.toString(this.totalWeeks/2), xcoord - 5, ycoord + 15);
/*     */     
/*     */ 
/* 256 */     xcoord = this.pc.xcoord(this.xmax);
/* 257 */     ycoord = this.pc.ycoord(xaxisPosy);
/* 258 */     g.drawLine(xcoord, ycoord + 4, xcoord, ycoord - 3);
/* 259 */     g.drawString(this.totalWeeks + " weeks", xcoord - 40, ycoord + 15);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 267 */     if (this.sampling) {
/* 268 */       Iterator it = this.xAndYSample.iterator();
/* 269 */       if (it.hasNext()) {
/* 270 */         g.setColor(Color.MAGENTA);
/* 271 */         XY prevXY = (XY)it.next();
/*     */         
/* 273 */         while (it.hasNext()) {
/* 274 */           XY xY = (XY)it.next();
/* 275 */           if ((prevXY.getY() != Integer.MAX_VALUE) && (xY.getY() != Integer.MAX_VALUE))
/* 276 */             g.drawLine(prevXY.getX(), prevXY.getY(), xY.getX(), xY.getY());
/* 277 */           prevXY = xY;
/*     */         }
/* 279 */         g.setColor(Color.black);
/*     */       }
/*     */     }
/* 282 */     Iterator<XY> it = this.xAndYContin.iterator();
/* 283 */     if (it.hasNext()) {
/* 284 */       g.setColor(Color.black);
/* 285 */       XY prevXY = (XY)it.next();
/*     */       
/* 287 */       while (it.hasNext()) {
/* 288 */         XY xY = (XY)it.next();
/* 289 */         Graphics2D g2 = (Graphics2D)g;
/* 290 */         g2.setStroke(new BasicStroke(1.2F));
/* 291 */         if ((prevXY.getY() != Integer.MAX_VALUE) && (xY.getY() != Integer.MAX_VALUE))
/* 292 */           g2.drawLine(prevXY.getX(), prevXY.getY(), xY.getX(), xY.getY());
/* 293 */         prevXY = xY;
/*     */       }
/*     */     }
/*     */     
/* 297 */     if (this.hasTimeLine) {
/* 298 */       g.setColor(Color.GRAY);
/* 299 */       g.drawLine(this.pc.xcoord(this.timeLine), this.pc.ycoord(0.0D), this.pc.xcoord(this.timeLine), this.pc.ycoord(1.0D));
/* 300 */       g.setColor(Color.BLACK);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void clearModel()
/*     */   {
/* 309 */     this.xAndYSample.clear();
/* 310 */     this.xAndYContin.clear();
/*     */   }
/*     */   
/*     */   public void forcePaint() {
/* 314 */     Graphics g = getGraphics();
/*     */     
/*     */ 
/*     */ 
/* 318 */     if (this.sampling) {
/* 319 */       Iterator it = this.xAndYSample.iterator();
/* 320 */       if (it.hasNext()) {
/* 321 */         g.setColor(Color.MAGENTA);
/* 322 */         XY prevXY = (XY)it.next();
/*     */         
/* 324 */         while (it.hasNext()) {
/* 325 */           XY xY = (XY)it.next();
/* 326 */           g.drawLine(prevXY.getX(), prevXY.getY(), xY.getX(), xY.getY());
/* 327 */           prevXY = xY;
/*     */         }
/* 329 */         g.setColor(Color.black);
/*     */       }
/*     */     }
/* 332 */     Iterator it = this.xAndYContin.iterator();
/* 333 */     if (it.hasNext()) {
/* 334 */       g.setColor(Color.black);
/* 335 */       XY prevXY = (XY)it.next();
/*     */       
/* 337 */       while (it.hasNext()) {
/* 338 */         XY xY = (XY)it.next();
/* 339 */         Graphics2D g2 = (Graphics2D)g;
/* 340 */         g2.setStroke(new BasicStroke(1.2F));
/* 341 */         g2.drawLine(prevXY.getX(), prevXY.getY(), xY.getX(), xY.getY());
/* 342 */         prevXY = xY;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void updateSample(double x, double y)
/*     */   {
/* 353 */     int thisX = this.pc.xcoord(x);
/* 354 */     int thisY = this.pc.ycoord(y);
/*     */     
/* 356 */     this.xAndYSample.add(new XY(thisX, thisY));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void updateContin(double x, double y)
/*     */   {
/* 366 */     int thisX = this.pc.xcoord(x);
/* 367 */     int thisY = this.pc.ycoord(y);
/*     */     
/* 369 */     this.xAndYContin.add(new XY(thisX, thisY));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTimeLine(double time)
/*     */   {
/* 379 */     this.timeLine = time;
/* 380 */     this.hasTimeLine = true;
/*     */   }
/*     */ }


/* Location:              /Users/jasonxu/Desktop/HematopoiesisSimulator.jar!/hematopoiesissimulator/PlotCanvasBean.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */