/*     */ package simulatorcore;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LinkedRateList
/*     */ {
/*     */   private RateNode front;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int size;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public LinkedRateList()
/*     */   {
/*  24 */     this.front = null;
/*  25 */     this.size = 0;
/*     */   }
/*     */   
/*     */   public void add(double rate)
/*     */   {
/*  30 */     add(size(), rate);
/*     */   }
/*     */   
/*     */ 
/*     */   public void add(int index, double rate)
/*     */   {
/*  36 */     if (index == 0) {
/*  37 */       this.front = new RateNode(rate, this.front);
/*     */     } else {
/*  39 */       RateNode current = this.front;
/*  40 */       for (int i = 0; i < index - 1; i++) {
/*  41 */         current = current.next;
/*     */       }
/*     */       
/*  44 */       RateNode newNode = new RateNode(rate, current.next);
/*  45 */       current.next = newNode;
/*     */     }
/*  47 */     this.size += 1;
/*     */   }
/*     */   
/*     */ 
/*     */   public double get(int index)
/*     */   {
/*  53 */     RateNode current = this.front;
/*  54 */     for (int i = 0; i < index; i++) {
/*  55 */       current = current.next;
/*     */     }
/*  57 */     return current.data;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void remove(int index)
/*     */   {
/*  64 */     if (index == 0)
/*     */     {
/*  66 */       this.front = this.front.next;
/*     */     } else {
/*  68 */       RateNode current = this.front;
/*  69 */       for (int i = 0; i < index - 1; i++) {
/*  70 */         current = current.next;
/*     */       }
/*     */       
/*  73 */       current.next = current.next.next;
/*     */     }
/*  75 */     this.size -= 1;
/*     */   }
/*     */   
/*     */ 
/*     */   public void set(int index, double rate)
/*     */   {
/*  81 */     RateNode current = this.front;
/*  82 */     for (int i = 0; i < index; i++) {
/*  83 */       current = current.next;
/*     */     }
/*  85 */     current.data = rate;
/*     */   }
/*     */   
/*     */   public int size()
/*     */   {
/*  90 */     return this.size;
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/*  95 */     if (this.front == null) {
/*  96 */       return "[]";
/*     */     }
/*  98 */     String result = "[" + this.front.data;
/*  99 */     RateNode current = this.front.next;
/* 100 */     while (current != null) {
/* 101 */       result = result + ", " + current.data;
/* 102 */       current = current.next;
/*     */     }
/* 104 */     result = result + "]";
/* 105 */     return result;
/*     */   }
/*     */ }


/* Location:              /Users/jasonxu/Desktop/HematopoiesisSimulator.jar!/simulatorcore/LinkedRateList.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */