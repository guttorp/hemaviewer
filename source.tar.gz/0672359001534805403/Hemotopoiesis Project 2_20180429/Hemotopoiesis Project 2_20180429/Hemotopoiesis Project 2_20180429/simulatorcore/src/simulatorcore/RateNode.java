/*    */ package simulatorcore;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RateNode
/*    */ {
/*    */   public double data;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public RateNode next;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public RateNode(double rate)
/*    */   {
/* 23 */     this(rate, null);
/*    */   }
/*    */   
/*    */   public RateNode(double rate, RateNode next)
/*    */   {
/* 28 */     this.data = rate;
/* 29 */     this.next = next;
/*    */   }
/*    */ }


/* Location:              /Users/jasonxu/Desktop/HematopoiesisSimulator.jar!/simulatorcore/RateNode.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */