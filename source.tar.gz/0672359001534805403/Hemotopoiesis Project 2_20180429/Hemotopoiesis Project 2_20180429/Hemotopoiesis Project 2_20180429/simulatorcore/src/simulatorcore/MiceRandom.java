/*     */ package simulatorcore;
/*     */ 
/*     */ import edu.rit.util.Random;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MiceRandom
/*     */ {
/*     */   public static final double PI = 3.141592653589793D;
/*     */   public static final double EE = 2.718281828459046D;
/*     */   public static final double RAND_MAX = 32767.0D;
/*     */   public static double rxxx1;
/*     */   
/*     */   public MiceRandom(int seed)
/*     */   {
/*  16 */     this.random = Random.getInstance(seed);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  25 */   public static int ixxx1 = 0;
/*     */   
/*     */ 
/*     */   public Random random;
/*     */   
/*     */ 
/*     */ 
/*     */   public double runi()
/*     */   {
/*  34 */     return this.random.nextDouble(100L);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public double runi2()
/*     */   {
/*  43 */     return (this.random.nextDouble() * 32767.0D * 32768.0D + 
/*  44 */       this.random.nextDouble() * 32767.0D + 1.0D) / 
/*  45 */       1.073741825E9D;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public double runir(double dA, double dB)
/*     */   {
/*  52 */     return (dB - dA) * runi() + dA;
/*     */   }
/*     */   
/*     */ 
/*     */   public double runir2(double dA, double dB)
/*     */   {
/*  58 */     return (dB - dA) * runi2() + dA;
/*     */   }
/*     */   
/*     */ 
/*     */   public int runii(int iA, int iB)
/*     */   {
/*  64 */     return (int)Math.floor(runi2() * (iB - iA + 1.0D)) + iA;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public double rnor(double dMu, double dSd)
/*     */   {
/*  71 */     double dE = 0.0D;
/*  72 */     double dV1 = 0.0D;
/*  73 */     double dV2 = 0.0D;
/*  74 */     double dW = 0.0D;
/*     */     
/*  76 */     if (ixxx1 == 0)
/*     */     {
/*     */       do
/*     */       {
/*  80 */         dV1 = 2.0D * runi() - 1.0D;
/*  81 */         dV2 = 2.0D * runi() - 1.0D;
/*  82 */         dW = dV1 * dV1 + dV2 * dV2;
/*  83 */       } while (dW > 1.0D);
/*     */       
/*  85 */       dE = Math.sqrt(-2.0D * Math.log(dW) / dW);
/*  86 */       rxxx1 = dV1 * dE;
/*  87 */       ixxx1 = 1;
/*  88 */       return dV2 * dE * dSd + dMu;
/*     */     }
/*     */     
/*     */ 
/*  92 */     ixxx1 = 0;
/*  93 */     return rxxx1 * dSd + dMu;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public double rcnor(double dMu, double dSd)
/*     */   {
/* 104 */     double dResult = 0.0D;
/* 105 */     double dUnit = 0.0D;
/* 106 */     for (int i = 1; i <= 12; i++)
/*     */     {
/* 108 */       dUnit += runi();
/*     */     }
/* 110 */     dResult = dMu + dSd * (dUnit - 6.0D);
/* 111 */     return dResult;
/*     */   }
/*     */   
/*     */   public double rigaus(double dMu, double dLambda)
/*     */   {
/* 116 */     double dU = 0.0D;
/* 117 */     double dV = 0.0D;
/* 118 */     double dW = 0.0D;
/* 119 */     double dC = 0.0D;
/* 120 */     double dX1 = 0.0D;
/*     */     
/* 122 */     dU = rnor(0.0D, 1.0D);
/* 123 */     dV = dU * dU;
/* 124 */     dW = dMu * dV;
/* 125 */     dC = dMu / (2.0D * dLambda);
/* 126 */     dX1 = dMu + dC * (dW - Math.sqrt(dW * (4.0D * dLambda + dW)));
/*     */     
/* 128 */     return runi() > dMu / (dMu + dX1) ? dMu * dMu / dX1 : dX1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int rpois(double dMu)
/*     */   {
/* 135 */     double dP = 1.0D;
/* 136 */     int i = 0;
/*     */     
/* 138 */     if (dMu <= 0.0D)
/*     */     {
/* 140 */       return 0;
/*     */     }
/*     */     
/* 143 */     dMu = Math.exp(-dMu);
/*     */     do
/*     */     {
/* 146 */       dP *= runi();
/* 147 */       i++;
/* 148 */     } while (dP >= dMu);
/*     */     
/* 150 */     return i - 1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public double rexp(double dLambda)
/*     */   {
/* 157 */     return -Math.log(runi()) / dLambda;
/*     */   }
/*     */   
/*     */ 
/*     */   public double rcauchy(double dLoc, double dScale)
/*     */   {
/* 163 */     return Math.tan((runi() - 0.5D) * 3.141592653589793D) * dScale + dLoc;
/*     */   }
/*     */   
/*     */ 
/*     */   public double rncauchy(double dLoc, double dScale)
/*     */   {
/* 169 */     double dNscale = dScale * 0.67D;
/* 170 */     return Math.tan((runi() - 0.5D) * 3.141592653589793D) * dNscale + dLoc;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public double rgamma(double dAlpha)
/*     */   {
/* 177 */     if (dAlpha <= 0.0D)
/*     */     {
/* 179 */       return 0.0D;
/*     */     }
/*     */     
/* 182 */     if (dAlpha == 1.0D)
/*     */     {
/* 184 */       return rexp(1.0D);
/*     */     }
/*     */     
/* 187 */     if (dAlpha < 1.0D)
/*     */     {
/* 189 */       double dAA = (dAlpha + 2.718281828459046D) / 2.718281828459046D;
/*     */       double dR2;
/*     */       do {
/* 192 */         double dR1 = runi();
/* 193 */         dR2 = runi();
/*     */         
/* 195 */         if (dR1 > 1.0D / dAA)
/*     */         {
/* 197 */           double dX = -Math.log(dAA * (1.0D - dR1) / dAlpha);
/*     */           
/* 199 */           if (dR2 < Math.pow(dX, dAlpha - 1.0D))
/*     */           {
/* 201 */             return dX;
/*     */           }
/*     */         }
/*     */         else
/*     */         {
/* 206 */           double dX = Math.pow(dAA * dR1, 1.0D / dAlpha);
/* 207 */           if (dR2 < Math.exp(-dX))
/*     */           {
/* 209 */             return dX;
/*     */           }
/*     */         }
/* 212 */       } while (dR2 < 2.0D);
/*     */     }
/*     */     else
/*     */     {
/* 216 */       double dC1 = dAlpha - 1.0D;
/* 217 */       double dC2 = (dAlpha - 1.0D / (6.0D * dAlpha)) / dC1;
/* 218 */       double dC3 = 2.0D / dC1;
/* 219 */       double dC4 = dC3 + 2.0D;
/* 220 */       double dC5 = 1.0D / Math.sqrt(dAlpha);
/*     */       double dR2;
/*     */       do {
/*     */         double dR1;
/*     */         do {
/* 225 */           dR1 = runi();
/* 226 */           dR2 = runi();
/*     */           
/* 228 */           if (dAlpha > 2.5D)
/*     */           {
/* 230 */             dR1 = dR2 + dC5 * (1.0D - 1.86D * dR1);
/*     */           }
/* 232 */         } while ((dR1 <= 0.0D) || (dR1 >= 1.0D));
/*     */         
/* 234 */         double dW = dC2 * dR2 / dR1;
/*     */         
/* 236 */         if (dC3 * dR1 + dW + 1.0D / dW <= dC4)
/*     */         {
/* 238 */           return dC1 * dW;
/*     */         }
/*     */         
/* 241 */         if (dC3 * Math.log(dR1) - Math.log(dW) + dW < 1.0D)
/*     */         {
/* 243 */           return dC1 * dW;
/*     */         }
/* 245 */       } while (dR2 < 2.0D);
/*     */     }
/*     */     
/* 248 */     return 0.0D;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public double rbeta(double dAlpha, double dBeta)
/*     */   {
/* 256 */     if ((dAlpha <= 0.0D) || (dBeta <= 0.0D))
/*     */     {
/* 258 */       return 0.0D;
/*     */     }
/*     */     
/* 261 */     double dR1 = rgamma(dAlpha);
/* 262 */     return dR1 / (dR1 + rgamma(dBeta));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int rdirichlet(double[] adP, double[] adAlpha, long k)
/*     */   {
/* 270 */     double dTotal = 0.0D;
/*     */     
/* 272 */     for (int j = 0; j < k; j++)
/*     */     {
/* 274 */       adP[j] = rgamma(adAlpha[j]);
/* 275 */       dTotal += adP[j];
/*     */     }
/*     */     
/* 278 */     for (int j = 0; j < k; j++)
/*     */     {
/* 280 */       adP[j] /= dTotal;
/*     */     }
/*     */     
/* 283 */     return 1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int rdanish(double[] adP, double[] adAlpha, double dGamma, int k)
/*     */   {
/* 294 */     double dTotal = 0.0D;
/*     */     
/* 296 */     for (int i = 0; i < k; i++)
/*     */     {
/* 298 */       double dLambda = dGamma * adAlpha[i] * adAlpha[i];
/* 299 */       adP[i] = rigaus(adAlpha[i], dLambda);
/* 300 */       dTotal += adP[i];
/*     */     }
/*     */     
/* 303 */     for (int i = 0; i < k; i++)
/*     */     {
/* 305 */       adP[i] /= dTotal;
/*     */     }
/*     */     
/* 308 */     return 1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int rmultnom(long[] aiCount, long n, double[] adPr, long k)
/*     */   {
/* 316 */     long ulSum = 0L;
/*     */     
/*     */ 
/*     */ 
/* 320 */     for (int i = 0; i < k; i++)
/*     */     {
/* 322 */       aiCount[i] = 0L;
/*     */     }
/*     */     
/* 325 */     for (long j = 0L; j < n; j += 1L)
/*     */     {
/* 327 */       double dProb = 0.0D;
/* 328 */       double dPick = runi();
/*     */       
/* 330 */       for (int i = 0; i < k - 1L; i++)
/*     */       {
/* 332 */         dProb += adPr[i];
/*     */         
/* 334 */         if (dPick < dProb)
/*     */         {
/* 336 */           aiCount[i] += 1L;
/* 337 */           ulSum += 1L;
/* 338 */           break;
/*     */         }
/*     */       }
/*     */     }
/* 342 */     aiCount[((int)k - 1)] = (n - ulSum);
/* 343 */     return 1;
/*     */   }
/*     */   
/*     */ 
/*     */   public long rmultnom1(double[] adPr, long k)
/*     */   {
/* 349 */     double dP = runi();
/* 350 */     double dSum = 0.0D;
/* 351 */     int i = 0;
/*     */     
/* 353 */     for (i = 0; i < k; i++)
/*     */     {
/* 355 */       dSum += adPr[i];
/*     */       
/* 357 */       if (dSum > dP)
/*     */       {
/* 359 */         return i;
/*     */       }
/*     */     }
/*     */     
/* 363 */     return k - 1L;
/*     */   }
/*     */   
/*     */ 
/*     */   public double rlogistic(double dLoc, double dScale)
/*     */   {
/* 369 */     return 1.0D / (1.0D - runi()) - 1.0D;
/*     */   }
/*     */   
/*     */ 
/*     */   public double rlnorm(double dNorm, double dNorsd)
/*     */   {
/* 375 */     return Math.exp(rnor(dNorm, dNorsd));
/*     */   }
/*     */   
/*     */ 
/*     */   public int rbin(int n, double p)
/*     */   {
/* 381 */     int j = 0;
/* 382 */     int k = 0;
/* 383 */     for (k = 0; k < n; k++)
/*     */     {
/* 385 */       if (runi() < p)
/*     */       {
/* 387 */         j++;
/*     */       }
/*     */     }
/* 390 */     return j;
/*     */   }
/*     */   
/*     */ 
/*     */   public double rweibull(double dGamma)
/*     */   {
/* 396 */     if (dGamma <= 0.0D)
/*     */     {
/* 398 */       return 0.0D;
/*     */     }
/* 400 */     return Math.pow(rexp(1.0D), 1.0D / dGamma);
/*     */   }
/*     */   
/*     */ 
/*     */   public double rchisq(double dT)
/*     */   {
/* 406 */     return rgamma(dT / 2.0D) * 2.0D;
/*     */   }
/*     */   
/*     */ 
/*     */   public double rf(double dT, double dU)
/*     */   {
/* 412 */     if ((dT <= 0.0D) || (dU <= 0.0D))
/*     */     {
/* 414 */       return 0.0D;
/*     */     }
/* 416 */     return rchisq(dT) * dU / (dT * rchisq(dU));
/*     */   }
/*     */   
/*     */ 
/*     */   public double rstudent(double dT)
/*     */   {
/* 422 */     if (dT <= 0.0D)
/*     */     {
/* 424 */       return 0.0D;
/*     */     }
/* 426 */     return rnor(0.0D, 1.0D) / Math.sqrt(rchisq(dT) / dT);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int rperm(long[] piResult, int n)
/*     */   {
/* 437 */     for (int i = 0; i < n; i++)
/*     */     {
/* 439 */       int iNew = runii(i, n - 1);
/* 440 */       int iSample = (int)piResult[iNew];
/* 441 */       int iSpare = (int)piResult[i];
/* 442 */       piResult[i] = iSample;
/* 443 */       piResult[iNew] = iSpare;
/*     */     }
/*     */     
/* 446 */     return 1;
/*     */   }
/*     */   
/*     */ 
/*     */   public int rperm_some(long[] piResult, long cLength, long cPermute)
/*     */   {
/* 452 */     int i = 0;
/* 453 */     long ulTemp = 0L;
/* 454 */     int iNew = 0;
/*     */     
/* 456 */     for (i = 0; i < cPermute; i++)
/*     */     {
/* 458 */       iNew = runii(i, (int)cLength - 1);
/* 459 */       ulTemp = piResult[iNew];
/* 460 */       piResult[iNew] = piResult[i];
/* 461 */       piResult[i] = ulTemp;
/*     */     }
/*     */     
/* 464 */     return 0;
/*     */   }
/*     */ }


/* Location:              /Users/jasonxu/Desktop/HematopoiesisSimulator.jar!/simulatorcore/MiceRandom.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */