/*     */ package simulatorcore;
/*     */ 
/*     */ import edu.rit.util.Random;
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.util.ArrayList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HumanRandomMutation
/*     */   extends MiceRandom
/*     */ {
/*     */   private final int L;
/*     */   private final int set;
/*     */   
/*     */   public static void main(String[] args)
/*     */     throws IOException
/*     */   {
/*  33 */     double lambdaInit = 40.0D;
/*  34 */     double nuInit = 56.1D;
/*  35 */     double muInit = 6.7D;
/*  36 */     double alphaInit = 285.7D;
/*     */     
/*  38 */     double lambda = 40.0D;
/*  39 */     double mu = 6.7D;
/*  40 */     double alpha = 285.7D;
/*  41 */     double nu = 56.1D;
/*  42 */     double mll = 1.0D;double mva = 1.0D;double dvv = 1.0D;double dvu = 1.0D;double ratio_as = 1.0D;
/*     */     
/*  44 */     double l = 1.0D / lambda;
/*  45 */     double lb = 0.0D;
/*  46 */     double v = 1.0D / nu;
/*  47 */     double u = 1.0D / mu;
/*  48 */     double a = 1.0D / alpha;
/*  49 */     double as = 0.0D;
/*  50 */     double ld = l * mll;
/*  51 */     double ldb = 1.0D * mll;
/*  52 */     double ad = a * mva;
/*  53 */     double vd = v * dvv;
/*  54 */     double ud = u * dvu;
/*  55 */     double asd = as * ratio_as;
/*  56 */     String[] events = { "B", "E", "D", "Ap" };
/*  57 */     double[] rates = { l, v, u, a, ld, vd, ud, ad };
/*     */     
/*     */ 
/*  60 */     double Rpercent = 0.0D;
/*  61 */     double Cpercent = Rpercent;
/*     */     
/*  63 */     int sampleSize = 70;
/*  64 */     boolean setCellChance = false;
/*     */     
/*     */ 
/*     */ 
/*  68 */     int seed = 17;
/*     */     
/*  70 */     double cellChanceRate = 0.5D;
/*     */     
/*     */ 
/*  73 */     int totalWeeks = 520;
/*  74 */     int sampleInterval = 52;
/*  75 */     int R0 = 10000;
/*  76 */     double mutationProb = 0.001D;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  83 */     int C0 = (int)(R0 / nu / (1.0D / lambda - 1.0D / alpha - 1.0D / nu + 1.0D / mu));
/*     */     
/*     */ 
/*  86 */     int L = totalWeeks / sampleInterval;
/*  87 */     int set = 1;
/*  88 */     int N = 10000;
/*     */     
/*     */ 
/*  91 */     long tic = System.currentTimeMillis();
/*     */     
/*     */ 
/*     */ 
/*  95 */     PrintStream p = System.out;
/*     */     
/*  97 */     p.println("ArrayList.2010");
/*  98 */     p.println("Human: initial number of type a/type d cells in the Reserve compartment is Rd0 = 1.");
/*     */     
/* 100 */     p.println("R0 = " + R0 + ", C0 = " + C0 + ". Total " + totalWeeks + " weeks. Sample size = 70.");
/* 101 */     p.println("Sample Interval = " + sampleInterval);
/* 102 */     p.println("Regular cell mutation probability = " + mutationProb);
/* 103 */     p.println("mutated cell with brith rate (rate of parental cell + epsilon)");
/* 104 */     p.println("where epsilon ~ Unif(0, (rate of parental cell) / 100)");
/* 105 */     p.println();
/*     */     
/*     */ 
/* 108 */     for (int i = 1; i <= 10; i++) {
/* 109 */       p.println("Run #" + i);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 118 */       HumanRandomMutation mice2new = new HumanRandomMutation(L, set, N, 1, R0, 0, C0, 
/* 119 */         rates, events, sampleSize, seed, sampleInterval, 
/* 120 */         setCellChance, cellChanceRate, false, N, mutationProb, p);
/*     */       
/*     */ 
/* 123 */       mice2new.simulate("");
/*     */       
/* 125 */       p.printf("%10s %10s %10s %10s %10s %10s \n", new Object[] { "Time", "Cd", "C", "Rd", "R", "Y" });
/*     */       
/* 127 */       int k = 0;
/* 128 */       while (k <= L) {
/* 129 */         p.printf("%10d %10d %10d %10d %10d %10d \n", new Object[] { Integer.valueOf(k * sampleInterval), 
/* 130 */           Integer.valueOf(mice2new.recCd[k]), Integer.valueOf(mice2new.recC[k]), Integer.valueOf(mice2new.recRd[k]), 
/* 131 */           Integer.valueOf(mice2new.recR[k]), Integer.valueOf(mice2new.recY[k]) });
/* 132 */         k++;
/*     */       }
/* 134 */       seed = (int)(mice2new.random.nextDouble() * 1.0E9D);
/* 135 */       p.println();
/*     */     }
/*     */     
/*     */ 
/* 139 */     long toc = System.currentTimeMillis();
/* 140 */     System.out.println((toc - tic) / 1000L + " seconds");
/*     */     
/* 142 */     p.close();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HumanRandomMutation(int _L, int _set, int _N, int _Rd0, int _R0, int _Cd0, int _C0, double[] _rates, String[] _events, int _sampleSize, int _seed, int _sampleInterval, boolean _setCellChance, double cellChanceRate, boolean maxCellConBoolean, int N2, double mutationProb, PrintStream p)
/*     */   {
/* 189 */     super(_seed);
/* 190 */     this.randomStart = false;
/* 191 */     this.Rd0 = _Rd0;
/* 192 */     this.Cd0 = _Cd0;
/*     */     
/* 194 */     this.L = (_L + 1);
/* 195 */     this.set = _set;
/* 196 */     this.N = _N;
/* 197 */     this.R0 = _R0;
/* 198 */     this.C0 = _C0;
/* 199 */     this.rates = _rates;
/* 200 */     this.events = new String[_events.length * 2];
/* 201 */     this.sampleSize = _sampleSize;
/* 202 */     this.sampleInterval = _sampleInterval;
/* 203 */     this.cellChance = _setCellChance;
/* 204 */     this.chanceSurvive = Math.random();
/* 205 */     this.cellChanceRate = cellChanceRate;
/* 206 */     this.maxCellConBoolean = maxCellConBoolean;
/* 207 */     this.N2 = N2;
/*     */     
/*     */ 
/* 210 */     this.mutatedCells = new ArrayList();
/* 211 */     this.mutationProb = mutationProb;
/* 212 */     this.sumMutatedBirthRate = 0.0D;
/* 213 */     this.proportion = 0.01D;
/* 214 */     this.p = p;
/*     */     
/* 216 */     if (this.Rd0 != 0) {
/* 217 */       for (int i = 1; i <= this.Rd0; i++) {
/* 218 */         this.mutatedCells.add(Double.valueOf(this.rates[0] * (1.0D + runir(0.0D, this.proportion))));
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 224 */     for (int i = 0; i < _events.length; i++) {
/* 225 */       this.events[i] = ("d" + _events[i]);
/*     */     }
/* 227 */     for (int i = 0; i < _events.length; i++) {
/* 228 */       this.events[(i + _events.length)] = ("g" + _events[i]);
/*     */     }
/* 230 */     init();
/*     */   }
/*     */   
/*     */ 
/*     */   private void init()
/*     */   {
/* 236 */     this.times = new int[this.L];
/* 237 */     this.recRd = new int[this.L];
/* 238 */     this.recR = new int[this.L];
/* 239 */     this.recCd = new int[this.L];
/* 240 */     this.recC = new int[this.L];
/* 241 */     this.recY = new int[this.L];
/*     */     
/* 243 */     this.cellCount = new int[4];
/* 244 */     this.typeOfEvents = this.events.length;
/* 245 */     this.compoundRates = new double[this.typeOfEvents];
/* 246 */     this.cellCountIdx = new int[this.typeOfEvents];
/* 247 */     for (int i = 0; i < this.typeOfEvents; i++) {
/* 248 */       this.cellCountIdx[i] = 0;
/* 249 */       if (this.events[i].substring(1, 2).equals("D")) {
/* 250 */         this.cellCountIdx[i] = 2;
/*     */       }
/* 252 */       if (this.events[i].substring(0, 1).equals("g")) {
/* 253 */         this.cellCountIdx[i] += 1;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void simulate(String outputFileName)
/*     */   {
/* 260 */     this.outputFileName = outputFileName;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 266 */     int r = 0;
/*     */     
/* 268 */     for (int i = 0; i < this.L; i++) {
/* 269 */       this.times[i] = r;
/* 270 */       r += this.sampleInterval;
/*     */     }
/*     */     
/* 273 */     for (int k = 0; k < this.set; k++) {
/* 274 */       TwoComp1();
/*     */     }
/*     */     
/* 277 */     this.p.println("1/lambdaInit = " + this.rates[0] + ", total number of mutated cells = " + this.mutatedCells.size());
/* 278 */     this.p.println("Display 10 mutated cells birth rates randomly:");
/* 279 */     for (int j = 0; j < 10; j++) {
/* 280 */       this.p.println(this.mutatedCells.get(runii(0, this.mutatedCells.size() - 1)));
/*     */     }
/* 282 */     this.p.println();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void updateCompartment(String nextEvent)
/*     */   {
/* 292 */     if (nextEvent.equals("dB"))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/* 297 */       if (this.cellCount[0] > 0) {
/* 298 */         double[] mProb = new double[this.mutatedCells.size()];
/* 299 */         for (int i = 0; i < this.mutatedCells.size(); i++) {
/* 300 */           mProb[i] = (((Double)this.mutatedCells.get(i)).doubleValue() / this.sumMutatedBirthRate);
/*     */         }
/* 302 */         int selected = (int)rmultnom1(mProb, this.mutatedCells.size());
/*     */         
/*     */ 
/* 305 */         this.mutatedCells.add(Double.valueOf(((Double)this.mutatedCells.get(selected)).doubleValue() * (1.0D + runir(0.0D, this.proportion))));
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 310 */         this.cellCount[0] += 1;
/* 311 */         this.R += 1;
/*     */       }
/* 313 */       else if ((this.cellChance) && ((!this.maxCellConBoolean) || (this.C < this.N2))) {
/* 314 */         this.chanceSurvive = Math.random();
/* 315 */         if (this.chanceSurvive > this.cellChanceRate) {
/* 316 */           this.cellCount[2] += 1;
/* 317 */           this.C += 1;
/*     */         }
/*     */       }
/*     */     }
/* 321 */     else if (nextEvent.equals("gB")) {
/* 322 */       if ((this.R < this.N) && (this.cellCount[1] > 0)) {
/* 323 */         double randy = runi();
/* 324 */         if (randy <= this.mutationProb)
/*     */         {
/*     */ 
/* 327 */           this.mutatedCells.add(Double.valueOf(this.rates[0] * (1.0D + runir(0.0D, this.proportion))));
/*     */           
/* 329 */           this.cellCount[0] += 1;
/*     */         } else {
/* 331 */           this.cellCount[1] += 1;
/*     */         }
/*     */         
/* 334 */         this.R += 1;
/*     */       }
/* 336 */       else if ((this.cellChance) && ((!this.maxCellConBoolean) || (this.C < this.N2))) {
/* 337 */         this.chanceSurvive = Math.random();
/* 338 */         if (this.chanceSurvive > this.cellChanceRate) {
/* 339 */           this.cellCount[3] += 1;
/* 340 */           this.C += 1;
/*     */         }
/*     */       }
/* 343 */     } else if (nextEvent.equals("dAp")) {
/* 344 */       if (this.cellCount[0] >= 1) {
/* 345 */         removeFromMutatedCells();
/*     */         
/* 347 */         this.cellCount[0] -= 1;
/* 348 */         this.R -= 1;
/*     */       }
/* 350 */       if ((this.R == 0) && (this.C == 0)) {
/* 351 */         this.currentTime = 1000.0D;
/*     */       }
/* 353 */     } else if (nextEvent.equals("gAp")) {
/* 354 */       if (this.cellCount[1] >= 1) {
/* 355 */         this.cellCount[1] -= 1;
/* 356 */         this.R -= 1;
/*     */       }
/* 358 */       if ((this.R == 0) && (this.C == 0)) {
/* 359 */         this.currentTime = 1000.0D;
/*     */       }
/* 361 */     } else if (nextEvent.equals("dE")) {
/* 362 */       if (this.cellCount[0] >= 1) {
/* 363 */         removeFromMutatedCells();
/*     */         
/* 365 */         this.cellCount[0] -= 1;
/* 366 */         this.R -= 1;
/*     */         
/*     */ 
/* 369 */         if ((!this.maxCellConBoolean) || (this.C < this.N2)) {
/* 370 */           this.cellCount[2] += 1;
/* 371 */           this.C += 1;
/*     */         }
/*     */       }
/* 374 */     } else if (nextEvent.equals("gE")) {
/* 375 */       if (this.cellCount[1] >= 1) {
/* 376 */         this.cellCount[1] -= 1;
/* 377 */         this.R -= 1;
/*     */         
/* 379 */         if ((!this.maxCellConBoolean) || (this.C < this.N2)) {
/* 380 */           this.cellCount[3] += 1;
/* 381 */           this.C += 1;
/*     */         }
/*     */       }
/* 384 */     } else if (nextEvent.equals("dD")) {
/* 385 */       if (this.cellCount[2] >= 1) {
/* 386 */         this.cellCount[2] -= 1;
/* 387 */         this.C -= 1;
/*     */       }
/* 389 */       if ((this.R == 0) && (this.C == 0)) {
/* 390 */         this.currentTime = 1000.0D;
/*     */       }
/* 392 */     } else if (nextEvent.equals("gD")) {
/* 393 */       if (this.cellCount[3] >= 1) {
/* 394 */         this.cellCount[3] -= 1;
/* 395 */         this.C -= 1;
/*     */       }
/* 397 */       if ((this.R == 0) && (this.C == 0)) {
/* 398 */         this.currentTime = 1000.0D;
/*     */       }
/* 400 */     } else if (nextEvent.equals("dAs")) {
/* 401 */       this.cellCount[2] += 1;
/* 402 */       this.C += 1;
/* 403 */     } else if (nextEvent.equals("gAs")) {
/* 404 */       this.cellCount[3] += 1;
/* 405 */       this.C += 1;
/*     */     }
/*     */   }
/*     */   
/*     */   private void removeFromMutatedCells()
/*     */   {
/* 411 */     int selected = runii(0, this.mutatedCells.size() - 1);
/*     */     
/* 413 */     this.mutatedCells.remove(selected);
/*     */   }
/*     */   
/*     */   public long TwoComp1()
/*     */   {
/* 418 */     if (this.randomStart) {
/* 419 */       this.Rd0 = rbin(this.R0, this.Rpercent);
/* 420 */       this.Cd0 = rbin(this.C0, this.Cpercent);
/*     */     }
/*     */     
/* 423 */     this.recCd[0] = this.Cd0;
/* 424 */     this.recC[0] = this.C0;
/* 425 */     this.recRd[0] = this.Rd0;
/* 426 */     this.recR[0] = this.R0;
/* 427 */     this.recY[0] = ((int)(this.sampleSize * this.Cd0 / this.C0));
/*     */     
/* 429 */     this.R = this.R0;
/* 430 */     this.cellCount[0] = this.Rd0;
/* 431 */     this.cellCount[1] = (this.R - this.Rd0);
/* 432 */     this.C = this.C0;
/* 433 */     this.cellCount[2] = this.Cd0;
/* 434 */     this.cellCount[3] = (this.C - this.Cd0);
/*     */     
/* 436 */     this.currentTime = 0.0D;
/*     */     
/* 438 */     for (int k = 1; k < this.L; k++)
/*     */     {
/* 440 */       while (this.currentTime <= this.times[k]) {
/* 441 */         this.sumOfRates = 0.0D;
/* 442 */         this.sumMutatedBirthRate = 0.0D;
/* 443 */         if (this.mutatedCells != null) {
/* 444 */           for (int i = 0; i < this.mutatedCells.size(); i++) {
/* 445 */             this.sumMutatedBirthRate += ((Double)this.mutatedCells.get(i)).doubleValue();
/*     */           }
/*     */         }
/* 448 */         this.sumOfRates += this.sumMutatedBirthRate;
/*     */         
/* 450 */         for (int i = 1; i < this.typeOfEvents; i++) {
/* 451 */           this.compoundRates[i] = (this.rates[i] * this.cellCount[this.cellCountIdx[i]]);
/* 452 */           this.sumOfRates += this.compoundRates[i];
/*     */         }
/*     */         
/* 455 */         this.compoundRates[0] = (this.sumMutatedBirthRate / this.sumOfRates);
/* 456 */         for (int i = 1; i < this.typeOfEvents; i++) {
/* 457 */           this.compoundRates[i] /= this.sumOfRates;
/*     */         }
/* 459 */         this.currentTime += rexp(this.sumOfRates);
/*     */         
/*     */ 
/* 462 */         updateCompartment(this.events[((int)rmultnom1(this.compoundRates, this.typeOfEvents))]);
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 467 */       k--;
/* 468 */       this.recCd[(k + 1)] = this.cellCount[2];
/* 469 */       this.recC[(k + 1)] = this.C;
/* 470 */       this.recRd[(k + 1)] = this.cellCount[0];
/* 471 */       this.recR[(k + 1)] = this.R;
/* 472 */       this.recY[(k + 1)] = rbin(this.sampleSize, this.cellCount[2] / this.C);
/* 473 */       k++;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 481 */     this.currentGroup += 1;
/* 482 */     return 1L;
/*     */   }
/*     */   
/*     */ 
/*     */   public void createOutputFile()
/*     */   {
/*     */     try
/*     */     {
/* 490 */       File outputFile = new File(this.outputFileName);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 498 */       FileOutputStream out = new FileOutputStream(outputFile, false);
/* 499 */       PrintStream p = new PrintStream(out);
/* 500 */       p.println("#");
/* 501 */       p.println("Time Group Cd C Rd R Y");
/* 502 */       p.close();
/*     */     } catch (Exception e) {
/* 504 */       System.err.println("Error writing to file.");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void outputResults()
/*     */   {
/* 515 */     int i = 0;
/*     */     try
/*     */     {
/* 518 */       FileOutputStream updatedResults = new FileOutputStream(this.outputFileName, true);
/* 519 */       PrintStream p = new PrintStream(updatedResults);
/*     */       
/* 521 */       while (i < this.L) {
/* 522 */         p.print(i * this.sampleInterval + " " + this.currentGroup + " ");
/* 523 */         p.println(this.recCd[i] + " " + this.recC[i] + " " + this.recRd[i] + " " + this.recR[i] + " " + this.recY[i]);
/*     */         
/* 525 */         i++;
/*     */       }
/*     */       
/* 528 */       p.close();
/*     */     } catch (Exception e) {
/* 530 */       System.err.println("Error writing to file.");
/*     */     }
/*     */   }
/*     */   
/*     */   public void setCellChanceRate(double cellChanceRate)
/*     */   {
/* 536 */     this.cellChanceRate = cellChanceRate;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 544 */   private long Indexp = 2L;
/*     */   
/*     */ 
/* 547 */   protected int N = 10000;
/*     */   
/*     */ 
/* 550 */   public int R0 = 100;
/* 551 */   public int Rd0 = 50;
/* 552 */   public int C0 = 100;
/* 553 */   public int Cd0 = 50;
/*     */   
/*     */   private int[] cellCount;
/*     */   
/*     */   private int R;
/*     */   private int C;
/*     */   private double Rpercent;
/*     */   private double Cpercent;
/*     */   public int[] times;
/*     */   public int[] recRd;
/*     */   public int[] recR;
/*     */   public int[] recCd;
/*     */   public int[] recC;
/*     */   public int[] recY;
/* 567 */   private int currentGroup = 1;
/*     */   
/*     */   private double currentTime;
/*     */   
/*     */   private double sumOfRates;
/*     */   
/*     */   private int typeOfEvents;
/*     */   private double[] rates;
/*     */   private double[] compoundRates;
/*     */   private int[] cellCountIdx;
/* 577 */   private int sampleSize = 70;
/* 578 */   private int sampleInterval = 4;
/*     */   
/*     */   private String[] events;
/*     */   
/*     */   private String outputFileName;
/*     */   
/* 584 */   public boolean writeResults2File = true;
/*     */   private boolean randomStart;
/*     */   private boolean cellChance;
/*     */   private double chanceSurvive;
/*     */   private double cellChanceRate;
/*     */   private boolean maxCellConBoolean;
/*     */   private int N2;
/*     */   private ArrayList<Double> mutatedCells;
/*     */   private double sumMutatedBirthRate;
/*     */   private double mutationProb;
/*     */   private double proportion;
/*     */   private PrintStream p;
/*     */ }


/* Location:              /Users/jasonxu/Desktop/HematopoiesisSimulator.jar!/simulatorcore/HumanRandomMutation.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */