/*     */ package simulatorcore;
/*     */ 
/*     */ import java.io.FileWriter;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class test
/*     */ {
/*     */   public static void main(String[] args)
/*     */     throws Exception
/*     */   {
/*  16 */     int L = 100;
/*  17 */     int set = Integer.parseInt(args[8]);
/*     */     
/*     */ 
/*  20 */     int N = 10000;
/*  21 */     int sampleSize = 70;
/*     */     
/*     */ 
/*  24 */     int seed = (int)(System.currentTimeMillis() % 1000000000L);
/*  25 */     int sampleInterval = 4;
/*     */     
/*     */ 
/*     */ 
/*  29 */     double mll = 1.0D;double mva = 1.0D;double dvv = 1.0D;double dvu = 1.0D;double ratio_as = 1.0D;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  34 */     String run = args[0];
/*  35 */     String rowname = args[1];
/*  36 */     double l = Double.parseDouble(args[2]);
/*  37 */     double v = Double.parseDouble(args[3]);
/*  38 */     double u = Double.parseDouble(args[4]);
/*  39 */     double as = Double.parseDouble(args[5]);
/*  40 */     double ap = Double.parseDouble(args[6]);
/*     */     
/*  42 */     String outputFileName = "C:\\1youyisstuff\\2GuttorpAbkowitzRA\\MCMC\\output\\" + run + "\\" + "\\simResult_" + rowname;
/*     */     
/*  44 */     double ld = l * mll;double vd = v * dvv;double ud = u * dvu;double apd = ap * mva;double asd = as * ratio_as;
/*     */     
/*  46 */     int R0 = 30;double R0percentD = 0.5D;int Rd0 = (int)(R0 * R0percentD);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  53 */     int C0 = 16;double C0percentD = 0.5D;int Cd0 = (int)(C0 * C0percentD);int Cg0 = C0 - Cd0;
/*     */     
/*  55 */     Cd0 = (int)Math.floor(Rd0 * vd / (ld - apd - vd + ud) + 0.5D);
/*  56 */     Cg0 = (int)Math.floor((R0 - Rd0) * v / (l - ap - v + u) + 0.5D);
/*  57 */     C0 = Cd0 + Cg0;C0percentD = Cd0 / C0;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  66 */     String[] events = { "B", "E", "D", "Ap" };double[] rates = { l, v, u, ap, ld, vd, ud, apd };
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  74 */     Mice2new mice2new = new Mice2new(L, set, N, Rd0, R0, Cd0, C0, rates, events, sampleSize, seed, sampleInterval, true, 0.5D, false, N);
/*     */     
/*  76 */     mice2new = new Mice2new(L, set, N, R0percentD, R0, C0percentD, C0, rates, events, sampleSize, seed, sampleInterval, true, 0.5D, false, N);
/*  77 */     mice2new.writeResults2File = true;
/*     */     
/*  79 */     mice2new.simulate(outputFileName);
/*     */   }
/*     */   
/*     */   public static void save2File(String fileName, Vector data)
/*     */     throws Exception
/*     */   {
/*  85 */     FileWriter f = new FileWriter(fileName);
/*  86 */     for (int i = 0; i < data.size(); i++) {
/*  87 */       f.write(data.elementAt(i) + " ");
/*     */     }
/*  89 */     f.close();
/*     */   }
/*     */   
/*     */   public static void testRuni() throws Exception
/*     */   {
/*  94 */     Vector data = new Vector();
/*     */     
/*  96 */     MiceRandom mr = new MiceRandom(3);
/*  97 */     for (int i = 0; i < 1000000; i++) {
/*  98 */       data.add(i, Double.valueOf(mr.runi()));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 114 */     save2File("c:/1youyisstuff/data/runi_1_3_1000000.txt", data);
/* 115 */     System.exit(1);
/*     */   }
/*     */ }


/* Location:              /Users/jasonxu/Desktop/HematopoiesisSimulator.jar!/simulatorcore/test.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */