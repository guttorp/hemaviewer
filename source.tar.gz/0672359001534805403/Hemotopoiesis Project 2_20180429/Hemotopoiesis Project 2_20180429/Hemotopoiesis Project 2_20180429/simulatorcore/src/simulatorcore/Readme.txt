simResult looks like this:
    Time Group Cd C Rd R Y
    1 1 6 13 15 30 33
    2 1 5 10 15 31 34
    3 1 7 16 11 28 33
    4 1 7 16 12 35 27
    5 1 11 23 11 26 40
    6 1 12 20 11 31 31
    7 1 9 16 16 34 37



TwoComp1 and TwoComp2 differ in the way initial numbers of cells are picked
    in TwoComp1 Rd0 and Rg0 are calculated from params input; Cd0 is calculated from the ratio of C/R
    in TwoComp2, Rd0 and Cd0 are randomly drawn.

TwoComp1 does not check for N while TwoComp2 does.

TwoComp3 differs from TwoComp1 in that a new apoptosis rate is used when R is near N.

Switch to use Random.nextDouble() to generate random number and see the rngs in the MiceRandom Constructor.
When the seed is 1, set=2, L=5, the two numbers in simResult is 356 10.



    public long TwoComp2()
    {
	R = R0;
	Rd = rbin((int)R,.13);
	Rg = R - Rd;

	l = r1*v+a;
	u = v/r2;

	ld = l*mll;
	ad = a*mva;
	vd = v/dvv;
	ud = u/dvu;

	// Second Compartment
	// Monkey setting
	C = 50;
	Cd = rbin((int)C,.77);
	Cg = C - Cd;


	/*----------------------------*/
	/*---Simulation starts here---*/
	/*----------------------------*/

	// exponential parameter
	z = ((double)Rd*(ld+ad+vd))+((double)Rg*(l+a+v))+((double)Cd*ud)+((double)Cg*u);

	// exponential draw and cumulative time
	y = rexp(z);

	// uniform draw
	x = runi();

	for (k=0; k<L; k++)
	{
	    while (y <= times[k])
	    {
		// BIRTH of D type
		if(x <= ( ((double)Rd*ld)/z ))
		{
		    if((R < N) && (Rd>0) )
		    {
			Rd = Rd+1;
			R = R+1;
		    }

		    z = ((double)Rd*(ld+ad+vd))+((double)Rg*(l+a+v))+((double)Cd*ud)+((double)Cg*u);
		    y = y+rexp(z);
		    x = runi();
		}

		// BIRTH of G type
		else if(x <= ( (((double)Rd*ld)+((double)Rg*l))/z ))
		{
		    if((R < N) && (Rg>0))
		    {
			Rg = Rg+1;
			R = R+1;
		    }

		    z = ((double)Rd*(ld+ad+vd))+((double)Rg*(l+a+v))+((double)Cd*ud)+((double)Cg*u);
		    y = y+rexp(z);
		    x = runi();
		}

		// APOPTOSIS of D type
		else if(x <= ( (((double)Rd*(ld+ad))+((double)Rg*l))/z ))
		{
		    if(Rd >= 1)
		    {
			Rd = Rd-1;
			R = R-1;
		    }

		    z = ((double)Rd*(ld+ad+vd))+((double)Rg*(l+a+v))+((double)Cd*ud)+((double)Cg*u);
		    if (z != 0) // checking if both compartments are extinguished
		    {
			y = y+rexp(z);
			x = runi();
		    }
		    else
		    {
			y = 1000;
		    }
		}

		// APOPTOSIS of G type
		else if(x <= ( (((double)Rd*(ld+ad))+((double)Rg*(l+a)))/z) )
		{
		    if(Rg >= 1)
		    {
			Rg = Rg-1;
			R  = R-1;
		    }

		    z = ((double)Rd*(ld+ad+vd))+((double)Rg*(l+a+v))+((double)Cd*ud)+((double)Cg*u);

		    if (z != 0)
		    {
			y = y+rexp(z);
			x = runi();
		    }
		    else
		    {
			y = 1000;
		    }
		}

		// DIFFERENTIATION of D type
		else if(x <= ((((double)Rd*(ld+ad+vd))+((double)Rg*(l+a)))/z) )
		{
		    if(Rd >= 1)
		    {
			Rd = Rd-1;
			Cd = Cd+1;
			R = R-1;
			C = C+1;
		    }

		    z = ((double)Rd*(ld+ad+vd))+((double)Rg*(l+a+v))+((double)Cd*ud)+((double)Cg*u);
		    y = y+rexp(z);
		    x = runi();
		}

		// DIFFERENTIATION of G type
		else if(x <= (1 - (( ((double)Cd*ud) + ((double)Cg*u) )/z) ) )
		{
		    if(Rg >= 1)
		    {
			Rg = Rg-1;
			Cg = Cg+1;
			R = R-1;
			C = C+1;
		    }

		    z = ((double)Rd*(ld+ad+vd))+((double)Rg*(l+a+v))+((double)Cd*ud)+((double)Cg*u);
		    y = y+rexp(z);
		    x = runi();
		}

		// ULTIMATE DIFFERENTIATION or DEATH of D type
		else if(x <= (1- (((double)Cg*u)/z) ))
		{
		    if(Cd >= 1)
		    {
			Cd = Cd-1;
			C = C-1;
		    }

		    z = ((double)Rd*(ld+ad+vd))+((double)Rg*(l+a+v))+((double)Cd*ud)+((double)Cg*u);

		    if (z != 0)
		    {
			y = y+rexp(z);
			x = runi();
		    }
		    else
		    {
			y = 1000;
		    }
		}

		// ULTIMATE DIFFERENTIATION or DEATH of G type
		else
		{
		    if(Cg >= 1)
		    {
			Cg = Cg-1;
			C = C-1;
		    }

		    z = ((double)Rd*(ld+ad+vd))+((double)Rg*(l+a+v))+((double)Cd*ud)+((double)Cg*u);

		    if (z != 0)
		    {
			y = y+rexp(z);
			x = runi();
		    }
		    else
		    {
			y = 1000;
		    }
		}
	    }

	    recCd[k] = Cd;
	    recC[k] = C;
	    recRd[k] = Rd;
	    recR[k] = R;
	    recY[k] = rbin(30, ((double)Cd/(double)C) );


	}

	outputResults();
	currentGroup++;

	return 1;

    };


    public long TwoComp3()
    {
	// an and adn are the values of the apoptosis in case
	// the hp on the steady state is different

	double an, adn;
	R = R0;
	Rd = Rd0;
	Rg = R - Rd;

	l = r1*v+a;
	u = v/r2;

	ld = l*mll;
	ad = a*mva;
	vd = v/dvv;
	ud = u/dvu;

	an = l;
	adn = an*mva;


	// Second Compartment
	// Marked

	Cg = (long)Math.floor((double)Rg*v/(l-a-v+u) + .5);
	Cd = (long)Math.floor((double)Rd*vd/(ld-ad-vd+ud) +.5);
	C = Cd+Cg;


	/*----------------------------*/
	/*---Simulation starts here---*/
	/*----------------------------*/

	// exponential parameter
	z = ((double)Rd*(ld+ad+vd))+((double)Rg*(l+a+v))+((double)Cd*ud)+((double)Cg*u);

	// exponential draw and cumulative time
	y = rexp(z);

	// uniform draw
	x = runi();

	for (k=0;k<L;k++)
	{
	    while (y <= times[k])
	    {

		if((R <= N)) // if R<=N then the aoptosis stays as it is, otherwise it gets increased
		{
		    // BIRTH of D type
		    if(x <= ( ((double)Rd*ld)/z ))
		    {
			if(Rd > 0)
			{
			    Rd = Rd+1;
			    R = R+1;
			}

			z = ((double)Rd*(ld+ad+vd))+((double)Rg*(l+a+v))+((double)Cd*ud)+((double)Cg*u);
			y = y+rexp(z);
			x = runi();
		    }

		    // BIRTH of G type
		    else if(x <= ( (((double)Rd*ld)+((double)Rg*l))/z ))
		    {
			if(Rg > 0)
			{
			    Rg = Rg+1;
			    R = R+1;
			}

			z = ((double)Rd*(ld+ad+vd))+((double)Rg*(l+a+v))+((double)Cd*ud)+((double)Cg*u);
			y = y+rexp(z);
			x = runi();
		    }

		    // APOPTOSIS of D type
		    else if(x <= ( (((double)Rd*(ld+ad))+((double)Rg*l))/z ))
		    {
			if(Rd >= 1)
			{
			    Rd = Rd-1;
			    R = R-1;
			}

			z = ((double)Rd*(ld+ad+vd))+((double)Rg*(l+a+v))+((double)Cd*ud)+((double)Cg*u);

			if (z != 0) // checking if both compartments are estinguished
			{
			    y = y+rexp(z);
			    x = runi();
			}
			else
			{
			    y = 1000;
			}
		    }

		    // APOPTOSIS of G type
		    else if(x <= ( (((double)Rd*(ld+ad))+((double)Rg*(l+a)))/z) )
		    {
			if(Rg >= 1)
			{
			    Rg = Rg-1;
			    R  = R-1;
			}

			z = ((double)Rd*(ld+ad+vd))+((double)Rg*(l+a+v))+((double)Cd*ud)+((double)Cg*u);

			if (z != 0)
			{
			    y = y+rexp(z);
			    x = runi();
			}
			else
			{
			    y = 1000;
			}
		    }

		    // DIFFERENTIATION of D type
		    else if(x <= ((((double)Rd*(ld+ad+vd))+((double)Rg*(l+a)))/z) )
		    {
			if(Rd >= 1)
			{
			    Rd = Rd-1;
			    Cd = Cd+1;
			    R = R-1;
			    C = C+1;
			}

			z = ((double)Rd*(ld+ad+vd))+((double)Rg*(l+a+v))+((double)Cd*ud)+((double)Cg*u);
			y = y+rexp(z);
			x = runi();
		    }

		    // DIFFERENTIATION of G type
		    else if(x <= (1 - (( ((double)Cd*ud) + ((double)Cg*u) )/z) ) )
		    {

			if(Rg >= 1)
			{
			    Rg = Rg-1;
			    Cg = Cg+1;
			    R = R-1;
			    C = C+1;
			}

			z = ((double)Rd*(ld+ad+vd))+((double)Rg*(l+a+v))+((double)Cd*ud)+((double)Cg*u);
			y = y+rexp(z);
			x = runi();
		    }

		    // ULTIMATE DIFFERENTIATION or DEATH of D type
		    else if(x <= (1- (((double)Cg*u)/z) ))
		    {
			if(Cd >= 1)
			{
			    Cd = Cd-1;
			    C = C-1;
			}

			z = ((double)Rd*(ld+ad+vd))+((double)Rg*(l+a+v))+((double)Cd*ud)+((double)Cg*u);

			if (z != 0)
			{
			    y = y+rexp(z);
			    x = runi();
			}
			else
			{
			    y = 1000;
			}
		    }

		    // ULTIMATE DIFFERENTIATION or DEATH of G type
		    else
		    {
			if(Cg >= 1)
			{
			    Cg = Cg-1;
			    C = C-1;
			}

			z = ((double)Rd*(ld+ad+vd))+((double)Rg*(l+a+v))+((double)Cd*ud)+((double)Cg*u);

			if (z != 0)
			{
			    y = y+rexp(z);
			    x = runi();
			}
			else
			{
			    y = 1000;
			}
		    }
		}

		else // now R should be close to N
		{
		    // BIRTH of D type
		    if(x <= ( ((double)Rd*ld)/z ))
		    {
			if(Rd > 0)
			{
			    Rd = Rd+1;
			    R = R+1;
			}

			z = ((double)Rd*(ld+adn+vd))+((double)Rg*(l+an+v))+((double)Cd*ud)+((double)Cg*u);
			y = y+rexp(z);
			x = runi();
		    }

		    // BIRTH of G type
		    else if(x <= ( (((double)Rd*ld)+((double)Rg*l))/z ))
		    {
			if(Rg > 0)
			{
			    Rg = Rg+1;
			    R = R+1;
			}

			z = ((double)Rd*(ld+adn+vd))+((double)Rg*(l+an+v))+((double)Cd*ud)+((double)Cg*u);
			y = y+rexp(z);
			x = runi();
		    }

		    // APOPTOSIS of D type
		    else if(x <= ( (((double)Rd*(ld+adn))+((double)Rg*l))/z ))
		    {
			if(Rd >= 1)
			{
			    Rd = Rd-1;
			    R = R-1;
			}

			z = ((double)Rd*(ld+adn+vd))+((double)Rg*(l+an+v))+((double)Cd*ud)+((double)Cg*u);

			if (z != 0) // checking if both compartments are estinguished
			{
			    y = y+rexp(z);
			    x = runi();
			}
			else
			{
			    y = 1000;
			}
		    }

		    // APOPTOSIS of G type
		    else if(x <= ( (((double)Rd*(ld+adn))+((double)Rg*(l+an)))/z) )
		    {
			if(Rg>= 1)
			{
			    Rg = Rg-1;
			    R  = R-1;
			}

			z = ((double)Rd*(ld+adn+vd))+((double)Rg*(l+an+v))+((double)Cd*ud)+((double)Cg*u);

			if (z != 0)
			{
			    y = y+rexp(z);
			    x = runi();
			}
			else
			{
			    y = 1000;
			}
		    }

		    // DIFFERENTIATION of D type
		    else if(x <= ((((double)Rd*(ld+adn+vd))+((double)Rg*(l+an)))/z) )
		    {
			if(Rd >= 1)
			{
			    Rd = Rd-1;
			    Cd = Cd+1;
			    R = R-1;
			    C = C+1;
			}

			z = ((double)Rd*(ld+adn+vd))+((double)Rg*(l+an+v))+((double)Cd*ud)+((double)Cg*u);
			y = y+rexp(z);
			x = runi();
		    }

		    // DIFFERENTIATION of G type
		    else if(x <= (1 - (( ((double)Cd*ud) + ((double)Cg*u) )/z) ) )
		    {
			if(Rg >= 1)
			{
			    Rg = Rg-1;
			    Cg = Cg+1;
			    R = R-1;
			    C = C+1;
			}

			z = ((double)Rd*(ld+adn+vd))+((double)Rg*(l+an+v))+((double)Cd*ud)+((double)Cg*u);
			y = y+rexp(z);
			x = runi();
		    }

		    // ULTIMATE DIFFERENTIATION or DEATH of D type
		    else if(x <= (1- (((double)Cg*u)/z) ))
		    {
			if(Cd >= 1)
			{
			    Cd = Cd-1;
			    C = C-1;
			}

			z = ((double)Rd*(ld+adn+vd))+((double)Rg*(l+an+v))+((double)Cd*ud)+((double)Cg*u);

			if (z != 0)
			{
			    y = y+rexp(z);
			    x = runi();
			}
			else
			{
			    y = 1000;
			}
		    }

		    // ULTIMATE DIFFERENTIATION or DEATH of G type
		    else
		    {
			if(Cg >= 1)
			{
			    Cg = Cg-1;
			    C = C-1;
			}

			z = ((double)Rd*(ld+adn+vd))+((double)Rg*(l+an+v))+((double)Cd*ud)+((double)Cg*u);

			if (z != 0)
			{
			    y = y+rexp(z);
			    x = runi();
			}
			else
			{
			    y = 1000;
			}
		    }
		}

	    }

	    recCd[k] = Cd;
	    recC[k] = C;
	    recRd[k] = Rd;
	    recR[k] = R;
	    recY[k] = rbin(70, ((double)Cd/(double)C) );


	}

	outputResults();
	currentGroup++;

	return 1;
    };


