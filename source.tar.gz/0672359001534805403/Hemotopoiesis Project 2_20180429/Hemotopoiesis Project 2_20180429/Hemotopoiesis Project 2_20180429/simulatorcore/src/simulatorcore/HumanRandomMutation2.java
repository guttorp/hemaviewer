/*     */ package simulatorcore;
/*     */ 
/*     */ import edu.rit.util.Random;
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.util.LinkedList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HumanRandomMutation2
/*     */   extends MiceRandom
/*     */ {
/*     */   private final int L;
/*     */   private final int set;
/*     */   
/*     */   public static void main(String[] args)
/*     */     throws IOException
/*     */   {
/*  33 */     double lambdaInit = 40.0D;
/*  34 */     double nuInit = 56.1D;
/*  35 */     double muInit = 6.7D;
/*  36 */     double alphaInit = 285.7D;
/*     */     
/*  38 */     double lambda = 40.0D;
/*  39 */     double mu = 6.7D;
/*  40 */     double alpha = 285.7D;
/*  41 */     double nu = 56.1D;
/*  42 */     double mll = 1.0D;double mva = 1.0D;double dvv = 1.0D;double dvu = 1.0D;double ratio_as = 1.0D;
/*     */     
/*  44 */     double l = 1.0D / lambda;
/*  45 */     double lb = 0.0D;
/*  46 */     double v = 1.0D / nu;
/*  47 */     double u = 1.0D / mu;
/*  48 */     double a = 1.0D / alpha;
/*  49 */     double as = 0.0D;
/*  50 */     double ld = l * mll;
/*  51 */     double ldb = 1.0D * mll;
/*  52 */     double ad = a * mva;
/*  53 */     double vd = v * dvv;
/*  54 */     double ud = u * dvu;
/*  55 */     double asd = as * ratio_as;
/*  56 */     String[] events = { "B", "E", "D", "Ap" };
/*  57 */     double[] rates = { l, v, u, a, ld, vd, ud, ad };
/*     */     
/*     */ 
/*  60 */     double Rpercent = 0.0D;
/*  61 */     double Cpercent = Rpercent;
/*     */     
/*  63 */     int sampleSize = 70;
/*  64 */     boolean setCellChance = false;
/*     */     
/*     */ 
/*     */ 
/*  68 */     int seed = 17;
/*     */     
/*  70 */     double cellChanceRate = 0.5D;
/*     */     
/*     */ 
/*  73 */     int totalWeeks = 520;
/*  74 */     int sampleInterval = 52;
/*  75 */     int R0 = 10000;
/*  76 */     double mutationProb = 0.001D;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  83 */     int C0 = (int)(R0 / nu / (1.0D / lambda - 1.0D / alpha - 1.0D / nu + 1.0D / mu));
/*     */     
/*     */ 
/*  86 */     int L = totalWeeks / sampleInterval;
/*  87 */     int set = 1;
/*  88 */     int N = 10000;
/*     */     
/*     */ 
/*  91 */     long tic = System.currentTimeMillis();
/*     */     
/*     */ 
/*     */ 
/*  95 */     PrintStream p = System.out;
/*     */     
/*  97 */     p.println("LinkedRateList.2010");
/*  98 */     p.println("Human: initial number of type a/type d cells in the Reserve compartment is Rd0 = 1.");
/*     */     
/* 100 */     p.println("R0 = " + R0 + ", C0 = " + C0 + ". Total " + totalWeeks + " weeks. Sample size = 70.");
/* 101 */     p.println("Sample Interval = " + sampleInterval);
/* 102 */     p.println("Regular cell mutation probability = " + mutationProb);
/* 103 */     p.println("mutated cell with brith rate (rate of parental cell + epsilon)");
/* 104 */     p.println("where epsilon ~ Unif(0, (rate of parental cell) / 100)");
/* 105 */     p.println();
/*     */     
/* 107 */     for (int i = 1; i <= 10; i++) {
/* 108 */       p.println("Run #" + i);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 117 */       HumanRandomMutation2 mice2new = new HumanRandomMutation2(L, set, N, 1, R0, 0, C0, 
/* 118 */         rates, events, sampleSize, seed, sampleInterval, 
/* 119 */         setCellChance, cellChanceRate, false, N, mutationProb, p);
/*     */       
/*     */ 
/* 122 */       mice2new.simulate("");
/*     */       
/* 124 */       p.printf("%10s %10s %10s %10s %10s %10s \n", new Object[] { "Time", "Cd", "C", "Rd", "R", "Y" });
/*     */       
/* 126 */       int k = 0;
/* 127 */       while (k <= L) {
/* 128 */         p.printf("%10d %10d %10d %10d %10d %10d \n", new Object[] { Integer.valueOf(k * sampleInterval), 
/* 129 */           Integer.valueOf(mice2new.recCd[k]), Integer.valueOf(mice2new.recC[k]), Integer.valueOf(mice2new.recRd[k]), 
/* 130 */           Integer.valueOf(mice2new.recR[k]), Integer.valueOf(mice2new.recY[k]) });
/* 131 */         k++;
/*     */       }
/* 133 */       seed = (int)(mice2new.random.nextDouble() * 1.0E9D);
/* 134 */       p.println();
/*     */     }
/*     */     
/*     */ 
/* 138 */     long toc = System.currentTimeMillis();
/* 139 */     System.out.println((toc - tic) / 1000L + " seconds");
/*     */     
/* 141 */     p.close();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HumanRandomMutation2(int _L, int _set, int _N, int _Rd0, int _R0, int _Cd0, int _C0, double[] _rates, String[] _events, int _sampleSize, int _seed, int _sampleInterval, boolean _setCellChance, double cellChanceRate, boolean maxCellConBoolean, int N2, double mutationProb, PrintStream p)
/*     */   {
/* 188 */     super(_seed);
/* 189 */     this.randomStart = false;
/* 190 */     this.Rd0 = _Rd0;
/* 191 */     this.Cd0 = _Cd0;
/*     */     
/* 193 */     this.L = (_L + 1);
/* 194 */     this.set = _set;
/* 195 */     this.N = _N;
/* 196 */     this.R0 = _R0;
/* 197 */     this.C0 = _C0;
/* 198 */     this.rates = _rates;
/* 199 */     this.events = new String[_events.length * 2];
/* 200 */     this.sampleSize = _sampleSize;
/* 201 */     this.sampleInterval = _sampleInterval;
/* 202 */     this.cellChance = _setCellChance;
/* 203 */     this.chanceSurvive = Math.random();
/* 204 */     this.cellChanceRate = cellChanceRate;
/* 205 */     this.maxCellConBoolean = maxCellConBoolean;
/* 206 */     this.N2 = N2;
/*     */     
/*     */ 
/* 209 */     this.mutatedCells = new LinkedList();
/* 210 */     this.mutationProb = mutationProb;
/* 211 */     this.sumMutatedBirthRate = 0.0D;
/* 212 */     this.proportion = 0.01D;
/* 213 */     this.p = p;
/*     */     
/* 215 */     if (this.Rd0 != 0) {
/* 216 */       for (int i = 1; i <= this.Rd0; i++) {
/* 217 */         this.mutatedCells.add(Double.valueOf(this.rates[0] * (1.0D + runir(0.0D, this.proportion))));
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 222 */     for (int i = 0; i < _events.length; i++) {
/* 223 */       this.events[i] = ("d" + _events[i]);
/*     */     }
/* 225 */     for (int i = 0; i < _events.length; i++) {
/* 226 */       this.events[(i + _events.length)] = ("g" + _events[i]);
/*     */     }
/* 228 */     init();
/*     */   }
/*     */   
/*     */ 
/*     */   private void init()
/*     */   {
/* 234 */     this.times = new int[this.L];
/* 235 */     this.recRd = new int[this.L];
/* 236 */     this.recR = new int[this.L];
/* 237 */     this.recCd = new int[this.L];
/* 238 */     this.recC = new int[this.L];
/* 239 */     this.recY = new int[this.L];
/*     */     
/* 241 */     this.cellCount = new int[4];
/* 242 */     this.typeOfEvents = this.events.length;
/* 243 */     this.compoundRates = new double[this.typeOfEvents];
/* 244 */     this.cellCountIdx = new int[this.typeOfEvents];
/* 245 */     for (int i = 0; i < this.typeOfEvents; i++) {
/* 246 */       this.cellCountIdx[i] = 0;
/* 247 */       if (this.events[i].substring(1, 2).equals("D")) {
/* 248 */         this.cellCountIdx[i] = 2;
/*     */       }
/* 250 */       if (this.events[i].substring(0, 1).equals("g")) {
/* 251 */         this.cellCountIdx[i] += 1;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void simulate(String outputFileName)
/*     */   {
/* 258 */     this.outputFileName = outputFileName;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 264 */     int r = 0;
/*     */     
/* 266 */     for (int i = 0; i < this.L; i++) {
/* 267 */       this.times[i] = r;
/* 268 */       r += this.sampleInterval;
/*     */     }
/*     */     
/* 271 */     for (int k = 0; k < this.set; k++) {
/* 272 */       TwoComp1();
/*     */     }
/*     */     
/* 275 */     this.p.println("1/lambdaInit = " + this.rates[0] + ", total number of mutated cells = " + this.mutatedCells.size());
/* 276 */     this.p.println("Display 10 mutated cells birth rates randomly:");
/* 277 */     for (int j = 0; j < 10; j++) {
/* 278 */       this.p.println(this.mutatedCells.get(runii(0, this.mutatedCells.size() - 1)));
/*     */     }
/* 280 */     this.p.println();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void updateCompartment(String nextEvent)
/*     */   {
/* 290 */     if (nextEvent.equals("dB"))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/* 295 */       if (this.cellCount[0] > 0) {
/* 296 */         double[] mProb = new double[this.mutatedCells.size()];
/* 297 */         for (int i = 0; i < this.mutatedCells.size(); i++) {
/* 298 */           mProb[i] = (((Double)this.mutatedCells.get(i)).doubleValue() / this.sumMutatedBirthRate);
/*     */         }
/* 300 */         int selected = (int)rmultnom1(mProb, this.mutatedCells.size());
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 305 */         this.mutatedCells.add(Double.valueOf(((Double)this.mutatedCells.get(selected)).doubleValue() * (1.0D + runir(0.0D, this.proportion))));
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 310 */         this.cellCount[0] += 1;
/* 311 */         this.R += 1;
/*     */       }
/* 313 */       else if ((this.cellChance) && ((!this.maxCellConBoolean) || (this.C < this.N2))) {
/* 314 */         this.chanceSurvive = Math.random();
/* 315 */         if (this.chanceSurvive > this.cellChanceRate) {
/* 316 */           this.cellCount[2] += 1;
/* 317 */           this.C += 1;
/*     */         }
/*     */       }
/*     */     }
/* 321 */     else if (nextEvent.equals("gB")) {
/* 322 */       if ((this.R < this.N) && (this.cellCount[1] > 0)) {
/* 323 */         double randy = runi();
/* 324 */         if (randy <= this.mutationProb)
/*     */         {
/* 326 */           this.mutatedCells.add(Double.valueOf(this.rates[0] * (1.0D + runir(0.0D, this.proportion))));
/*     */           
/* 328 */           this.cellCount[0] += 1;
/*     */         } else {
/* 330 */           this.cellCount[1] += 1;
/*     */         }
/*     */         
/* 333 */         this.R += 1;
/*     */       }
/* 335 */       else if ((this.cellChance) && ((!this.maxCellConBoolean) || (this.C < this.N2))) {
/* 336 */         this.chanceSurvive = Math.random();
/* 337 */         if (this.chanceSurvive > this.cellChanceRate) {
/* 338 */           this.cellCount[3] += 1;
/* 339 */           this.C += 1;
/*     */         }
/*     */       }
/* 342 */     } else if (nextEvent.equals("dAp")) {
/* 343 */       if (this.cellCount[0] >= 1) {
/* 344 */         removeFromMutatedCells();
/*     */         
/* 346 */         this.cellCount[0] -= 1;
/* 347 */         this.R -= 1;
/*     */       }
/* 349 */       if ((this.R == 0) && (this.C == 0)) {
/* 350 */         this.currentTime = 1000.0D;
/*     */       }
/* 352 */     } else if (nextEvent.equals("gAp")) {
/* 353 */       if (this.cellCount[1] >= 1) {
/* 354 */         this.cellCount[1] -= 1;
/* 355 */         this.R -= 1;
/*     */       }
/* 357 */       if ((this.R == 0) && (this.C == 0)) {
/* 358 */         this.currentTime = 1000.0D;
/*     */       }
/* 360 */     } else if (nextEvent.equals("dE")) {
/* 361 */       if (this.cellCount[0] >= 1) {
/* 362 */         removeFromMutatedCells();
/*     */         
/* 364 */         this.cellCount[0] -= 1;
/* 365 */         this.R -= 1;
/*     */         
/*     */ 
/* 368 */         if ((!this.maxCellConBoolean) || (this.C < this.N2)) {
/* 369 */           this.cellCount[2] += 1;
/* 370 */           this.C += 1;
/*     */         }
/*     */       }
/* 373 */     } else if (nextEvent.equals("gE")) {
/* 374 */       if (this.cellCount[1] >= 1) {
/* 375 */         this.cellCount[1] -= 1;
/* 376 */         this.R -= 1;
/*     */         
/* 378 */         if ((!this.maxCellConBoolean) || (this.C < this.N2)) {
/* 379 */           this.cellCount[3] += 1;
/* 380 */           this.C += 1;
/*     */         }
/*     */       }
/* 383 */     } else if (nextEvent.equals("dD")) {
/* 384 */       if (this.cellCount[2] >= 1) {
/* 385 */         this.cellCount[2] -= 1;
/* 386 */         this.C -= 1;
/*     */       }
/* 388 */       if ((this.R == 0) && (this.C == 0)) {
/* 389 */         this.currentTime = 1000.0D;
/*     */       }
/* 391 */     } else if (nextEvent.equals("gD")) {
/* 392 */       if (this.cellCount[3] >= 1) {
/* 393 */         this.cellCount[3] -= 1;
/* 394 */         this.C -= 1;
/*     */       }
/* 396 */       if ((this.R == 0) && (this.C == 0)) {
/* 397 */         this.currentTime = 1000.0D;
/*     */       }
/* 399 */     } else if (nextEvent.equals("dAs")) {
/* 400 */       this.cellCount[2] += 1;
/* 401 */       this.C += 1;
/* 402 */     } else if (nextEvent.equals("gAs")) {
/* 403 */       this.cellCount[3] += 1;
/* 404 */       this.C += 1;
/*     */     }
/*     */   }
/*     */   
/*     */   private void removeFromMutatedCells()
/*     */   {
/* 410 */     int selected = runii(0, this.mutatedCells.size() - 1);
/*     */     
/* 412 */     this.mutatedCells.remove(selected);
/*     */   }
/*     */   
/*     */   public long TwoComp1()
/*     */   {
/* 417 */     if (this.randomStart) {
/* 418 */       this.Rd0 = rbin(this.R0, this.Rpercent);
/* 419 */       this.Cd0 = rbin(this.C0, this.Cpercent);
/*     */     }
/*     */     
/* 422 */     this.recCd[0] = this.Cd0;
/* 423 */     this.recC[0] = this.C0;
/* 424 */     this.recRd[0] = this.Rd0;
/* 425 */     this.recR[0] = this.R0;
/* 426 */     this.recY[0] = ((int)(this.sampleSize * this.Cd0 / this.C0));
/*     */     
/* 428 */     this.R = this.R0;
/* 429 */     this.cellCount[0] = this.Rd0;
/* 430 */     this.cellCount[1] = (this.R - this.Rd0);
/* 431 */     this.C = this.C0;
/* 432 */     this.cellCount[2] = this.Cd0;
/* 433 */     this.cellCount[3] = (this.C - this.Cd0);
/*     */     
/* 435 */     this.currentTime = 0.0D;
/*     */     
/* 437 */     for (int k = 1; k < this.L; k++)
/*     */     {
/* 439 */       while (this.currentTime <= this.times[k]) {
/* 440 */         this.sumOfRates = 0.0D;
/* 441 */         this.sumMutatedBirthRate = 0.0D;
/*     */         
/* 443 */         for (int i = 0; i < this.mutatedCells.size(); i++) {
/* 444 */           this.sumMutatedBirthRate += ((Double)this.mutatedCells.get(i)).doubleValue();
/*     */         }
/*     */         
/* 447 */         this.sumOfRates += this.sumMutatedBirthRate;
/*     */         
/* 449 */         for (int i = 1; i < this.typeOfEvents; i++) {
/* 450 */           this.compoundRates[i] = (this.rates[i] * this.cellCount[this.cellCountIdx[i]]);
/* 451 */           this.sumOfRates += this.compoundRates[i];
/*     */         }
/*     */         
/* 454 */         this.compoundRates[0] = (this.sumMutatedBirthRate / this.sumOfRates);
/* 455 */         for (int i = 1; i < this.typeOfEvents; i++) {
/* 456 */           this.compoundRates[i] /= this.sumOfRates;
/*     */         }
/* 458 */         this.currentTime += rexp(this.sumOfRates);
/*     */         
/*     */ 
/* 461 */         updateCompartment(this.events[((int)rmultnom1(this.compoundRates, this.typeOfEvents))]);
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 466 */       k--;
/* 467 */       this.recCd[(k + 1)] = this.cellCount[2];
/* 468 */       this.recC[(k + 1)] = this.C;
/* 469 */       this.recRd[(k + 1)] = this.cellCount[0];
/* 470 */       this.recR[(k + 1)] = this.R;
/* 471 */       this.recY[(k + 1)] = rbin(this.sampleSize, this.cellCount[2] / this.C);
/* 472 */       k++;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 480 */     this.currentGroup += 1;
/* 481 */     return 1L;
/*     */   }
/*     */   
/*     */ 
/*     */   public void createOutputFile()
/*     */   {
/*     */     try
/*     */     {
/* 489 */       File outputFile = new File(this.outputFileName);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 497 */       FileOutputStream out = new FileOutputStream(outputFile, false);
/* 498 */       PrintStream p = new PrintStream(out);
/* 499 */       p.println("#");
/* 500 */       p.println("Time Group Cd C Rd R Y");
/* 501 */       p.close();
/*     */     } catch (Exception e) {
/* 503 */       System.err.println("Error writing to file.");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void outputResults()
/*     */   {
/* 514 */     int i = 0;
/*     */     try
/*     */     {
/* 517 */       FileOutputStream updatedResults = new FileOutputStream(this.outputFileName, true);
/* 518 */       PrintStream p = new PrintStream(updatedResults);
/*     */       
/* 520 */       while (i < this.L) {
/* 521 */         p.print(i * this.sampleInterval + " " + this.currentGroup + " ");
/* 522 */         p.println(this.recCd[i] + " " + this.recC[i] + " " + this.recRd[i] + " " + this.recR[i] + " " + this.recY[i]);
/*     */         
/* 524 */         i++;
/*     */       }
/*     */       
/* 527 */       p.close();
/*     */     } catch (Exception e) {
/* 529 */       System.err.println("Error writing to file.");
/*     */     }
/*     */   }
/*     */   
/*     */   public void setCellChanceRate(double cellChanceRate)
/*     */   {
/* 535 */     this.cellChanceRate = cellChanceRate;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 543 */   private long Indexp = 2L;
/*     */   
/*     */ 
/* 546 */   protected int N = 10000;
/*     */   
/*     */ 
/* 549 */   public int R0 = 100;
/* 550 */   public int Rd0 = 50;
/* 551 */   public int C0 = 100;
/* 552 */   public int Cd0 = 50;
/*     */   
/*     */   private int[] cellCount;
/*     */   
/*     */   private int R;
/*     */   private int C;
/*     */   private double Rpercent;
/*     */   private double Cpercent;
/*     */   public int[] times;
/*     */   public int[] recRd;
/*     */   public int[] recR;
/*     */   public int[] recCd;
/*     */   public int[] recC;
/*     */   public int[] recY;
/* 566 */   private int currentGroup = 1;
/*     */   
/*     */   private double currentTime;
/*     */   
/*     */   private double sumOfRates;
/*     */   
/*     */   private int typeOfEvents;
/*     */   private double[] rates;
/*     */   private double[] compoundRates;
/*     */   private int[] cellCountIdx;
/* 576 */   private int sampleSize = 70;
/* 577 */   private int sampleInterval = 4;
/*     */   
/*     */   private String[] events;
/*     */   
/*     */   private String outputFileName;
/*     */   
/* 583 */   public boolean writeResults2File = true;
/*     */   private boolean randomStart;
/*     */   private boolean cellChance;
/*     */   private double chanceSurvive;
/*     */   private double cellChanceRate;
/*     */   private boolean maxCellConBoolean;
/*     */   private int N2;
/*     */   private LinkedList<Double> mutatedCells;
/*     */   private double sumMutatedBirthRate;
/*     */   private double mutationProb;
/*     */   private double proportion;
/*     */   private PrintStream p;
/*     */ }


/* Location:              /Users/jasonxu/Desktop/HematopoiesisSimulator.jar!/simulatorcore/HumanRandomMutation2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */