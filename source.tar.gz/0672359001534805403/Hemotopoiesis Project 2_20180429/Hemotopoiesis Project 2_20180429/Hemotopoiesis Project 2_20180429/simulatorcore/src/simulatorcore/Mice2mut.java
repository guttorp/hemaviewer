/*     */ package simulatorcore;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Mice2mut
/*     */   extends Mice2new
/*     */ {
/*     */   private ArrayList<Double> mutatedCells;
/*     */   private double sumMutatedBirthRate;
/*     */   private double mutationProb;
/*     */   private double proportion;
/*     */   private boolean noUpperLimitRes;
/*     */   
/*     */   public Mice2mut(int L, int set, int N, double Rpercent, int R0, double Cpercent, int C0, double[] rates, String[] events, int sampleSize, int seed, int sampleInterval, boolean setCellChance, double cellChanceRate, boolean maxCellConBoolean, int N2, double proportion, double mutationProb, boolean noUpperLimitRes)
/*     */   {
/*  27 */     super(L, set, N, Rpercent, R0, Cpercent, C0, rates, events, sampleSize, seed, sampleInterval, setCellChance, cellChanceRate, maxCellConBoolean, N);
/*     */     
/*  29 */     initialize(proportion, mutationProb);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Mice2mut(int L, int set, int N, int Rd0, int R0, int Cd0, int C0, double[] rates, String[] events, int sampleSize, int seed, int sampleInterval, boolean setCellChance, double cellChanceRate, boolean maxCellConBoolean, int N2, double proportion, double mutationProb, boolean noUpperLimitRes)
/*     */   {
/*  40 */     super(L, set, N, 1, R0, 0, C0, rates, events, sampleSize, seed, sampleInterval, setCellChance, cellChanceRate, maxCellConBoolean, N);
/*  41 */     initialize(proportion, mutationProb);
/*     */   }
/*     */   
/*     */   private void initialize(double proportion, double mutationProb) {
/*  45 */     this.proportion = proportion;
/*  46 */     this.mutationProb = mutationProb;
/*  47 */     this.mutatedCells = new ArrayList();
/*  48 */     this.sumMutatedBirthRate = 0.0D;
/*  49 */     this.noUpperLimitRes = false;
/*     */     
/*  51 */     if (this.Rd0 != 0) {
/*  52 */       for (int i = 1; i <= this.Rd0; i++) {
/*  53 */         this.mutatedCells.add(Double.valueOf(this.rates[0] * (1.0D + runir(0.0D, proportion))));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void updateCompartment(String nextEvent)
/*     */   {
/*  64 */     if (nextEvent.equals("dB"))
/*     */     {
/*     */ 
/*  67 */       if ((this.noUpperLimitRes) || ((this.R < this.N) && (this.cellCount[0] > 0)))
/*     */       {
/*     */ 
/*  70 */         if (this.cellCount[0] > 0) {
/*  71 */           double[] mProb = new double[this.mutatedCells.size()];
/*  72 */           for (int i = 0; i < this.mutatedCells.size(); i++) {
/*  73 */             mProb[i] = (((Double)this.mutatedCells.get(i)).doubleValue() / this.sumMutatedBirthRate);
/*     */           }
/*  75 */           int selected = (int)rmultnom1(mProb, this.mutatedCells.size());
/*     */           
/*     */ 
/*  78 */           this.mutatedCells.add(Double.valueOf(((Double)this.mutatedCells.get(selected)).doubleValue() * (1.0D + runir(0.0D, this.proportion))));
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*  83 */           this.cellCount[0] += 1;
/*  84 */           this.R += 1;
/*     */         }
/*  86 */         else if ((this.cellChance) && ((!this.maxCellConBoolean) || (this.C < this.N2))) {
/*  87 */           this.chanceSurvive = Math.random();
/*  88 */           if (this.chanceSurvive > this.cellChanceRate) {
/*  89 */             this.cellCount[2] += 1;
/*  90 */             this.C += 1;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*  95 */     else if (nextEvent.equals("gB")) {
/*  96 */       if ((this.noUpperLimitRes) || ((this.R < this.N) && (this.cellCount[1] > 0))) {
/*  97 */         double randy = runi();
/*  98 */         if (randy <= this.mutationProb)
/*     */         {
/*     */ 
/* 101 */           this.mutatedCells.add(Double.valueOf(this.rates[0] * (1.0D + runir(0.0D, this.proportion))));
/*     */           
/* 103 */           this.cellCount[0] += 1;
/*     */         } else {
/* 105 */           this.cellCount[1] += 1;
/*     */         }
/*     */         
/* 108 */         this.R += 1;
/*     */       }
/* 110 */       else if ((this.cellChance) && ((!this.maxCellConBoolean) || (this.C < this.N2))) {
/* 111 */         this.chanceSurvive = Math.random();
/* 112 */         if (this.chanceSurvive > this.cellChanceRate) {
/* 113 */           this.cellCount[3] += 1;
/* 114 */           this.C += 1;
/*     */         }
/*     */       }
/* 117 */     } else if (nextEvent.equals("dAp")) {
/* 118 */       if (this.cellCount[0] >= 1) {
/* 119 */         removeFromMutatedCells();
/*     */         
/* 121 */         this.cellCount[0] -= 1;
/* 122 */         this.R -= 1;
/*     */       }
/* 124 */       if ((this.R == 0) && (this.C == 0)) {
/* 125 */         this.currentTime = 1000.0D;
/*     */       }
/* 127 */     } else if (nextEvent.equals("gAp")) {
/* 128 */       if (this.cellCount[1] >= 1) {
/* 129 */         this.cellCount[1] -= 1;
/* 130 */         this.R -= 1;
/*     */       }
/* 132 */       if ((this.R == 0) && (this.C == 0)) {
/* 133 */         this.currentTime = 1000.0D;
/*     */       }
/* 135 */     } else if (nextEvent.equals("dE")) {
/* 136 */       if (this.cellCount[0] >= 1) {
/* 137 */         removeFromMutatedCells();
/*     */         
/* 139 */         this.cellCount[0] -= 1;
/* 140 */         this.R -= 1;
/*     */         
/*     */ 
/* 143 */         if ((!this.maxCellConBoolean) || (this.C < this.N2)) {
/* 144 */           this.cellCount[2] += 1;
/* 145 */           this.C += 1;
/*     */         }
/*     */       }
/* 148 */     } else if (nextEvent.equals("gE")) {
/* 149 */       if (this.cellCount[1] >= 1) {
/* 150 */         this.cellCount[1] -= 1;
/* 151 */         this.R -= 1;
/*     */         
/* 153 */         if ((!this.maxCellConBoolean) || (this.C < this.N2)) {
/* 154 */           this.cellCount[3] += 1;
/* 155 */           this.C += 1;
/*     */         }
/*     */       }
/* 158 */     } else if (nextEvent.equals("dD")) {
/* 159 */       if (this.cellCount[2] >= 1) {
/* 160 */         this.cellCount[2] -= 1;
/* 161 */         this.C -= 1;
/*     */       }
/* 163 */       if ((this.R == 0) && (this.C == 0)) {
/* 164 */         this.currentTime = 1000.0D;
/*     */       }
/* 166 */     } else if (nextEvent.equals("gD")) {
/* 167 */       if (this.cellCount[3] >= 1) {
/* 168 */         this.cellCount[3] -= 1;
/* 169 */         this.C -= 1;
/*     */       }
/* 171 */       if ((this.R == 0) && (this.C == 0)) {
/* 172 */         this.currentTime = 1000.0D;
/*     */       }
/* 174 */     } else if (nextEvent.equals("dAs")) {
/* 175 */       this.cellCount[2] += 1;
/* 176 */       this.C += 1;
/* 177 */     } else if (nextEvent.equals("gAs")) {
/* 178 */       this.cellCount[3] += 1;
/* 179 */       this.C += 1;
/*     */     }
/*     */   }
/*     */   
/*     */   private void removeFromMutatedCells()
/*     */   {
/* 185 */     int selected = runii(0, this.mutatedCells.size() - 1);
/*     */     
/* 187 */     this.mutatedCells.remove(selected);
/*     */   }
/*     */   
/*     */   public long TwoComp1()
/*     */   {
/* 192 */     if (this.randomStart) {
/* 193 */       this.Rd0 = rbin(this.R0, this.Rpercent);
/* 194 */       this.Cd0 = rbin(this.C0, this.Cpercent);
/*     */     }
/*     */     
/* 197 */     if (this.Rd0 != 0) {
/* 198 */       for (int i = 1; i <= this.Rd0; i++) {
/* 199 */         this.mutatedCells.add(Double.valueOf(this.rates[0] * (1.0D + runir(0.0D, this.proportion))));
/*     */       }
/*     */     }
/*     */     
/* 203 */     this.recCd[0] = this.Cd0;
/* 204 */     this.recC[0] = this.C0;
/* 205 */     this.recRd[0] = this.Rd0;
/* 206 */     this.recR[0] = this.R0;
/* 207 */     this.recY[0] = ((int)(this.sampleSize * this.Cd0 / this.C0));
/*     */     
/* 209 */     this.R = this.R0;
/* 210 */     this.cellCount[0] = this.Rd0;
/* 211 */     this.cellCount[1] = (this.R - this.Rd0);
/* 212 */     this.C = this.C0;
/* 213 */     this.cellCount[2] = this.Cd0;
/* 214 */     this.cellCount[3] = (this.C - this.Cd0);
/*     */     
/* 216 */     this.currentTime = 0.0D;
/*     */     
/* 218 */     for (int k = 1; k < this.L; k++)
/*     */     {
/* 220 */       while (this.currentTime <= this.times[k]) {
/* 221 */         this.sumOfRates = 0.0D;
/* 222 */         this.sumMutatedBirthRate = 0.0D;
/* 223 */         if (this.mutatedCells != null) {
/* 224 */           for (int i = 0; i < this.mutatedCells.size(); i++) {
/* 225 */             this.sumMutatedBirthRate += ((Double)this.mutatedCells.get(i)).doubleValue();
/*     */           }
/*     */         }
/* 228 */         this.sumOfRates += this.sumMutatedBirthRate;
/*     */         
/* 230 */         for (int i = 1; i < this.typeOfEvents; i++) {
/* 231 */           this.compoundRates[i] = (this.rates[i] * this.cellCount[this.cellCountIdx[i]]);
/* 232 */           this.sumOfRates += this.compoundRates[i];
/*     */         }
/*     */         
/* 235 */         this.compoundRates[0] = (this.sumMutatedBirthRate / this.sumOfRates);
/* 236 */         for (int i = 1; i < this.typeOfEvents; i++) {
/* 237 */           this.compoundRates[i] /= this.sumOfRates;
/*     */         }
/* 239 */         this.currentTime += rexp(this.sumOfRates);
/*     */         
/*     */ 
/* 242 */         updateCompartment(this.events[((int)rmultnom1(this.compoundRates, this.typeOfEvents))]);
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 247 */       k--;
/* 248 */       this.recCd[(k + 1)] = this.cellCount[2];
/* 249 */       this.recC[(k + 1)] = this.C;
/* 250 */       this.recRd[(k + 1)] = this.cellCount[0];
/* 251 */       this.recR[(k + 1)] = this.R;
/* 252 */       this.recY[(k + 1)] = rbin(this.sampleSize, this.cellCount[2] / this.C);
/* 253 */       k++;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 261 */     this.currentGroup += 1;
/* 262 */     return 1L;
/*     */   }
/*     */ }


/* Location:              /Users/jasonxu/Desktop/HematopoiesisSimulator.jar!/simulatorcore/Mice2mut.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */