/*     */ package simulatorcore;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.PrintStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Mice2new
/*     */   extends MiceRandom
/*     */ {
/*     */   protected final int L;
/*     */   protected final int set;
/*     */   
/*     */   public Mice2new(int _L, int _set, int _N, double _Rpercent, int _R0, double _Cpercent, int _C0, double[] _rates, String[] _events, int _sampleSize, int _seed, int _sampleInterval, boolean _setCellChance, double cellChanceRate, boolean maxCellConBoolean, int N2)
/*     */   {
/*  37 */     super(_seed);
/*  38 */     this.randomStart = true;
/*  39 */     this.Rpercent = _Rpercent;
/*  40 */     this.Cpercent = _Cpercent;
/*  41 */     this.L = (_L + 1);
/*  42 */     this.set = _set;
/*  43 */     this.N = _N;
/*  44 */     this.R0 = _R0;
/*  45 */     this.C0 = _C0;
/*  46 */     this.rates = _rates;
/*  47 */     this.events = new String[_events.length * 2];
/*  48 */     this.sampleSize = _sampleSize;
/*  49 */     this.sampleInterval = _sampleInterval;
/*  50 */     this.cellChance = _setCellChance;
/*  51 */     this.chanceSurvive = Math.random();
/*  52 */     this.cellChanceRate = cellChanceRate;
/*  53 */     this.maxCellConBoolean = maxCellConBoolean;
/*  54 */     this.N2 = N2;
/*     */     
/*  56 */     for (int i = 0; i < _events.length; i++) {
/*  57 */       this.events[i] = ("d" + _events[i]);
/*     */     }
/*  59 */     for (int i = 0; i < _events.length; i++) {
/*  60 */       this.events[(i + _events.length)] = ("g" + _events[i]);
/*     */     }
/*  62 */     init();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Mice2new(int _L, int _set, int _N, int _Rd0, int _R0, int _Cd0, int _C0, double[] _rates, String[] _events, int _sampleSize, int _seed, int _sampleInterval, boolean _setCellChance, double cellChanceRate, boolean maxCellConBoolean, int N2)
/*     */   {
/*  70 */     super(_seed);
/*  71 */     this.randomStart = false;
/*  72 */     this.Rd0 = _Rd0;
/*  73 */     this.Cd0 = _Cd0;
/*     */     
/*  75 */     this.L = (_L + 1);
/*  76 */     this.set = _set;
/*  77 */     this.N = _N;
/*  78 */     this.R0 = _R0;
/*  79 */     this.C0 = _C0;
/*  80 */     this.rates = _rates;
/*  81 */     this.events = new String[_events.length * 2];
/*  82 */     this.sampleSize = _sampleSize;
/*  83 */     this.sampleInterval = _sampleInterval;
/*  84 */     this.cellChance = _setCellChance;
/*  85 */     this.chanceSurvive = Math.random();
/*  86 */     this.cellChanceRate = cellChanceRate;
/*  87 */     this.maxCellConBoolean = maxCellConBoolean;
/*  88 */     this.N2 = N2;
/*     */     
/*  90 */     for (int i = 0; i < _events.length; i++) {
/*  91 */       this.events[i] = ("d" + _events[i]);
/*     */     }
/*  93 */     for (int i = 0; i < _events.length; i++) {
/*  94 */       this.events[(i + _events.length)] = ("g" + _events[i]);
/*     */     }
/*  96 */     init();
/*     */   }
/*     */   
/*     */   private void init()
/*     */   {
/* 101 */     this.times = new int[this.L];
/* 102 */     this.recRd = new int[this.L];
/* 103 */     this.recR = new int[this.L];
/* 104 */     this.recCd = new int[this.L];
/* 105 */     this.recC = new int[this.L];
/* 106 */     this.recY = new int[this.L];
/*     */     
/* 108 */     this.cellCount = new int[4];
/* 109 */     this.typeOfEvents = this.events.length;
/* 110 */     this.compoundRates = new double[this.typeOfEvents];
/* 111 */     this.cellCountIdx = new int[this.typeOfEvents];
/* 112 */     for (int i = 0; i < this.typeOfEvents; i++) {
/* 113 */       this.cellCountIdx[i] = 0;
/* 114 */       if (this.events[i].substring(1, 2).equals("D")) {
/* 115 */         this.cellCountIdx[i] = 2;
/*     */       }
/* 117 */       if (this.events[i].substring(0, 1).equals("g")) {
/* 118 */         this.cellCountIdx[i] += 1;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void simulate(String outputFileName)
/*     */   {
/* 125 */     this.outputFileName = outputFileName;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 132 */     int r = 0;
/*     */     
/* 134 */     for (int i = 0; i < this.L; i++) {
/* 135 */       this.times[i] = r;
/* 136 */       r += this.sampleInterval;
/*     */     }
/*     */     
/* 139 */     for (int k = 0; k < this.set; k++) {
/* 140 */       TwoComp1();
/*     */     }
/*     */   }
/*     */   
/*     */   public void updateCompartment(String nextEvent)
/*     */   {
/* 146 */     if (nextEvent.equals("dB"))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 154 */       if ((this.R < this.N) && (this.cellCount[0] > 0)) {
/* 155 */         this.cellCount[0] += 1;
/* 156 */         this.R += 1;
/* 157 */       } else if ((this.cellChance) && ((!this.maxCellConBoolean) || (this.C < this.N2))) {
/* 158 */         this.chanceSurvive = Math.random();
/* 159 */         if (this.chanceSurvive > this.cellChanceRate) {
/* 160 */           this.cellCount[2] += 1;
/* 161 */           this.C += 1;
/*     */         }
/*     */       }
/*     */     }
/* 165 */     else if (nextEvent.equals("gB")) {
/* 166 */       if ((this.R < this.N) && (this.cellCount[1] > 0)) {
/* 167 */         this.cellCount[1] += 1;
/* 168 */         this.R += 1;
/* 169 */       } else if ((this.cellChance) && ((!this.maxCellConBoolean) || (this.C < this.N2))) {
/* 170 */         this.chanceSurvive = Math.random();
/* 171 */         if (this.chanceSurvive > this.cellChanceRate) {
/* 172 */           this.cellCount[3] += 1;
/* 173 */           this.C += 1;
/*     */         }
/*     */       }
/* 176 */     } else if (nextEvent.equals("dAp")) {
/* 177 */       if (this.cellCount[0] >= 1) {
/* 178 */         this.cellCount[0] -= 1;
/* 179 */         this.R -= 1;
/*     */       }
/* 181 */       if ((this.R == 0) && (this.C == 0)) {
/* 182 */         this.currentTime = 1000.0D;
/*     */       }
/* 184 */     } else if (nextEvent.equals("gAp")) {
/* 185 */       if (this.cellCount[1] >= 1) {
/* 186 */         this.cellCount[1] -= 1;
/* 187 */         this.R -= 1;
/*     */       }
/* 189 */       if ((this.R == 0) && (this.C == 0)) {
/* 190 */         this.currentTime = 1000.0D;
/*     */       }
/* 192 */     } else if (nextEvent.equals("dE")) {
/* 193 */       if (this.cellCount[0] >= 1) {
/* 194 */         this.cellCount[0] -= 1;
/* 195 */         this.R -= 1;
/*     */         
/*     */ 
/* 198 */         if ((!this.maxCellConBoolean) || (this.C < this.N2)) {
/* 199 */           this.cellCount[2] += 1;
/* 200 */           this.C += 1;
/*     */         }
/*     */       }
/* 203 */     } else if (nextEvent.equals("gE")) {
/* 204 */       if (this.cellCount[1] >= 1) {
/* 205 */         this.cellCount[1] -= 1;
/* 206 */         this.R -= 1;
/*     */         
/* 208 */         if ((!this.maxCellConBoolean) || (this.C < this.N2)) {
/* 209 */           this.cellCount[3] += 1;
/* 210 */           this.C += 1;
/*     */         }
/*     */       }
/* 213 */     } else if (nextEvent.equals("dD")) {
/* 214 */       if (this.cellCount[2] >= 1) {
/* 215 */         this.cellCount[2] -= 1;
/* 216 */         this.C -= 1;
/*     */       }
/* 218 */       if ((this.R == 0) && (this.C == 0)) {
/* 219 */         this.currentTime = 1000.0D;
/*     */       }
/* 221 */     } else if (nextEvent.equals("gD")) {
/* 222 */       if (this.cellCount[3] >= 1) {
/* 223 */         this.cellCount[3] -= 1;
/* 224 */         this.C -= 1;
/*     */       }
/* 226 */       if ((this.R == 0) && (this.C == 0)) {
/* 227 */         this.currentTime = 1000.0D;
/*     */       }
/* 229 */     } else if (nextEvent.equals("dAs")) {
/* 230 */       this.cellCount[2] += 1;
/* 231 */       this.C += 1;
/* 232 */     } else if (nextEvent.equals("gAs")) {
/* 233 */       this.cellCount[3] += 1;
/* 234 */       this.C += 1;
/*     */     }
/*     */   }
/*     */   
/*     */   public long TwoComp1()
/*     */   {
/* 240 */     if (this.randomStart)
/*     */     {
/* 242 */       this.Rd0 = rbin(this.R0, this.Rpercent);
/* 243 */       this.Cd0 = rbin(this.C0, this.Cpercent);
/*     */     }
/*     */     
/* 246 */     this.recCd[0] = this.Cd0;
/* 247 */     this.recC[0] = this.C0;
/* 248 */     this.recRd[0] = this.Rd0;
/* 249 */     this.recR[0] = this.R0;
/* 250 */     this.recY[0] = ((int)(this.sampleSize * this.Cd0 / this.C0));
/*     */     
/* 252 */     this.R = this.R0;
/* 253 */     this.cellCount[0] = this.Rd0;
/* 254 */     this.cellCount[1] = (this.R - this.Rd0);
/* 255 */     this.C = this.C0;
/* 256 */     this.cellCount[2] = this.Cd0;
/* 257 */     this.cellCount[3] = (this.C - this.Cd0);
/*     */     
/* 259 */     this.currentTime = 0.0D;
/* 260 */     for (int k = 1; k < this.L; k++)
/*     */     {
/* 262 */       while (this.currentTime <= this.times[k]) {
/* 263 */         this.sumOfRates = 0.0D;
/* 264 */         for (int i = 0; i < this.typeOfEvents; i++) {
/* 265 */           this.compoundRates[i] = (this.rates[i] * this.cellCount[this.cellCountIdx[i]]);
/* 266 */           this.sumOfRates += this.compoundRates[i];
/*     */         }
/*     */         
/* 269 */         for (int i = 0; i < this.typeOfEvents; i++) {
/* 270 */           this.compoundRates[i] /= this.sumOfRates;
/*     */         }
/*     */         
/* 273 */         this.currentTime += rexp(this.sumOfRates);
/*     */         
/*     */ 
/* 276 */         updateCompartment(this.events[((int)rmultnom1(this.compoundRates, this.typeOfEvents))]);
/*     */       }
/*     */       
/*     */ 
/* 280 */       k--;
/* 281 */       this.recCd[(k + 1)] = this.cellCount[2];
/* 282 */       this.recC[(k + 1)] = this.C;
/* 283 */       this.recRd[(k + 1)] = this.cellCount[0];
/* 284 */       this.recR[(k + 1)] = this.R;
/* 285 */       this.recY[(k + 1)] = rbin(this.sampleSize, (double)this.cellCount[2] / (double)this.C);
/* 286 */       k++;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 296 */     this.currentGroup += 1;
/* 297 */     return 1L;
/*     */   }
/*     */   
/*     */ 
/*     */   public void createOutputFile()
/*     */   {
/*     */     try
/*     */     {
/* 305 */       File outputFile = new File(this.outputFileName);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 313 */       FileOutputStream out = new FileOutputStream(outputFile, false);
/* 314 */       PrintStream p = new PrintStream(out);
/* 315 */       p.println("#");
/* 316 */       p.println("Time Group Cd C Rd R Y");
/* 317 */       outputResults();
/* 318 */       p.close();
/*     */     } catch (Exception e) {
/* 320 */       System.err.println("Error writing to file.");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void outputResults()
/*     */   {
/* 332 */     int i = 0;
/*     */     try
/*     */     {
/* 335 */       FileOutputStream updatedResults = new FileOutputStream(this.outputFileName, true);
/* 336 */       PrintStream p = new PrintStream(updatedResults);
/*     */       
/* 338 */       while (i < this.L) {
/* 339 */         p.print(i * this.sampleInterval + " " + this.currentGroup + " ");
/* 340 */         p.println(this.recCd[i] + " " + this.recC[i] + " " + this.recRd[i] + " " + this.recR[i] + " " + this.recY[i]);
/*     */         
/* 342 */         i++;
/*     */       }
/*     */       
/* 345 */       p.close();
/*     */     } catch (Exception e) {
/* 347 */       System.err.println("Error writing to file.");
/*     */     }
/*     */   }
/*     */   
/*     */   public void setCellChanceRate(double cellChanceRate)
/*     */   {
/* 353 */     this.cellChanceRate = cellChanceRate;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 363 */   protected long Indexp = 2L;
/*     */   
/*     */ 
/* 366 */   protected int N = 10000;
/*     */   
/*     */ 
/* 369 */   public int R0 = 100;
/* 370 */   public int Rd0 = 50;
/* 371 */   public int C0 = 100;
/* 372 */   public int Cd0 = 50;
/*     */   
/*     */   protected int[] cellCount;
/*     */   
/*     */   protected int R;
/*     */   protected int C;
/*     */   protected double Rpercent;
/*     */   protected double Cpercent;
/*     */   public int[] times;
/*     */   public int[] recRd;
/*     */   public int[] recR;
/*     */   public int[] recCd;
/*     */   public int[] recC;
/*     */   public int[] recY;
/* 386 */   protected int currentGroup = 1;
/*     */   
/*     */   protected double currentTime;
/*     */   
/*     */   protected double sumOfRates;
/*     */   
/*     */   protected int typeOfEvents;
/*     */   protected double[] rates;
/*     */   protected double[] compoundRates;
/*     */   protected int[] cellCountIdx;
/* 396 */   protected int sampleSize = 70;
/* 397 */   protected int sampleInterval = 4;
/*     */   
/*     */   protected String[] events;
/*     */   
/*     */   protected String outputFileName;
/*     */   
/* 403 */   public boolean writeResults2File = true;
/*     */   protected boolean randomStart;
/*     */   protected boolean cellChance;
/*     */   protected double chanceSurvive;
/*     */   protected double cellChanceRate;
/*     */   protected boolean maxCellConBoolean;
/*     */   protected int N2;
/*     */ }


/* Location:              /Users/jasonxu/Desktop/HematopoiesisSimulator.jar!/simulatorcore/Mice2new.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */