/*     */ package simulatorcore;
/*     */ 
/*     */ import edu.rit.util.Random;
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Mice2newSim
/*     */   extends MiceRandom
/*     */ {
/*     */   private final int L;
/*     */   private final int set;
/*     */   
/*     */   public static void main(String[] args)
/*     */     throws IOException
/*     */   {
/*  29 */     double lambdaInit = 40.0D;
/*  30 */     double nuInit = 56.1D;
/*  31 */     double muInit = 6.7D;
/*  32 */     double alphaInit = 285.7D;
/*     */     
/*     */ 
/*  35 */     int totalWeeks = 1040;
/*  36 */     int R0 = 10000;
/*     */     
/*  38 */     int C0 = (int)(R0 * muInit / nuInit);
/*     */     
/*  40 */     double lambda = 40.0D;
/*  41 */     double mu = 6.7D;
/*  42 */     double alpha = 285.7D;
/*  43 */     double nu = 56.1D;
/*  44 */     double mll = 1.0D;double mva = 1.0D;double dvv = 1.0D;double dvu = 1.0D;double ratio_as = 1.0D;
/*     */     
/*  46 */     double l = 1.0D / lambda;
/*  47 */     double lb = 0.0D;
/*  48 */     double v = 1.0D / nu;
/*  49 */     double u = 1.0D / mu;
/*  50 */     double a = 1.0D / alpha;
/*  51 */     double as = 0.0D;
/*  52 */     double ld = l * mll;
/*  53 */     double ldb = 1.0D * mll;
/*  54 */     double ad = a * mva;
/*  55 */     double vd = v * dvv;
/*  56 */     double ud = u * dvu;
/*  57 */     double asd = as * ratio_as;
/*  58 */     String[] events = { "B", "E", "D", "Ap" };
/*  59 */     double[] rates = { l, v, u, a, ld, vd, ud, ad };
/*     */     
/*     */ 
/*  62 */     int sampleInterval = 260;
/*     */     
/*  64 */     int L = totalWeeks / sampleInterval;
/*  65 */     int set = 1;
/*  66 */     int N = 10000;
/*     */     
/*     */ 
/*     */ 
/*  70 */     double Rpercent = 0.1D;
/*  71 */     double Cpercent = Rpercent;
/*     */     
/*  73 */     String outputFileName = "HumanRd0percent" + (int)(Rpercent * 100.0D) + ".txt";
/*     */     
/*     */ 
/*  76 */     int sampleSize = 70;
/*  77 */     boolean setCellChance = false;
/*  78 */     int seed = (int)(System.currentTimeMillis() % 1000000000L);
/*  79 */     double cellChanceRate = 0.5D;
/*     */     
/*  81 */     FileOutputStream updatedResults = new FileOutputStream(outputFileName, false);
/*  82 */     PrintStream p = new PrintStream(updatedResults);
/*     */     
/*     */ 
/*  85 */     p.println("Jan. 25 2010");
/*  86 */     p.println("Human: initial percentage of type a/type d cells in the Reserve compartment is " + 
/*  87 */       (int)(Rpercent * 100.0D) + "%.");
/*  88 */     p.println("type a cells in Reserve are not bounded. \nR0 = " + R0 + ", C0 = " + C0 + 
/*  89 */       ". Total 1040 weeks. Sample size 70.");
/*     */     
/*  91 */     for (int i = 1; i <= 10; i++)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 107 */       Mice2newSim mice2new = new Mice2newSim(L, set, N, Rpercent, R0, Cpercent, C0, 
/* 108 */         rates, events, sampleSize, seed, sampleInterval, 
/* 109 */         setCellChance, cellChanceRate, false, N);
/*     */       
/*     */ 
/*     */ 
/* 113 */       mice2new.simulate("");
/*     */       
/*     */ 
/*     */ 
/* 117 */       p.println("Run #" + i);
/* 118 */       p.printf("%10s %10s %10s %10s %10s %10s \n", new Object[] { "Time", "Cd", "C", "Rd", "R", "Y" });
/* 119 */       int k = 0;
/*     */       
/*     */ 
/* 122 */       while (k <= L) {
/* 123 */         p.printf("%10d %10d %10d %10d %10d %10d \n", new Object[] { Integer.valueOf(k * sampleInterval), 
/* 124 */           Integer.valueOf(mice2new.recCd[k]), Integer.valueOf(mice2new.recC[k]), Integer.valueOf(mice2new.recRd[k]), 
/* 125 */           Integer.valueOf(mice2new.recR[k]), Integer.valueOf(mice2new.recY[k]) });
/* 126 */         k++;
/*     */       }
/* 128 */       seed = (int)(mice2new.random.nextDouble() * 1.0E9D);
/* 129 */       p.println();
/*     */     }
/*     */     
/*     */ 
/* 133 */     p.close();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Mice2newSim(int _L, int _set, int _N, double _Rpercent, int _R0, double _Cpercent, int _C0, double[] _rates, String[] _events, int _sampleSize, int _seed, int _sampleInterval, boolean _setCellChance, double cellChanceRate, boolean maxCellConBoolean, int N2)
/*     */   {
/* 142 */     super(_seed);
/* 143 */     this.randomStart = true;
/* 144 */     this.Rpercent = _Rpercent;
/* 145 */     this.Cpercent = _Cpercent;
/* 146 */     this.L = (_L + 1);
/* 147 */     this.set = _set;
/* 148 */     this.N = _N;
/* 149 */     this.R0 = _R0;
/* 150 */     this.C0 = _C0;
/* 151 */     this.rates = _rates;
/* 152 */     this.events = new String[_events.length * 2];
/* 153 */     this.sampleSize = _sampleSize;
/* 154 */     this.sampleInterval = _sampleInterval;
/* 155 */     this.cellChance = _setCellChance;
/* 156 */     this.chanceSurvive = Math.random();
/* 157 */     this.cellChanceRate = cellChanceRate;
/* 158 */     this.maxCellConBoolean = maxCellConBoolean;
/* 159 */     this.N2 = N2;
/*     */     
/* 161 */     for (int i = 0; i < _events.length; i++) {
/* 162 */       this.events[i] = ("d" + _events[i]);
/*     */     }
/* 164 */     for (int i = 0; i < _events.length; i++) {
/* 165 */       this.events[(i + _events.length)] = ("g" + _events[i]);
/*     */     }
/* 167 */     init();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Mice2newSim(int _L, int _set, int _N, int _Rd0, int _R0, int _Cd0, int _C0, double[] _rates, String[] _events, int _sampleSize, int _seed, int _sampleInterval, boolean _setCellChance, double cellChanceRate)
/*     */   {
/* 175 */     super(_seed);
/* 176 */     this.randomStart = false;
/* 177 */     this.Rd0 = _Rd0;
/* 178 */     this.Cd0 = _Cd0;
/*     */     
/* 180 */     this.L = (_L + 1);
/* 181 */     this.set = _set;
/* 182 */     this.N = _N;
/* 183 */     this.R0 = _R0;
/* 184 */     this.C0 = _C0;
/* 185 */     this.rates = _rates;
/* 186 */     this.events = new String[_events.length * 2];
/* 187 */     this.sampleSize = _sampleSize;
/* 188 */     this.sampleInterval = _sampleInterval;
/* 189 */     this.cellChance = _setCellChance;
/* 190 */     this.chanceSurvive = Math.random();
/* 191 */     this.cellChanceRate = cellChanceRate;
/*     */     
/* 193 */     for (int i = 0; i < _events.length; i++) {
/* 194 */       this.events[i] = ("d" + _events[i]);
/*     */     }
/* 196 */     for (int i = 0; i < _events.length; i++) {
/* 197 */       this.events[(i + _events.length)] = ("g" + _events[i]);
/*     */     }
/* 199 */     init();
/*     */   }
/*     */   
/*     */ 
/*     */   private void init()
/*     */   {
/* 205 */     this.times = new int[this.L];
/* 206 */     this.recRd = new int[this.L];
/* 207 */     this.recR = new int[this.L];
/* 208 */     this.recCd = new int[this.L];
/* 209 */     this.recC = new int[this.L];
/* 210 */     this.recY = new int[this.L];
/*     */     
/* 212 */     this.cellCount = new int[4];
/* 213 */     this.typeOfEvents = this.events.length;
/* 214 */     this.compoundRates = new double[this.typeOfEvents];
/* 215 */     this.cellCountIdx = new int[this.typeOfEvents];
/* 216 */     for (int i = 0; i < this.typeOfEvents; i++) {
/* 217 */       this.cellCountIdx[i] = 0;
/* 218 */       if (this.events[i].substring(1, 2).equals("D")) {
/* 219 */         this.cellCountIdx[i] = 2;
/*     */       }
/* 221 */       if (this.events[i].substring(0, 1).equals("g")) {
/* 222 */         this.cellCountIdx[i] += 1;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void simulate(String outputFileName)
/*     */   {
/* 229 */     this.outputFileName = outputFileName;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 235 */     int r = 0;
/*     */     
/* 237 */     for (int i = 0; i < this.L; i++) {
/* 238 */       this.times[i] = r;
/* 239 */       r += this.sampleInterval;
/*     */     }
/*     */     
/* 242 */     for (int k = 0; k < this.set; k++) {
/* 243 */       TwoComp1();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void updateCompartment(String nextEvent)
/*     */   {
/* 250 */     if (nextEvent.equals("dB"))
/*     */     {
/*     */ 
/*     */ 
/* 254 */       if (this.cellCount[0] > 0) {
/* 255 */         this.cellCount[0] += 1;
/* 256 */         this.R += 1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     }
/* 272 */     else if (nextEvent.equals("gB")) {
/* 273 */       if ((this.R < this.N) && (this.cellCount[1] > 0)) {
/* 274 */         this.cellCount[1] += 1;
/* 275 */         this.R += 1;
/* 276 */       } else if ((this.cellChance) && ((!this.maxCellConBoolean) || (this.C < this.N2))) {
/* 277 */         this.chanceSurvive = Math.random();
/* 278 */         if (this.chanceSurvive > this.cellChanceRate) {
/* 279 */           this.cellCount[3] += 1;
/* 280 */           this.C += 1;
/*     */         }
/*     */       }
/* 283 */     } else if (nextEvent.equals("dAp")) {
/* 284 */       if (this.cellCount[0] >= 1) {
/* 285 */         this.cellCount[0] -= 1;
/* 286 */         this.R -= 1;
/*     */       }
/* 288 */       if ((this.R == 0) && (this.C == 0)) {
/* 289 */         this.currentTime = 1000.0D;
/*     */       }
/* 291 */     } else if (nextEvent.equals("gAp")) {
/* 292 */       if (this.cellCount[1] >= 1) {
/* 293 */         this.cellCount[1] -= 1;
/* 294 */         this.R -= 1;
/*     */       }
/* 296 */       if ((this.R == 0) && (this.C == 0)) {
/* 297 */         this.currentTime = 1000.0D;
/*     */       }
/* 299 */     } else if (nextEvent.equals("dE")) {
/* 300 */       if (this.cellCount[0] >= 1) {
/* 301 */         this.cellCount[0] -= 1;
/* 302 */         this.R -= 1;
/*     */         
/*     */ 
/* 305 */         if ((!this.maxCellConBoolean) || (this.C < this.N2)) {
/* 306 */           this.cellCount[2] += 1;
/* 307 */           this.C += 1;
/*     */         }
/*     */       }
/* 310 */     } else if (nextEvent.equals("gE")) {
/* 311 */       if (this.cellCount[1] >= 1) {
/* 312 */         this.cellCount[1] -= 1;
/* 313 */         this.R -= 1;
/*     */         
/* 315 */         if ((!this.maxCellConBoolean) || (this.C < this.N2)) {
/* 316 */           this.cellCount[3] += 1;
/* 317 */           this.C += 1;
/*     */         }
/*     */       }
/* 320 */     } else if (nextEvent.equals("dD")) {
/* 321 */       if (this.cellCount[2] >= 1) {
/* 322 */         this.cellCount[2] -= 1;
/* 323 */         this.C -= 1;
/*     */       }
/* 325 */       if ((this.R == 0) && (this.C == 0)) {
/* 326 */         this.currentTime = 1000.0D;
/*     */       }
/* 328 */     } else if (nextEvent.equals("gD")) {
/* 329 */       if (this.cellCount[3] >= 1) {
/* 330 */         this.cellCount[3] -= 1;
/* 331 */         this.C -= 1;
/*     */       }
/* 333 */       if ((this.R == 0) && (this.C == 0)) {
/* 334 */         this.currentTime = 1000.0D;
/*     */       }
/* 336 */     } else if (nextEvent.equals("dAs")) {
/* 337 */       this.cellCount[2] += 1;
/* 338 */       this.C += 1;
/* 339 */     } else if (nextEvent.equals("gAs")) {
/* 340 */       this.cellCount[3] += 1;
/* 341 */       this.C += 1;
/*     */     }
/*     */   }
/*     */   
/*     */   public long TwoComp1()
/*     */   {
/* 347 */     if (this.randomStart) {
/* 348 */       this.Rd0 = rbin(this.R0, this.Rpercent);
/* 349 */       this.Cd0 = rbin(this.C0, this.Cpercent);
/*     */     }
/* 351 */     this.recCd[0] = this.Cd0;
/* 352 */     this.recC[0] = this.C0;
/* 353 */     this.recRd[0] = this.Rd0;
/* 354 */     this.recR[0] = this.R0;
/* 355 */     this.recY[0] = ((int)(this.sampleSize * this.Cd0 / this.C0));
/*     */     
/* 357 */     this.R = this.R0;
/* 358 */     this.cellCount[0] = this.Rd0;
/* 359 */     this.cellCount[1] = (this.R - this.Rd0);
/* 360 */     this.C = this.C0;
/* 361 */     this.cellCount[2] = this.Cd0;
/* 362 */     this.cellCount[3] = (this.C - this.Cd0);
/*     */     
/* 364 */     this.currentTime = 0.0D;
/*     */     
/* 366 */     for (int k = 1; k < this.L; k++)
/*     */     {
/* 368 */       while (this.currentTime <= this.times[k]) {
/* 369 */         this.sumOfRates = 0.0D;
/* 370 */         for (int i = 0; i < this.typeOfEvents; i++) {
/* 371 */           this.compoundRates[i] = (this.rates[i] * this.cellCount[this.cellCountIdx[i]]);
/* 372 */           this.sumOfRates += this.compoundRates[i];
/*     */         }
/* 374 */         for (int i = 0; i < this.typeOfEvents; i++) {
/* 375 */           this.compoundRates[i] /= this.sumOfRates;
/*     */         }
/* 377 */         this.currentTime += rexp(this.sumOfRates);
/*     */         
/* 379 */         updateCompartment(this.events[((int)rmultnom1(this.compoundRates, this.typeOfEvents))]);
/*     */       }
/*     */       
/* 382 */       k--;
/* 383 */       this.recCd[(k + 1)] = this.cellCount[2];
/* 384 */       this.recC[(k + 1)] = this.C;
/* 385 */       this.recRd[(k + 1)] = this.cellCount[0];
/* 386 */       this.recR[(k + 1)] = this.R;
/* 387 */       this.recY[(k + 1)] = rbin(this.sampleSize, this.cellCount[2] / this.C);
/* 388 */       k++;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 396 */     this.currentGroup += 1;
/* 397 */     return 1L;
/*     */   }
/*     */   
/*     */ 
/*     */   public void createOutputFile()
/*     */   {
/*     */     try
/*     */     {
/* 405 */       File outputFile = new File(this.outputFileName);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 413 */       FileOutputStream out = new FileOutputStream(outputFile, false);
/* 414 */       PrintStream p = new PrintStream(out);
/* 415 */       p.println("#");
/* 416 */       p.println("Time Group Cd C Rd R Y");
/* 417 */       p.close();
/*     */     } catch (Exception e) {
/* 419 */       System.err.println("Error writing to file.");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void outputResults()
/*     */   {
/* 430 */     int i = 0;
/*     */     try
/*     */     {
/* 433 */       FileOutputStream updatedResults = new FileOutputStream(this.outputFileName, true);
/* 434 */       PrintStream p = new PrintStream(updatedResults);
/*     */       
/* 436 */       while (i < this.L) {
/* 437 */         p.print(i * this.sampleInterval + " " + this.currentGroup + " ");
/* 438 */         p.println(this.recCd[i] + " " + this.recC[i] + " " + this.recRd[i] + " " + this.recR[i] + " " + this.recY[i]);
/*     */         
/* 440 */         i++;
/*     */       }
/*     */       
/* 443 */       p.close();
/*     */     } catch (Exception e) {
/* 445 */       System.err.println("Error writing to file.");
/*     */     }
/*     */   }
/*     */   
/*     */   public void setCellChanceRate(double cellChanceRate)
/*     */   {
/* 451 */     this.cellChanceRate = cellChanceRate;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 459 */   private long Indexp = 2L;
/*     */   
/*     */ 
/* 462 */   protected int N = 10000;
/*     */   
/*     */ 
/* 465 */   public int R0 = 100;
/* 466 */   public int Rd0 = 50;
/* 467 */   public int C0 = 100;
/* 468 */   public int Cd0 = 50;
/*     */   
/*     */   private int[] cellCount;
/*     */   
/*     */   private int R;
/*     */   private int C;
/*     */   private double Rpercent;
/*     */   private double Cpercent;
/*     */   public int[] times;
/*     */   public int[] recRd;
/*     */   public int[] recR;
/*     */   public int[] recCd;
/*     */   public int[] recC;
/*     */   public int[] recY;
/* 482 */   private int currentGroup = 1;
/*     */   
/*     */   private double currentTime;
/*     */   
/*     */   private double sumOfRates;
/*     */   
/*     */   private int typeOfEvents;
/*     */   private double[] rates;
/*     */   private double[] compoundRates;
/*     */   private int[] cellCountIdx;
/* 492 */   private int sampleSize = 70;
/* 493 */   private int sampleInterval = 4;
/*     */   
/*     */   private String[] events;
/*     */   
/*     */   private String outputFileName;
/*     */   
/* 499 */   public boolean writeResults2File = true;
/*     */   private boolean randomStart;
/*     */   private boolean cellChance;
/*     */   private double chanceSurvive;
/*     */   private double cellChanceRate;
/*     */   private boolean maxCellConBoolean;
/*     */   private int N2;
/*     */ }


/* Location:              /Users/jasonxu/Desktop/HematopoiesisSimulator.jar!/simulatorcore/Mice2newSim.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */